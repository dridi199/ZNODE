# Connectors
## Description
Connecteurs génériques HDFS, HBase, Hive, Kafka,.. pour les applications JAVA deployées sur le cluster Hadoop

## Versions
* 0.0.1 19/04/2016, <mailto:fahd-externe.essid@edf.fr>, creation (version non utilisable)
* 1.0.0 14/06/2016, <mailto:fahd-externe.essid@edf.fr>, gestion des Exceptions, depot sur le Nexus, intégartion jenkins
* 1.0.3 12/12/2016, <mailto:fahd-externe.essid@edf.fr>, ajout du Connecteur Oracle
* 1.0.4 11/01/2017, <mailto:fahd-externe.essid@edf.fr>, ajout de la methode get pour le connecteur Elasticsearch
* 1.0.5 13/01/2017, <mailto:fahd-externe.essid@edf.fr>, support hostname multi-noeuds dans Elasticsearch
* 1.0.9 14/04/2017, <mailto:fahd-externe.essid@edf.fr>, correction truncate hbase
* 1.1.0 21/04/2017, <mailto:ahmed-a-externe.mabrouk@edf.fr>, Ajout du connecteur Elasticsearch HTTP
* 1.1.1 21/04/2017, <mailto:fahd-externe.essid@edf.fr>, Ajout de Enable/Disable sur l'action truncate dans HbaseConnector
* 1.1.2 19/05/2017, <mailto:fahd-externe.essid@edf.fr>, Exposer les attributs de JDBConnector
* 1.1.8 21/04/2017, <mailto:ahmed-a-externe.mabrouk@edf.fr>, Ajout de la méthode deleteByQuery dans Elasticsearch HTTP
* 1.1.9 04/07/2017, <mailto:ahmed-externe.dridi@edf.fr>, upgrade java version and hadoop_udd 2.5.3  
* 1.2.2 08/08/2017, <mailto:ahmed-a-externe.mabrouk@edf.fr>, Ajout de la méthode search dans Elasticsearch HTTP
* 1.2.3 16/08/2017, ahmed-externe.dridi@edf.fr, Ajout de la méthode procedureExec a AbstractJdbcConnector
* 1.2.5 25/10/2017, <mailto:ahmed-a-externe.mabrouk@edf.fr> Ajout du connecteur Elasticsearch TCP
* 1.4.2 22/03/2018, <mailto:fahd-externe.essid@edf.fr>, Exposer l'instance de JestClient dans le connecteur HTTP d'elastic
* 1.4.2 07/05/2018, <mailto:hubert-externe.picardat@edf.fr>, 2 méthodes pour vérifier l'état de santé du cluster elastic


## Integration (Maven/Nexus) 
Par defaut, les connectors ont beaucoup de dépendances. Pour un Job Spark (Build avec dépendances), il est recommandé de les exclure et de les
ajouter une à une dans le POM principal, afin de limiter la taille du JAR.

```xml
<groupId>fr.edf.dco.common</groupId>
<artifactId>connectors</artifactId>
<version>1.5.2</version>
```

## Build et dépendances
* Depuis jenkins, http://jenkins.dn.edf.fr:8080/job/connectors/

## Test Fonctionnels
* Pas de tests JUnit (pas bien pour une librairie mutualisée!)