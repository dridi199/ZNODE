#!/bin/bash

hdfs dfs -mkdir -p /user/dco_app_bhc/init/armatis
hdfs dfs -mkdir -p /user/dco_app_bhc/init/armatis/fea 
hdfs dfs -mkdir -p /user/dco_app_bhc/init/armatis/feaRetours
hdfs dfs -mkdir -p /user/dco_app_bhc/init/armatis/dpnr
hdfs dfs -mkdir -p /user/dco_app_bhc/init/armatis/dpnrRetours
hdfs dfs -mkdir -p /user/dco_app_bhc/init/awl
hdfs dfs -mkdir -p /user/dco_app_bhc/init/awl/emailTracking
hdfs dfs -mkdir -p /user/dco_app_bhc/init/awl/messagesReceived
hdfs dfs -mkdir -p /user/dco_app_bhc/init/awl/messagesSent
hdfs dfs -mkdir -p /user/dco_app_bhc/init/awl/notifications
hdfs dfs -mkdir -p /user/dco_app_bhc/init/awl/inca
hdfs dfs -mkdir -p /user/dco_app_bhc/init/cabestan
hdfs dfs -mkdir -p /user/dco_app_bhc/init/cabestanRetours
hdfs dfs -mkdir -p /user/dco_app_bhc/init/cabestanRetours/clics
hdfs dfs -mkdir -p /user/dco_app_bhc/init/cabestanRetours/devices
hdfs dfs -mkdir -p /user/dco_app_bhc/init/cabestanRetours/mail
hdfs dfs -mkdir -p /user/dco_app_bhc/init/emissaires
hdfs dfs -mkdir -p /user/dco_app_bhc/init/emissairesRetours
hdfs dfs -mkdir -p /user/dco_app_bhc/init/etlsimm
hdfs dfs -mkdir -p /user/dco_app_bhc/init/etlsimm/rationalise
hdfs dfs -mkdir -p /user/dco_app_bhc/init/etlsimm/echea
hdfs dfs -mkdir -p /user/dco_app_bhc/init/etlsimm/satho
hdfs dfs -mkdir -p /user/dco_app_bhc/init/abandons
hdfs dfs -mkdir -p /user/dco_app_bhc/init/editic
hdfs dfs -mkdir -p /user/dco_app_bhc/init/editic/data
hdfs dfs -mkdir -p /user/dco_app_bhc/init/editic/acq
hdfs dfs -mkdir -p /user/dco_app_bhc/init/inca_insert
hdfs dfs -mkdir -p /user/dco_app_bhc/tmp/unprocessed

hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/ARCourrier* /user/dco_app_bhc/init/armatis/fea/ 
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/*DPNR*zipfile* /user/dco_app_bhc/init/armatis/dpnr/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/EDF_MM_CIBLE_EMAIL_CABE* /user/dco_app_bhc/init/cabestan/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/EDF_MM_CIBLE_COURRIER_EMIS* /user/dco_app_bhc/init/emissaires/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/DACC_POPULATIONTEMOIN* /user/dco_app_bhc/init/etlsimm/rationalise/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/*BHC_EDITIC*data* /user/dco_app_bhc/init/editic/data/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/*ECHEA* /user/dco_app_bhc/init/etlsimm/echea/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/*ACTCO* /user/dco_app_bhc/init/etlsimm/satho/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/*CONTACTS_EDF_MM_* /user/dco_app_bhc/init/awl/inca/

hdfs dfs -mv /user/dco_app_bhc/workretourtmp/*FACTU_ELEVEE* /user/dco_app_bhc/init/armatis/feaRetours/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/*DPNR*targzfile* /user/dco_app_bhc/init/armatis/dpnrRetours/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/*EMAILTracking* /user/dco_app_bhc/init/awl/emailTracking/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/*MessagesReceived* /user/dco_app_bhc/init/awl/messagesReceived/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/*MessagesSent* /user/dco_app_bhc/init/awl/messagesSent/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/*Notifications* /user/dco_app_bhc/init/awl/notifications/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/*CLICS* /user/dco_app_bhc/init/cabestanRetours/clics/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/*COMPL1* /user/dco_app_bhc/init/cabestanRetours/devices/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/*ROUTAGEEMAIL* /user/dco_app_bhc/init/cabestanRetours/mail/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/EDF_MM_EMIS* /user/dco_app_bhc/init/emissairesRetours/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/*EDF_MM_INCA_REPRISE* /user/dco_app_bhc/init/abandons/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/*BHC_EDITIC*acq* /user/dco_app_bhc/init/editic/acq/
hdfs dfs -mv /user/dco_app_bhc/tmp/xml/*EDF_MM_INSERT* /user/dco_app_bhc/init/inca_insert/

hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/* /user/dco_app_bhc/tmp/unprocessed/
hdfs dfs -mv /user/dco_app_bhc/workretourtmp/* /user/dco_app_bhc/tmp/unprocessed/
hdfs dfs -mv /user/dco_app_bhc/tmp/xml/* /user/dco_app_bhc/tmp/unprocessed/

exit 0