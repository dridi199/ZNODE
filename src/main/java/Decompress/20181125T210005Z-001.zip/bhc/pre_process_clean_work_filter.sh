#!/bin/bash

hdfs dfs -mv /user/dco_app_bhc/work/* /user/dco_app_bhc/workciblagetmp/
hdfs dfs -rm -r /user/dco_app_bhc/workciblagetmp/EDF_MA*
hdfs dfs -rm -r /user/dco_app_bhc/workciblagetmp/*Followup*
hdfs dfs -rm -r /user/dco_app_bhc/workciblagetmp/*_FORM_*
hdfs dfs -rm -r /user/dco_app_bhc/workciblagetmp/*.tar.gz
hdfs dfs -rm -r /user/dco_app_bhc/workciblagetmp/*.zip

hdfs dfs -mkdir /user/dco_app_bhc/tmp/xml
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/*.xml /user/dco_app_bhc/tmp/xml/

hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/EDF_MM_CABE_* /user/dco_app_bhc/workretourtmp/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/EDF_MM_EMIS_* /user/dco_app_bhc/workretourtmp/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/*acq* /user/dco_app_bhc/workretourtmp/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/WL_* /user/dco_app_bhc/workretourtmp/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/RETOURS_EXPE_LASERCONTACT_DPNR_*targzfile* /user/dco_app_bhc/workretourtmp/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/RETOURS_EXPE_LASERCONTACT_FACTU_ELEVEE_*targzfile* /user/dco_app_bhc/workretourtmp/
hdfs dfs -mv /user/dco_app_bhc/workciblagetmp/EDF_MM_INCA_REPRISE_* /user/dco_app_bhc/workretourtmp/


exit 0