#!/bin/bash

classname=$1

KRBUSER=dco_app_bhc
APPDIR=$HOME/scripts/contacts/bhc
COMMONDIR=/home/dco_app/usr
LOGGERVERSION=2.6.0

sparkconf=$(egrep '^spark\.' $APPDIR/config/bhc.properties | sed "s/^/--conf /g" | xargs)

mainjar=$(ls $APPDIR/lib/bhc*.jar | tail -1 |awk '{print $1}')

spark-submit $SITE_SPARKOPTS $sparkconf \
  --jars $COMMONDIR/lib/hdfs/HDFSLogger-$LOGGERVERSION.jar \
  /usr/hdp/current/hive-client/lib/datanucleus-core-3.2.10.jar,/usr/hdp/current/hive-client/lib/datanucleus-api-jdo-3.2.6.jar,/usr/hdp/current/hive-client/lib/datanucleus-rdbms-3.2.9.jar  
  --files $HOME/keytabs/$KRBUSER.keytab,$COMMONDIR/conf/hbase-site.xml,$COMMONDIR/conf/core-site.xml,$COMMONDIR/conf/hive-site.xml,$COMMONDIR/conf/hdfs-site.xml,$COMMONDIR/kerberos/krb5.conf,$APPDIR/config/HDFSLogger.properties,$APPDIR/config/contacts_hypervision.properties \
  --class fr.edf.dco.app.bhc.batch.spark.jobs.$classname \
  --name fr.edf.dco.bhc.batch.$classname \
  --master yarn-cluster \
  --queue dco_batch \
  --conf spark.yarn.executor.memoryOverhead=2048 --num-executors 10 --executor-memory 5G --executor-cores 1 --driver-memory 5G --driver-cores 1 \
$mainjar $2 $3 $4 $5
