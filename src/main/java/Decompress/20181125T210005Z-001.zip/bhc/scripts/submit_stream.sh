#!/bin/sh
# Script generique de lancement/arret d'une chaine Spark streaming sur Kafka 0.10
# Supporte les options --kill (arret), --clean (supprimer le Checkpoint) et --reset (reset des offsets ï¿½ gerer dans le code)

# parametres a adapter
KRBUSER=dco_app_bhc
APPDIR=$HOME/scripts/contacts/bhc
APPNAME=fr.edf.dco.cs.$1
PROPFILE=$HOME/scripts/contacts/bhc/config/bhc.properties
TOPIC=fr.edf.dco.cs.stream
MAINJAR=$(ls -t $APPDIR/lib/bhc-%INSTALL_BHC_JAR_VERSION%.jar | head -1 |awk '{print $1}')
CLASSNAME=fr.edf.dco.contacts.bhc.streaming.spark.jobs.$1
# -------------------------------
# Ne pas toucher au reste a priori
common=/home/dco_app/usr
appid=$(yarn  application -list -appTypes SPARK 2>/dev/null  | grep $APPNAME | awk '{print $1}')
if [[ $1 == --kill ]]
then if [[ -n $appid ]]
     then yarn application -kill $appid
     else echo "Spark application $APPNAME is not running"
     fi
     exit
fi
if [[ -n $appid ]]
then echo "Spark application $APPNAME is already running"; exit
fi
if [[ $1 == --clean ]]
then shift
     ckdir=$(grep "checkpointDirectory=" $PROPFILE |cut -c 21-)
     echo "Cleaning $ckdir"
     hdfs dfs -rm -r $ckdir/*
fi
(cat>jaas.conf)<<EOF
KafkaClient {
  com.sun.security.auth.module.Krb5LoginModule required
  doNotPrompt=true
  useTicketCache=false
  useKeyTab=true
  principal="$KRBUSER@$SITE_REALM"
  keyTab="$KRBUSER.keytab"
  serviceName="kafka";
};
EOF
sparkconf=$(grep '^spark.' $PROPFILE | sed "s/^/--conf /g" | xargs)
files=$APPDIR/config/HDFSLogger.properties,$common/conf/hbase-site.xml,$common/conf/hive-site.xml,$common/kerberos/krb5.conf,/home/dco_app_bhc/$KRBUSER.keytab,$PROPFILE,/etc/kafka/conf/truststore,jaas.conf
spark-submit $SITE_SPARKOPTS $sparkconf \
  --jars $common/lib/hdfs/HDFSLogger-2.6.0.jar \
  --files $files \
  --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=./jaas.conf" \
  --conf "spark.driver.extraJavaOptions=-Djava.security.auth.login.config=./jaas.conf" \
  --class $CLASSNAME \
  --name $APPNAME \
  --master yarn-cluster \
  --queue dco_fast \
 $MAINJAR $@ $SITE_KAFKA_SECURE $TOPIC
$1
