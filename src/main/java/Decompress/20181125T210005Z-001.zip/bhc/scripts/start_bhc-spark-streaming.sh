#!/bin/sh
a=10000
if test -e "f.txt"
then
    rm f.txt
fi
if [[ $1 == "--resetOffsets" ]]
then
echo "The Job Streaming wil be Submitted automatically"
echo "scan 'dco_app_bhc:bhc_contacts_params'" | hbase shell >> f.txt
sed -i '1,7d' f.txt
sed -i '$d' f.txt
sed -i '$d' f.txt
sed -i '$d' f.txt
sed -i '2,3d' f.txt
sed -i '3,4d' f.txt
sed -i '4,5d' f.txt
sed -i '5,6d' f.txt
sed -i '6,7d' f.txt
sed -i '7,8d' f.txt

cat f.txt | while read line
do
 partition_id=${line:0:1}
 offset_end=$((${line:56:${#line}}-$a))
echo "put 'dco_app_bhc:bhc_contacts_params','$partition_id','P:p_offset_end','$offset_end'" | hbase shell
done
fi
echo "Submitting Streaming Job"
./submit_stream.sh "KafkaToHbaseStreamingJob"