#!/bin/bash
# parametres a adapter
KRBUSER=dco_app_bhc
APPDIR=$HOME/scripts/contacts/bhc
APPNAME=fr.edf.dco.cs.$1
PROPFILE=$HOME/scripts/contacts/bhc/config/bhc.properties
MAINJAR=$(ls -t $APPDIR/lib/bhc-%INSTALL_BHC_JAR_VERSION%.jar | head -1 |awk '{print $1}')
CLASSNAME=fr.edf.dco.contacts.bhc.streaming.spark.jobs.$1
common=/home/dco_app/usr
hiveClientHome=/home/dco_app/usr/lib/hiveClient/


spark-submit --jars $hiveClientHome/datanucleus-core-3.2.10.jar,$hiveClientHome/datanucleus-api-jdo-3.2.6.jar,$hiveClientHome/datanucleus-rdbms-3.2.9.jar,$common/lib/hdfs/HDFSLogger-2.6.0.jar \
--files $APPDIR/config/HDFSLogger.properties,$common/conf/hbase-site.xml,$common/conf/hive-site.xml,$common/kerberos/krb5.conf,/home/dco_app_bhc/$KRBUSER.keytab,$PROPFILE \
--class fr.edf.dco.contacts.bhc.batch.spark.jobs.$1 --master yarn-cluster --queue dco_batch --num-executors 40 --executor-memory 5G --executor-cores 1 --driver-memory 5G --driver-cores 1 \
--conf spark.sql.shuffle.partitions=500 --conf spark.yarn.executor.memoryOverhead=1048 $MAINJAR $2 $3 $4 $5
