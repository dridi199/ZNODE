# Projet BHC - Base d'historisation des contacts
## Statut et historique
- En recette
- Version de la librairie bhc-....jar:

| Version    | Branche  | Date        | contact | commentaire |
| :--------- | :---------- | :---------- | :---------- |:--------|
| 0.0.1|Master|19/04/2016| <mailto:fahd-externe.essid@edf.fr>| creation
| 0.2.0|Master|22/03/2017| <mailto:fahd-externe.essid@edf.fr>| Premiere version stable, build dans jenkins
| 0.2.1|Master|22/03/2017| <mailto:fahd-externe.essid@edf.fr>| renommage du nom de package de fr.edf.dco.app vers fr.edf.dco.contacts
| 0.2.2|Master|22/03/2017| <mailto:fahd-externe.essid@edf.fr>| mise à jour du fichier pom.xml
| 0.2.3|Master|23/03/2017| <mailto:fahd-externe.essid@edf.fr>| ajout de l'action fix messages sent
| 0.2.4|Master|23/03/2017| <mailto:fahd-externe.essid@edf.fr>| mise à jour de la librairie connectors
| 0.2.5|Master|24/03/2017| <mailto:fahd-externe.essid@edf.fr>| fix cas timestamp negative
| 0.2.6|Master|27/03/2017| <mailto:fahd-externe.essid@edf.fr>| ajout acces user/pwd aux connecteurs JDBC
| 0.2.7|Master|29/03/2017| <mailto:fahd-externe.essid@edf.fr>| fix retours inca
| 0.2.9|Master|03/04/2017| <mailto:fahd-externe.essid@edf.fr>| ajout de l'acquittement d'ecriture dans SQLServer
| 0.3.0|Master|03/04/2017| <mailto:fahd-externe.essid@edf.fr>| ajout date acquitement, reduction ressources spark
| 0.3.1|Master|03/04/2017| <mailto:fahd-externe.essid@edf.fr>| evolution mapping inca abandon, ajouts des colonnes insert facture sur SAS_CIB_BHC
| 0.3.1|HDP2.5.3|07/04/2017| <mailto:fahd-externe.essid@edf.fr>| Création branche HDP2.53 pour TNR DATALAB
| 0.3.2|Master|05/04/2017| <mailto:fahd-externe.essid@edf.fr>| un seul job pour la publication dans les 3 table du SAS et donc une seule action oozie spark
| 0.3.3|Master|11/04/2017| <mailto:fahd-externe.essid@edf.fr>| enlever l'action oozie truncate hbase temporay table et ajouter cette fonction en fin du job hbase to sql
| 0.0.1|R7|11/04/2017| <mailto:fahd-externe.essid@edf.fr>| Création branche R7 pour les travaux bloquant en R7 (example changement de shema SQLServer)
| 0.3.4|Master|12/04/2017| <mailto:fahd-externe.essid@edf.fr>| Utilise la colonne hive line comme colonne de distribution
| 0.3.5|Master|14/04/2017| <mailto:fahd-externe.essid@edf.fr>| Mise à jour connectors + optimisation scan hbase depuis spark
| 0.3.6|Master|21/04/2017| <mailto:fahd-externe.essid@edf.fr>| ajouts champs editic à la table des ciblage SQL
| 0.3.7|Master|24/04/2017| <mailto:fahd-externe.essid@edf.fr>| modification sur Awl Messages Received
| 0.4.2|Master|24/04/2017| <mailto:fahd-externe.essid@edf.fr>| modification du separateur du vecteur inser_log du flux EDITIC ((,) au lieu de (;) pris en charge les deux)
| 0.4.7|Master|26/05/2017| <mailto:fahd-externe.essid@edf.fr>| parametrage hbase to sqlserver en y
| 0.4.8|Master|26/05/2017| <mailto:fahd-externe.essid@edf.fr>| rajout de controle dans hive to hbase pour laisser les fichier acq en dernier
| 0.5.7|HDP2.5.3|26/04/2017| <mailto:ahmed-externe.dridi@edf.fr>| migration vers HDP2.5.3
| 0.6.6|master|26/05/2017| <mailto:ahmed-externe.dridi@edf.fr>| redéploiment de chaine BHC oozie
| 0.6.7|master|26/05/2017| <mailto:ahmed-externe.dridi@edf.fr>| upgrade vers kafka 0.10
| 0.6.8|master|26/05/2017| <mailto:ahmed-externe.dridi@edf.fr>| saving kafka offsets to hdfs
| 0.6.9|master|14/05/2017| <mailto:ahmed-externe.dridi@edf.fr>| saving kafka offsets to hbase table
| 0.7.1|master|18/06/2017| <mailto:ahmed-externe.dridi@edf.fr>| add champs FLUX, MARCHE, RAISON_DESABO to Table interaction, reaction
| 0.7.2|master|28/07/2017| <mailto:ahmed-externe.dridi@edf.fr>| migration project to DSP git and jenkins
| 0.7.3|master|21/09/2017| <mailto:ahmed-externe.dridi@edf.fr>| add filterByRowKey
| 0.7.4|master|29/09/2017| <mailto:ahmed-externe.dridi@edf.fr>| Ordonnancement des flux dans la reprise et fix MessageReceived et mapping parametrable
| 0.7.6|master|27/10/2017| <mailto:ahmed-externe.dridi@edf.fr>| Oozification sparkstreaming et publication ze hadoop
## Informations sur l'application
- Domaine: Transverse
- Projet GitLab: https://si-devops-gitlab.edf.fr/bmp-acc-devops/bhc.git
- Process métier: PM7008
- Compte applicatif: dco_app_bhc
- Répertoire d'installation (frontal) : /home/dco_app_bhc/scripts/contacts/bhc
- Contact: <mailto:ahmed-externe.dridi@edf.fr>
- Documentation projet: A COMPLETER !!

## Build et dépendances
- la librairie bhc-....jar doit etre construite dans Jenkins http://jenkins.dn.edf.fr:8080/job/BHC/
- Attention, en cas de rebuild il faut mettre à jour oozie/job.properties

## Données 
**Sources**
- 
- Topic Kafka ```fr.edf.dco.cs.stream``` alimenté par la PSC avec les données ediway edifuz
- Fichiers txt et csv provenant des differents routeurs (CABESTAN, EMISSAIRES, ARMATIS, AWL...) deposés sur HDFS 
- Données statiques chargées depuis SQLServer pour la cartographie, procedure stockée : PMDBI/Contacts_Sortants/SP_BHC_CARTOGRAPHIE

**Destination**
- Table Hbase dco_app_bhc:bhc_contacts
- Table Hbase dco_app_bhc:bhc_contacts_temp
- Table SQLServer PMDBI/Contacts_Sortants_Reporting/SAS_CIB_BHC
- Table SQLServer PMDBI/Contacts_Sortants_Reporting/SAS_INT_BHC
- Table SQLServer PMDBI/Contacts_Sortants_Reporting/SAS_REA_BHC

## Installation 
### Application
Depuis le frontal, compte dco_app_bhc 

```ssh
oou install http://<git username>@gitlab.dn.edf.fr/dco/bhc.git
# deploiement des Coordinateurs
cd $HOME/scripts/contacts/bhc/oozie
oou deploy BHC-Coordinator.xml
```

### Arret/demarrage du job Spark Streaming
- **A COMPLETER**

## Reprise sur erreur
- **A COMPLETER**

## Tests fonctionnels
- **A COMPLETER**