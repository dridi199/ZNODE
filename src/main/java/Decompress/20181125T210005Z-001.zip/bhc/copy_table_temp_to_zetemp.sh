#!/bin/bash

hbase org.apache.hadoop.hbase.mapreduce.CopyTable -Dmapreduce.job.queuename=dco_batch -Dhadoop.security.group.mapping=org.apache.hadoop.security.JniBasedUnixGroupsMappingWithFallback --new.name='dco_app_bhc:bhc_contacts_zetemp' 'dco_app_bhc:bhc_contacts_temp';

exit 0