#!/bin/bash

beeline -u 'jdbc:hive2://'"$SITE_ZOOKEEPER"'/;principal=hive/_HOST@'"$SITE_REALM"';serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2;transportMode=http;httpPath=cliservice;ssl=true?tez.queue.name=dco_batch' -f $1
