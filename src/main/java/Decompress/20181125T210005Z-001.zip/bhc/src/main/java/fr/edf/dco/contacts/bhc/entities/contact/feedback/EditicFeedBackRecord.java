package fr.edf.dco.contacts.bhc.entities.contact.feedback;

import java.io.IOException;
import java.text.ParseException;

import org.apache.hadoop.hbase.client.Put;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * EDITIC feed back record representation
 * 
 * @author fahd-externe.essid@edf.fr
 *
 */
public class EditicFeedBackRecord extends FeedBackRecord {

  // ------------------------------------------------------------------
  // CONSTRUCTOR
  // ------------------------------------------------------------------

  public EditicFeedBackRecord(String file) {
    super(file, "\\|", Constants.CONTACT_STREAM_EDITIC, 4, "ID_CONTACT", false);
    this.trialId = 11;
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------

  @Override
  protected void process(String[] fields) throws CustomException {
    line.communicationID = fields[0].trim();

    if (line.communicationID.startsWith("TIC_") || !line.communicationID.startsWith("TIC")) {
      throw new CustomException("invalid communication id : " + line.communicationID);
    }

    line.status = fields[1].trim();

    rawDate = fields[2].trim();

    if (!Utils.isNotEmptyOrSpace(rawDate)) {
      rawDate = line.communicationID.substring(6, 14);

      try {
        date = Utils.formatDate(rawDate, "yyyyMMdd", "dd/MM/yyyy HH:mm:ss");
      } catch (ParseException e) {
        throw new CustomException("could not parse date : " + rawDate + " from yyyyMMdd to dd/MM/yyyy HH:mm:ss format");
      }
    } else {
      try {
        date = Utils.formatDate(rawDate, "yyyy-MM-dd'T'HH-mm-ss", "dd/MM/yyyy HH:mm:ss");
      } catch (ParseException e) {
        throw new CustomException("could not parse date : " + rawDate + " from yyyy-MM-dd'T'HH-mm-ss to dd/MM/yyyy HH:mm:ss format");
      }
    }

    ts = Utils.getLongTimestamp(date, "dd/MM/yyyy HH:mm:ss");
    partner = fields[3].trim();

    if (!Utils.isInit()) {
      updateInca();
    }
  }

  private void updateInca() throws CustomException {
    try {
      String insertLog1 = Utils.getExistingValue(line.communicationID, "S", "c_ref_insert_log1");
      String insertLog2 = Utils.getExistingValue(line.communicationID, "S", "c_ref_insert_log2");
      String insertLog3 = Utils.getExistingValue(line.communicationID, "S", "c_ref_insert_log3");
      String insertLog4 = Utils.getExistingValue(line.communicationID, "S", "c_ref_insert_log4");
      String insertLog5 = Utils.getExistingValue(line.communicationID, "S", "c_ref_insert_log5");
      String insertLog6 = Utils.getExistingValue(line.communicationID, "S", "c_ref_insert_log6");
      String insertLog7 = Utils.getExistingValue(line.communicationID, "S", "c_ref_insert_log7");
      String insertLog8 = Utils.getExistingValue(line.communicationID, "S", "c_ref_insert_log8");
      String insertLog9 = Utils.getExistingValue(line.communicationID, "S", "c_ref_insert_log9");
      String insertLog10 = Utils.getExistingValue(line.communicationID, "S", "c_ref_insert_log10");

      doUpdateInca(insertLog1);
      doUpdateInca(insertLog2);
      doUpdateInca(insertLog3);
      doUpdateInca(insertLog4);
      doUpdateInca(insertLog5);
      doUpdateInca(insertLog6);
      doUpdateInca(insertLog7);
      doUpdateInca(insertLog8);
      doUpdateInca(insertLog9);
      doUpdateInca(insertLog10);
    } catch (IOException e) {
      throw new CustomException("Unable to get data from hbase for ligical inserts : " + e.getMessage());
    }
  }

  private void doUpdateInca(String insert) throws IOException {
    if (Utils.isNotEmptyOrSpace(insert)) {
      String[] fields = insert.split(",|;", -1);

      if (fields.length == 3 && Utils.isNotEmptyOrSpace(fields[2]) && !fields[1].contains("0")) {
        String idTech = fields[2];
        Put p = Utils.getContactPut(idTech);

        p.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), ts, Utils.getBytes(line.raw));
        p.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), ts, Utils.getBytes(fileName));
        p.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), ts, Utils.getBytes(Constants.CONTACT_MARKET_MM));

        if (line.status.equals(Constants.CONTACT_STATUS_RAW_ABANDONED)) {
          p.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), ts, Utils.getBytes(Constants.CONTACT_STATUS_NON_ENVOYE));
        } else if (line.status.equals(Constants.CONTACT_STATUS_ENVOYE)) {
          p.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), ts, Utils.getBytes(Constants.CONTACT_STATUS_ENVOYE));
          p.addColumn(Utils.getBytes("S"), Utils.getBytes("a_tentative"), ts, Utils.getBytes(Integer.toString(trialId)));
          p.addColumn(Utils.getBytes("S"), Utils.getBytes("t_11_statut_envoi"), ts, Utils.getBytes(Constants.CONTACT_STATUS_ENVOYE));

          String tpl = Utils.getExistingValue(idTech, "S", "c_template");
          String cnl = Utils.getExistingValue(idTech, "S", "c_canal");

          p.addColumn(Utils.getBytes("S"), Utils.getBytes("t_11_canal"), ts, Utils.getBytes(cnl));
          p.addColumn(Utils.getBytes("S"), Utils.getBytes("t_11_template"), ts, Utils.getBytes(tpl));
        }
      }
    }
  }

  @Override
  public void storeToHbase() throws IOException {
    if (Utils.isNotEmptyOrSpace(line.communicationID) && ts != 0) {
      line.put = Utils.getContactPut(line.communicationID);

      line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), ts, Utils.getBytes(line.raw));
      line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), ts, Utils.getBytes(fileName));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), ts, Utils.getBytes(Constants.CONTACT_MARKET_MM));

      if (line.status.equals(Constants.CONTACT_STATUS_RAW_ABANDONED)) {
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), ts, Utils.getBytes(Constants.CONTACT_STATUS_NON_ENVOYE));
      } else if (line.status.equals(Constants.CONTACT_STATUS_ENVOYE)) {
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), ts, Utils.getBytes(Constants.CONTACT_STATUS_ENVOYE));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_tentative"), ts, Utils.getBytes(Integer.toString(trialId)));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("t_11_statut_envoi"), ts, Utils.getBytes(Constants.CONTACT_STATUS_ENVOYE));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("t_11_nom_partenaire"), ts, Utils.getBytes(partner));

        if (!Utils.isInit()) {
          line.template = Utils.getExistingValue(line.communicationID, "S", "c_template");
          line.chanel = Utils.getExistingValue(line.communicationID, "S", "c_canal");

          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("t_11_canal"), ts, Utils.getBytes(line.chanel));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("t_11_template"), ts, Utils.getBytes(line.template));
        }
      }
    }
  }

  // ------------------------------------------------------------------
  // DATA-MEMBERS
  // ------------------------------------------------------------------

  private String rawDate;
  private String date;
  private long ts;
  private String partner;
}
