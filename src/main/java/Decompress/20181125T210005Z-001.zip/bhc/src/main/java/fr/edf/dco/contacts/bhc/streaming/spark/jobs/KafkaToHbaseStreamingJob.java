package fr.edf.dco.contacts.bhc.streaming.spark.jobs;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.spark.SparkConf;
import org.apache.spark.TaskContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.HasOffsetRanges;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;
import org.apache.spark.streaming.kafka010.OffsetRange;

import fr.edf.dco.common.connector.base.ConnectorException;
import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.base.Utils;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;

/**
 * Spark Streaming application that handles contacts streaming from kafka and
 * contacts integration in HBase after specific transformations
 * 
 * save offsets using hbase table
 * 
 * @author ahmed-externe.dridi@edf.fr
 *
 */
public class KafkaToHbaseStreamingJob {
  public static void main(String[] args) {
    ApplicationContext context = ApplicationContext.getInstance();

    // Spark Streaming context configuration
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_STREAMING_KAFKA_HBASE);
    JavaStreamingContext streamingContext = new JavaStreamingContext(sparkConfiguration, Durations.seconds(120));

    String topic = context.getProperty(Constants.PROPERTIES_KAFKA_STREAM_TOPICS);
    HashSet<String> topicsSet = new HashSet<String>(Arrays.asList(topic.split(",")));

    // get new kafkaparams with trustore
    Map<String, Object> kafkaParams = context.getKafkaParams();
    JavaInputDStream<ConsumerRecord<String, String>> messages = null;
    Map<TopicPartition, Long> fromOffsets = getListOffsets(
        context.getProperty(Constants.PROPERTIES_HBASE_KAFKA_PARAMS_CONTACTS_TABLE), topic);

    // if there is an offsets into hbase table read theam all and resume from
    // them
    if (fromOffsets != null) {
      messages = KafkaUtils.createDirectStream(streamingContext, LocationStrategies.PreferConsistent(),
          ConsumerStrategies.<String, String> Assign(fromOffsets.keySet(), kafkaParams, fromOffsets));
    } else {
      // if the offsets is empty start reading topic from earliest
      messages = KafkaUtils.createDirectStream(streamingContext, LocationStrategies.PreferConsistent(),
          ConsumerStrategies.<String, String> Subscribe(topicsSet, kafkaParams));
    }

    messages.foreachRDD(new VoidFunction<JavaRDD<ConsumerRecord<String, String>>>() {
      private static final long serialVersionUID = 6479270890559614536L;

      @Override
      public void call(JavaRDD<ConsumerRecord<String, String>> rdd)
          throws ParseException, ConnectorException, IOException, InterruptedException {
        // get current time
        String timenow = new SimpleDateFormat("HH:mm").format(Calendar.getInstance().getTime());
        if (Utils.inCreneau(timenow)) {
          sleep();
        }
        flushToHbase(rdd);
      }
    });

    // start streaming job
    streamingContext.start();
    streamingContext.awaitTermination();

  }

  /**
   * if h_access false wait 5 minute
   * 
   * @throws IOException
   * @throws InterruptedException
   * @throws ParseException
   */
  // if access_writing is notgiven wait until the sunrise
  public static void sleep() throws IOException, InterruptedException, ParseException {
    ApplicationContext ctx = ApplicationContext.getInstance();
    HbaseConnector hbase = ctx.getHbase();
    hbase.setTable(ctx.getProperty(Constants.PROPERTIES_HBASE_KAFKA_PARAMS_CONTACTS_TABLE));
    String timenow = new SimpleDateFormat("HH:mm").format(Calendar.getInstance().getTime());
    while (hbase.get("6", "H", "h_access").equals("false") && Utils.inCreneau(timenow)) {
      Thread.sleep(300000); // sleep 5 min
    }
  }

  /**
   * flush rdd into hbase & update offsets
   * 
   * @param rdd
   */
  public static void flushToHbase(JavaRDD<ConsumerRecord<String, String>> rdd) {
    OffsetRange[] offsetRanges = ((HasOffsetRanges) rdd.rdd()).offsetRanges();
    rdd.foreachPartition(new VoidFunction<Iterator<ConsumerRecord<String, String>>>() {
      private static final long serialVersionUID = -8304377178209179602L;

      @Override
      public void call(Iterator<ConsumerRecord<String, String>> consumerRecords) throws ParseException {

        ApplicationContext context = ApplicationContext.getInstance();
        ContactFactory factory = new ContactFactory();
        HbaseConnector hbase = context.getHbase();

        hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
        AbstractContactRecord record = null;
        ConsumerRecord<String, String> message = null;
        while (consumerRecords.hasNext()) {
          message = consumerRecords.next();
          try {
            record = factory.createRecord(Constants.CONTACT_MESSAGE_EDIWAY_EDIFUZ);
            record.parse(message.value());
            record.storeToHbase();

          } catch (Exception e) {
            e.printStackTrace();
          }
        }
        context.flushContacts(true);

        // put offsets to hbase after processd data
        OffsetRange o = offsetRanges[TaskContext.get().partitionId()];
        try {
          hbase.put(context.getProperty(Constants.PROPERTIES_HBASE_KAFKA_PARAMS_CONTACTS_TABLE),
              "" + o.partition() + "", "P", "p_topic", "" + o.topic() + "");
          hbase.put(context.getProperty(Constants.PROPERTIES_HBASE_KAFKA_PARAMS_CONTACTS_TABLE),
              "" + o.partition() + "", "P", "p_offset_begin", "" + o.fromOffset() + "");
          hbase.put(context.getProperty(Constants.PROPERTIES_HBASE_KAFKA_PARAMS_CONTACTS_TABLE),
              "" + o.partition() + "", "P", "p_offset_end", "" + o.untilOffset() + "");
        } catch (IOException e1) {
          e1.printStackTrace();
        }
      }
    });
  }

  /**
   * get beginning_offsets for all partitions
   * 
   * @param tablename
   * @param topic
   * @return
   */
  public static Map<TopicPartition, Long> getListOffsets(String tablename, String topic) {
    ApplicationContext context = ApplicationContext.getInstance();
    Map<TopicPartition, Long> fromOffsets = new HashMap<TopicPartition, Long>();
    HbaseConnector hbase = context.getHbase();
    hbase.setTable(tablename);
    ResultScanner result = null;
    try {
      // get all latest saved offsets from hbase
      result = hbase.scan(false);
    } catch (IOException e) {
      e.printStackTrace();
    }
    Iterator<Result> it = result.iterator();
    while (it.hasNext()) {
      Result row = it.next();
      int numPartition = -1;
      long offsetbegin = 0;
      numPartition = Integer.parseInt(Bytes.toString(row.getRow())); // get
                                                                     // rowkey
      if (numPartition != 6 && numPartition != -1) {
        offsetbegin = Long.parseLong(Bytes.toString(row.getValue(Bytes.toBytes("P"), Bytes.toBytes("p_offset_end"))));
        fromOffsets.put(new TopicPartition(topic, numPartition), offsetbegin);
      }
    }
    if (fromOffsets.get(new TopicPartition(topic, 0)) == 0 && fromOffsets.get(new TopicPartition(topic, 1)) == 0
        && fromOffsets.get(new TopicPartition(topic, 2)) == 0 && fromOffsets.get(new TopicPartition(topic, 3)) == 0
        && fromOffsets.get(new TopicPartition(topic, 4)) == 0 && fromOffsets.get(new TopicPartition(topic, 5)) == 0) {
      fromOffsets = null;
    }
    return fromOffsets;
  }

  static boolean increneau = false;
}
