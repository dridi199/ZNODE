package fr.edf.dco.contacts.bhc.entities.cartography;

/**
 * Cartography Entry representation
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class Cartography {

  // ---------------------------------------------------------------------------
  // CONSTRUCTOR
  // ---------------------------------------------------------------------------

  /**
   * Creates a cartography entry from id (group code), strategy and template
   * 
   * @param id
   * @param strategy
   * @param template
   */
  public Cartography(String id, String strategy, String template) {
    this.id = id;
    this.strategy = strategy;
    this.template = template;
  }

  // ---------------------------------------------------------------------------
  // ACCESSORS
  // ---------------------------------------------------------------------------

  public String getStrategy() {
    return strategy;
  }

  public String getTemplate() {
    return template;
  }

  public String getId() {
    return id;
  }

  // ---------------------------------------------------------------------------
  // DATA MEMBERS
  // ---------------------------------------------------------------------------

  private String id;
  private String strategy;
  private String template;
}
