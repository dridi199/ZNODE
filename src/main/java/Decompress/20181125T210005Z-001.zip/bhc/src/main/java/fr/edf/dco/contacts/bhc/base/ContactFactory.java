package fr.edf.dco.contacts.bhc.base;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.common.factory.AbstractFactory;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;
import fr.edf.dco.contacts.bhc.entities.contact.EditicRecord;
import fr.edf.dco.contacts.bhc.entities.contact.feedback.ArmatisFeedBackRecord;
import fr.edf.dco.contacts.bhc.entities.contact.feedback.AwlFeedBackRecord;
import fr.edf.dco.contacts.bhc.entities.contact.feedback.IncaCabestanMmFeedBackRecord;
import fr.edf.dco.contacts.bhc.entities.contact.feedback.IncaEmissairesMMFeedBackRecord;
import fr.edf.dco.contacts.bhc.entities.contact.feedback.IncaMMAbandonedRecord;
import fr.edf.dco.contacts.bhc.entities.contact.targeting.ArmatisDpnrRecord;
import fr.edf.dco.contacts.bhc.entities.contact.targeting.ArmatisFeaRecord;
import fr.edf.dco.contacts.bhc.entities.contact.targeting.EcheaApureRecord;
import fr.edf.dco.contacts.bhc.entities.contact.targeting.EdiwayEdifuzRecord;
import fr.edf.dco.contacts.bhc.entities.contact.targeting.EtlSimmRecord;
import fr.edf.dco.contacts.bhc.entities.contact.targeting.IncaAwlMmRecord;
import fr.edf.dco.contacts.bhc.entities.contact.targeting.IncaCabestanMmRecord;
import fr.edf.dco.contacts.bhc.entities.contact.targeting.IncaEmissairesMmRecord;
import fr.edf.dco.contacts.bhc.entities.contact.targeting.IncaInsertRecord;
import fr.edf.dco.contacts.bhc.entities.contact.targeting.SathoActcoRecord;

/**
 * Contacts Factory class that delivers contact stream objects instances
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class ContactFactory extends AbstractFactory {

  /**
   * The factory criteria is the filename of the message or the kafka message
   * key in the streaming case
   */
  public AbstractContactRecord createRecord(String fileName) throws CustomException {
    if (fileName.contains(Constants.CONTACT_FILE_ETL_SIMM)) {
      return new EtlSimmRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_ECHEA_APURE)) {
      return new EcheaApureRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_SATHO_ACTCO)) {
      return new SathoActcoRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_INCA_CABESTAN_MM)) {
      return new IncaCabestanMmRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_ARMATIS_DPNR) && fileName.contains("zipfile")) {
      return new ArmatisDpnrRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_ARMATIS_FEA)) {
      return new ArmatisFeaRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_INCA_EMISSAIRES_MM)) {
      return new IncaEmissairesMmRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_INCA_CABESTAN_RETOURS_MM)) {
      return IncaCabestanMmFeedBackRecord.getRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_ARMATIS_DPNR) && fileName.contains("targzfile")) {
      return new ArmatisFeedBackRecord(fileName, Constants.CONTACT_STREAM_ARMATIS_DPNR);
    } else if (fileName.contains(Constants.CONTACT_FILE_ARMATIS_FEA_RETOURS)) {
      return new ArmatisFeedBackRecord(fileName, Constants.CONTACT_STREAM_ARMATIS_FEA);
    } else if (fileName.contains(Constants.CONTACT_MESSAGE_EDIWAY_EDIFUZ) || fileName.contains(Constants.CONTACT_MESSAGE_EDIWAY_EDIFUZ)) {
      return new EdiwayEdifuzRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_INCA_EMISSAIRES_RETOURS_MM)) {
      return new IncaEmissairesMMFeedBackRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_AWL_RETOURS) && (fileName.contains(Constants.CONTACT_FILE_AWL_MESSAGES_SENT) || fileName.contains(Constants.CONTACT_FILE_AWL_MESSAGES_RECEIVED) || fileName.contains(Constants.CONTACT_FILE_AWL_NOTIFICATIONS) || fileName.contains(Constants.CONTACT_FILE_AWL_EMAIL_TRACKING))) {
      return AwlFeedBackRecord.getRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_INCA_ABANDONS_MM)) {
      return new IncaMMAbandonedRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_EDITIC)) {
      return EditicRecord.getRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_INCA_INSERT)) {
      return new IncaInsertRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_INCA_AWL_MM)) {
      return new IncaAwlMmRecord(fileName);
    } else {
      throw new CustomException("Unknow Contact Type for file : " + fileName, fileName);
    }
  }
}
