package fr.edf.dco.contacts.bhc.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.input.PortableDataStream;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Element;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.common.connector.base.ConnectorException;
import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.common.connector.hadoop.HdfsConnector;

/**
 * Utility class containing static methods that can be used by any class here
 * are implemented general purpose methods
 * 
 * @author fahd-externe.essid@edf.fr
 */
public final class Utils extends fr.edf.dco.common.connector.base.Utils {

  /**
   * Return application context
   * 
   * @return
   */
  public static ApplicationContext getContext() {
    return ApplicationContext.getInstance();
  }

  /**
   * Transcode codes to appropriate messages
   */
  public static String transcode(String code) {
    String result = TRANSCODER.get(code);
    return result == null ? code : result;
  }

  /**
   * Return HBASE put for a given row key
   */
  public static Put getContactPut(String rowKey) {
    if (!getContext().getPuts().containsKey(rowKey)) {
      getContext().getPuts().put(rowKey, new Put(Utils.getBytes(rowKey)));
    }

    return getContext().getPuts().get(rowKey);
  }

  /**
   * Checks if application is in init mode
   */
  public static boolean isInit() {
    return getContext().getProperty(Constants.PROPERTIES_APPLICATION_INIT).equals("1");
  }

  /**
   * Substring file name without extension
   * 
   * @param name
   * @return
   */
  public static String getFileName(String name) {
    int beginFrom = 0;
    if (StringUtils.countMatches(name, ".") > 1) {
      beginFrom = name.lastIndexOf(" ", name.lastIndexOf("."));
    }

    if (name.contains("./")) {
      beginFrom = name.lastIndexOf("./") + 2;
    }

    return name.substring(beginFrom, name.lastIndexOf(".") + 4).trim();
  }

  /**
   * Return empty string if value is null
   * 
   * @param input
   * @return
   */
  public static String getEmptyIfNull(String input) {
    return input == null ? "" : input;
  }

  /**
   * Tests if an HBASE column qualifier value exists already
   */
  public static boolean valueAlreadyExists(String id, String value, String family, String column) throws IOException {
    HbaseConnector hbase = getContext().getHbase();
    hbase.setTable(getContext().getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));

    if (hbase.exists(id)) {
      Result result = hbase.getRowVersions(id);
      List<Cell> cells = result.getColumnCells(Utils.getBytes(family), Utils.getBytes(column));

      for (Cell cell : cells) {
        if (Bytes.toString(CellUtil.cloneValue(cell)).equals(value)) {
          return true;
        }
      }
    }

    if (getContext().getPuts().containsKey(id)) {
      List<Cell> cells = getContactPut(id).get(Utils.getBytes(family), Utils.getBytes(column));

      for (Cell cell : cells) {
        if (Bytes.toString(CellUtil.cloneValue(cell)).equals(String.valueOf(value))) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Tests if a row id exists already
   */
  public static boolean rowAlreadyExists(String id) throws IOException {
    HbaseConnector hbase = getContext().getHbase();
    hbase.setTable(getContext().getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));

    return hbase.exists(id) || getContext().getPuts().containsKey(id);
  }

  /**
   * Get existing value of a column qualifier for a given row key
   */
  public static String getExistingValue(String id, String family, String column) throws IOException {
    HbaseConnector hbase = getContext().getHbase();
    hbase.setTable(getContext().getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
    String value = null;

    if (hbase.exists(id)) {
      Result result = hbase.getRowVersions(id);
      List<Cell> cells = result.getColumnCells(Utils.getBytes(family), Utils.getBytes(column));

      for (Cell cell : cells) {
        value = Bytes.toString(CellUtil.cloneValue(cell));
      }
    } else if (getContext().getPuts().containsKey(id)) {
      List<Cell> cells = getContactPut(id).get(Utils.getBytes(family), Utils.getBytes(column));

      for (Cell cell : cells) {
        value = Bytes.toString(CellUtil.cloneValue(cell));
      }
    }

    return value;
  }
 
  public static Date getValueTimestamp(String id, String family, String column, String value) throws IOException {
    HbaseConnector hbase = getContext().getHbase();
    hbase.setTable(getContext().getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
    Date date = null;

    if (hbase.exists(id)) {
      Result result = hbase.getRowVersions(id);
      List<Cell> cells = result.getColumnCells(Utils.getBytes(family), Utils.getBytes(column));

      for (Cell cell : cells) {
        if (Bytes.toString(CellUtil.cloneValue(cell)).equals(value)) {
          return new Date(cell.getTimestamp());
        }
      }
    } else if (getContext().getPuts().containsKey(id)) {
      List<Cell> cells = getContactPut(id).get(Utils.getBytes(family), Utils.getBytes(column));

      for (Cell cell : cells) {
        if (Bytes.toString(CellUtil.cloneValue(cell)).equals(value)) {
          return new Date(cell.getTimestamp());
        }
      }
    }

    return date;
  }
  
  /**
   * check if filename contains date after a given date
   * 
   * @param d
   * @param name
   * @return
   */
  public static boolean getAfterDate(String d, String name) {
    if(name.contains("EDITIC")){
      name=name.substring(name.indexOf("EDITIC_")+7,name.indexOf("EDITIC_")+15);
      return (Long.parseLong(d) <= Long.parseLong(name));
    }
    else if (name.contains("_" + d.substring(0, 4))) {
      String year = d.substring(0, 4);
      name = name.substring(name.lastIndexOf("_" + year) + 1, name.lastIndexOf("_" + year) + 9);
      return (Long.parseLong(d) <= Long.parseLong(name));
    
    } else if (name.contains(".zip_")) { // special treatement for armatis archive that contains timestamp
      name = name.substring(name.indexOf(".zip_") + 5, name.length());
      Date date = new Date(Long.parseLong(name) * 1000L);
      String ad = DateFormatUtils.format(date, "yyyyMMdd");
      return (Long.parseLong(d) <= Long.parseLong(ad));
    
    } else {
      return false;
    }
  }
  
  /**
   * copy hdfs files from source to destination
   * @param path
   * @param dest
   * @throws IOException
   */
  public static void copyFile(String path,String dest) throws IOException{
    
    ApplicationContext context= ApplicationContext.getInstance();
    HdfsConnector hdfs = context.getHdfs();
    if(!hdfs.exists(dest+path.substring(path.lastIndexOf("/")+1,path.length())))
     hdfs.copy(path, dest);
    
  }
  /********************************************************************
   * Hdfs Utils
   ********************************************************************/ 
/**
 * move hdfs files from source to destination
 * @param path
 * @param dest
 * @throws IOException
 */
  public static void moveFile(String path,String dest) throws IOException{
    
    ApplicationContext context= ApplicationContext.getInstance();
    HdfsConnector hdfs = context.getHdfs();
    if(!hdfs.exists(dest+path.substring(path.lastIndexOf("/")+1,path.length())))
     hdfs.move(path, dest);
  }
  
  /**
   * INCA trial id update process
   */
  public static int updateTrialId(String id, long date, String status, int trial) throws IOException {
    HbaseConnector hbase = getContext().getHbase();
    hbase.setTable(getContext().getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
    int newTrialId = trial;

    Result result = hbase.getRowVersions(id);
    List<Cell> cells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_statut"));

    for (Cell cell : cells) {
      long ts = cell.getTimestamp();

      if (ts != date && Bytes.toString(CellUtil.cloneValue(cell)).equals(status)) {
        newTrialId++;
      }
    }

    return newTrialId;
  }

  /**
   * return boolean from String integer
   * 
   * @param number
   * @return
   */
  public static boolean getBoolean(String number) {
    if (isNotEmptyOrSpace(number)) {
      return new Integer(number).intValue() > 0;
    } else {
      return false;
    }
  }

  /**
   * Inca template and contact information in feed back
   */
  public static void updateContactInformation(String id, String coordonnees, String template) throws IOException {
    HbaseConnector hbase = getContext().getHbase();
    hbase.setTable(getContext().getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));

    if (hbase.exists(id)) {
      Result result = hbase.getRowVersions(id);
      List<Cell> cells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_tentative"));

      for (Cell cell : cells) {
        long ts = cell.getTimestamp();
        String t = Bytes.toString(CellUtil.cloneValue(cell));

        getContactPut(id).addColumn(Utils.getBytes("S"), Utils.getBytes("t_" + t + "_coordonnee"), ts, Utils.getBytes(coordonnees));
        getContactPut(id).addColumn(Utils.getBytes("S"), Utils.getBytes("t_" + t + "_template"), ts, Utils.getBytes(template));
      }
    } else if (getContext().getPuts().containsKey(id)) {
      List<Cell> cells = getContactPut(id).get(Utils.getBytes("S"), Utils.getBytes("a_tentative"));

      for (Cell cell : cells) {
        long ts = cell.getTimestamp();
        String t = Bytes.toString(CellUtil.cloneValue(cell));

        getContactPut(id).addColumn(Utils.getBytes("S"), Utils.getBytes("t_" + t + "_coordonnee"), ts, Utils.getBytes(coordonnees));
        getContactPut(id).addColumn(Utils.getBytes("S"), Utils.getBytes("t_" + t + "_template"), ts, Utils.getBytes(template));
      }
    }
  }

  public static Put resultToNoVersionPut(Result row, Put put) {

    if (row != null) {
      NavigableMap<byte[], NavigableMap<byte[], NavigableMap<Long, byte[]>>> rowMap = row.getMap();
      if(rowMap != null){
      for (byte[] f : rowMap.keySet()) {
        NavigableMap<byte[], NavigableMap<Long, byte[]>> family = rowMap.get(f);

        for (byte[] c : family.keySet()) {
          NavigableMap<Long, byte[]> column = family.get(c);
          column = cleanColumn(column);
          Long ts = Utils.getLongSetMax(column.keySet());
          byte[] v = column.get(ts);

          if (!put.has(f, c, ts)) {
            if (ts > 0) {
              put.addColumn(f, c, ts, v);
            } else {
              put.addColumn(f, c, v);
            }
          }
        }
      }
    }
    }

    return put;
  }

  /**
   * Remove empty entries from a put column navigable map
   */
  public static NavigableMap<Long, byte[]> cleanColumn(NavigableMap<Long, byte[]> column) {
    TreeMap<Long, byte[]> clean = new TreeMap<Long, byte[]>();

    for (Long l : column.keySet()) {
      if (isNotEmptyOrSpace(Bytes.toString(column.get(l)))) {
        clean.put(l, column.get(l));
      }
    }

    return clean;
  }

  /**
   * Returns the max long from a long set
   */
  public static Long getLongSetMax(Set<Long> set) {
    Long max = Long.MIN_VALUE;

    for (Long l : set) {
      if (l > max) {
        max = l;
      }
    }

    return max;
  }

  /********************************************************************
   * // JSON HANDLING
   ********************************************************************/

  /**
   * Extract JSON object from another one given the former reference id return
   * null if reference is not mentioned in json object
   */
  public static JSONObject getJsonObject(JSONObject json, String ref) {
    if (json == null) {
      return null;
    }

    JSONObject result = null;

    if (json.has(ref)) {
      try {
        result = json.getJSONObject(ref);
      } catch (JSONException e) {
        result = null;
      }
    }

    return result;
  }

  /**
   * Extract string from JSON given its reference id return null if reference is
   * not mentioned in json object
   */
  public static String getJsonString(JSONObject json, String ref) {
    if (json == null) {
      return null;
    }

    String result = null;

    if (json.has(ref)) {
      try {
        result = json.getString(ref);
      } catch (JSONException e) {
        result = null;
      }
    }

    return result;
  }

  /**
   * Extract JSON Array from JSON given its reference id return null if
   * reference is not mentioned in json object
   */
  public static JSONArray getJsonArray(JSONObject json, String ref) {
    if (json == null) {
      return null;
    }

    JSONArray result = null;

    if (json.has(ref)) {
      try {
        result = json.getJSONArray(ref);
      } catch (JSONException e) {
        result = null;
      }
    }

    return result;
  }

  /********************************************************************
   * // SERIALIZATION / DESERIALIZATION
   ********************************************************************/

  /**
   * Serialize Object to file location
   * 
   * @param file
   * @param object
   * @throws IOException 
   */
  public static void serialize(Object object, String file) throws CustomException, IOException {
    ObjectOutputStream objectOutputStream = null;
    try {
      objectOutputStream = new ObjectOutputStream(new FileOutputStream(file));
      objectOutputStream.writeObject(object);
    } catch (FileNotFoundException e) {
      throw new CustomException(" FileNotFoundException : " + e.getMessage());
    } catch (IOException re) {
      throw new CustomException(" IOException : " + re.getMessage());
    } finally {
      if (objectOutputStream != null)
        objectOutputStream.close();
    }

  }

  /**
   * Deserialize Object from file and return Object
   * 
   * @param file
   * @return object
   * @throws IOException
   * @throws ClassNotFoundException
   */
  public static Object deserialize(String file) throws CustomException, IOException, ClassNotFoundException {
    ObjectInputStream objectInputStream = null;
    Object object = null;
    try {
      objectInputStream = new ObjectInputStream(new FileInputStream(file));
      object = objectInputStream.readObject();
    } catch (FileNotFoundException e) {
      throw new CustomException(" FileNotFoundException : " + e.getMessage());
    } catch (IOException re) {
      throw new CustomException(" IOException : " + re.getMessage());
    } finally {
      if (objectInputStream != null)
        objectInputStream.close();
    }
    return object;
  }

  /********************************************************************
   * DATE UTILS
   ********************************************************************/

  /**
   * Return SQL format Timestamp value out of long Timestamp and date format
   * 
   * @param ts
   * @param format
   * @return
   */
  public static Timestamp getSqlTimestamp(long ts, String format) {
    String formattedDate = new SimpleDateFormat(format).format(new Date(ts));
    Timestamp timestamp = Timestamp.valueOf(formattedDate);
    Calendar cal = Calendar.getInstance();
    cal.set(2000, Calendar.JANUARY, 1);
    Date date = cal.getTime();

    if (timestamp.before(date)) {
      return null;
    } else {
      return timestamp;
    }
  }

  public static Timestamp getSqlTimestamp(long ts) {
    if (ts <= 0) {
      return null;
    } else {
      return getSqlTimestamp(ts, "yyyy-MM-dd HH:mm:ss");
    }
  }

  /**
   * Creates a date from String
   * 
   * @param stringDate date String value
   * @param format date format
   * @return Date value
   */
  public static Date dateFromString(String stringDate, String format) throws ParseException {
    if (isNotEmptyOrSpace(stringDate)) {
      SimpleDateFormat form = new SimpleDateFormat(format);

      return form.parse(stringDate);
    } else {
      return null;
    }
  }

  public static String stringFromDate(Date date, String format) {
    SimpleDateFormat form = new SimpleDateFormat(format);
    return form.format(date);
  }
  
  /**
   * verify if a string is convertable into double
   * 
   * @param str
   * @return
   */
  public static boolean isNumeric(String str)  
  {  
    try  
    {  
      @SuppressWarnings("unused")
      double d = Double.parseDouble(str);  
    }  
    catch(NumberFormatException nfe)  
    {  
      return false;  
    }  
    return true;  
  }
  /**
   * verify if a string is convertable into integer
   * 
   * @param str
   * @return
   */
  public static boolean isParsableToInt(String str)  
  {  
    try  
    {  
      @SuppressWarnings("unused")
      Integer d = Integer.parseInt(str);  
    }  
    catch(NumberFormatException nfe)  
    {  
      return false;  
    }  
    return true;  
  }
  
  /**
   * check if now we are between 15h and 18h (crenau bhc)
   * 
   * @param timeStampnow
   * @return
   * @throws ParseException
   */
    public static boolean inCreneau(String timeStampnow) throws ParseException {
      SimpleDateFormat parser = new SimpleDateFormat("HH:mm");
      Date creneaubegin = parser.parse("15:05");
      Date creneauend = parser.parse("18:00");
      Date now = parser.parse(timeStampnow);
      return (now.after(creneaubegin) && now.before(creneauend));
    }

  /********************************************************************
   * XML Utils
   ********************************************************************/

  public static String xmlElementToString(Element node) throws CustomException {
    StringWriter stringWriter = new StringWriter();
    try {
      Transformer transformer = TransformerFactory.newInstance().newTransformer();
      transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
      transformer.transform(new DOMSource(node), new StreamResult(stringWriter));
    } catch (TransformerException e) {
      throw new CustomException(" xml format exception : " + e.getMessage());
    }

    return stringWriter.toString();
  }

  public static String xmlElementGetValue(Element e, String node) {
    if (e.getElementsByTagName(node).getLength() == 1) {
      return e.getElementsByTagName(node).item(0).getTextContent();
    } else {
      return "";
    }
  }

  /********************************************************************
   * INITIALIZATIONS
   ********************************************************************/

  /**
   * Initialize transcode map values
   */
  public static HashMap<String, String> createTranscoder() {
    HashMap<String, String> t = new HashMap<String, String>();

    t.put("EENVO", "ENVOYE");
    t.put("ENENV", "NON_ENVOYE");
    t.put("EHBOU", "HARDBOUNCE");
    t.put("ESBOU", "SOFTBOUNCE");
    t.put("EHBIC", "HARDBOUNCE - ADRESSE INCONNUE");
    t.put("ESBDI", "DOMAINE INVALIDE");
    t.put("ESBDS", "DNS INVALIDE");
    t.put("ESBEL", "ERREUR DE RELAI");
    t.put("ESBBP", "BOITE PLEINE");
    t.put("ESBSP", "SPAM FILTER");
    t.put("ESBER", "ERREUR RESEAU");
    t.put("ESBES", "ERREUR SYNTAXE");
    t.put("ESBEG", "ERREUR GENERALE");
    t.put("EOUVR", "OUVERT");
    t.put("EOPTO", "DESABONNE");
    t.put("SOFT_BOUNCE", "SOFTBOUNCE");
    t.put("HARD_BOUNCE", "HARDBOUNCE");
    t.put("SPAM", "SPAM");
    t.put("OPENED", "OUVERT");
    t.put("OPTOUT", "DESABONNE");
    t.put("CLICK", "CLICK");
    t.put("SMS_ERR_RECIPIENT_PORTABILITY", "SOFTBOUNCE");
    t.put("MMS_ERR_RECIPIENT_PORTABILITY", "SOFTBOUNCE");
    t.put("SVI_ERR_ERROR_ANSWERPHONE_OUTCALL", "SOFTBOUNCE");
    t.put("SMS_ERR_GATEWAY_REJECT", "SOFTBOUNCE");
    t.put("SVI_ERR_GATEWAY_REJECT", "SOFTBOUNCE");
    t.put("EMA_ERR_GATEWAY_REJECT", "SOFTBOUNCE");
    t.put("FAX_ERR_GATEWAY_REJECT", "SOFTBOUNCE");
    t.put("SMA_ERR_GATEWAY_REJECT", "SOFTBOUNCE");
    t.put("MMS_ERR_GATEWAY_REJECT", "SOFTBOUNCE");
    t.put("SMS_ERR_RECIPIENT_REJECT", "SOFTBOUNCE");
    t.put("SVI_ERR_RECIPIENT_REJECT", "SOFTBOUNCE");
    t.put("EMA_ERR_RECIPIENT_REJECT", "SOFTBOUNCE");
    t.put("FAX_ERR_RECIPIENT_REJECT", "SOFTBOUNCE");
    t.put("SMA_ERR_RECIPIENT_REJECT", "SOFTBOUNCE");
    t.put("MMS_ERR_RECIPIENT_REJECT", "SOFTBOUNCE");
    t.put("SMS_ERR_RECIPIENT_UNREACHABLE", "SOFTBOUNCE");
    t.put("SVI_ERR_RECIPIENT_UNREACHABLE", "SOFTBOUNCE");
    t.put("EMA_ERR_RECIPIENT_UNREACHABLE", "SOFTBOUNCE");
    t.put("FAX_ERR_RECIPIENT_UNREACHABLE", "SOFTBOUNCE");
    t.put("SMA_ERR_RECIPIENT_UNREACHABLE", "SOFTBOUNCE");
    t.put("MMS_ERR_RECIPIENT_UNREACHABLE", "SOFTBOUNCE");
    t.put("SMS_ERR_RECIPIENT_DOES_NOT_EXIST", "HARDBOUNCE");
    t.put("SVI_ERR_RECIPIENT_DOES_NOT_EXIST", "HARDBOUNCE");
    t.put("EMA_ERR_RECIPIENT_DOES_NOT_EXIST", "HARDBOUNCE");
    t.put("FAX_ERR_RECIPIENT_DOES_NOT_EXIST", "HARDBOUNCE");
    t.put("SMA_ERR_RECIPIENT_DOES_NOT_EXIST", "HARDBOUNCE");
    t.put("MMS_ERR_RECIPIENT_DOES_NOT_EXIST", "HARDBOUNCE");
    t.put("SMS_ERR_GATEWAY_NETWORK_ERROR", "SOFTBOUNCE");
    t.put("SVI_ERR_GATEWAY_NETWORK_ERROR", "SOFTBOUNCE");
    t.put("EMA_ERR_GATEWAY_NETWORK_ERROR", "SOFTBOUNCE");
    t.put("FAX_ERR_GATEWAY_NETWORK_ERROR", "SOFTBOUNCE");
    t.put("SMA_ERR_GATEWAY_NETWORK_ERROR", "SOFTBOUNCE");
    t.put("MMS_ERR_GATEWAY_NETWORK_ERROR", "SOFTBOUNCE");
    t.put("SMS_ERR_GATEWAY_INTERNAL_ERROR", "SOFTBOUNCE");
    t.put("SVI_ERR_GATEWAY_INTERNAL_ERROR", "SOFTBOUNCE");
    t.put("EMA_ERR_GATEWAY_INTERNAL_ERROR", "SOFTBOUNCE");
    t.put("FAX_ERR_GATEWAY_INTERNAL_ERROR", "SOFTBOUNCE");
    t.put("SMA_ERR_GATEWAY_INTERNAL_ERROR", "SOFTBOUNCE");
    t.put("MMS_ERR_GATEWAY_INTERNAL_ERROR", "SOFTBOUNCE");
    t.put("SMS_ERR_DEVICE_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("SVI_ERR_DEVICE_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("EMA_ERR_DEVICE_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("FAX_ERR_DEVICE_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("SMA_ERR_DEVICE_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("MMS_ERR_DEVICE_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("SMS_ERR_OPERATOR_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("SVI_ERR_OPERATOR_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("EMA_ERR_OPERATOR_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("FAX_ERR_OPERATOR_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("SMA_ERR_OPERATOR_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("MMS_ERR_OPERATOR_UNKNOWN_ERROR", "SOFTBOUNCE");
    t.put("SMS_ERR_RECIPIENT_OTHER", "SOFTBOUNCE");
    t.put("SVI_ERR_RECIPIENT_OTHER", "SOFTBOUNCE");
    t.put("EMA_ERR_RECIPIENT_OTHER", "SOFTBOUNCE");
    t.put("FAX_ERR_RECIPIENT_OTHER", "SOFTBOUNCE");
    t.put("SMA_ERR_RECIPIENT_OTHER", "SOFTBOUNCE");
    t.put("MMS_ERR_RECIPIENT_OTHER", "SOFTBOUNCE");
    t.put("SMS_ERR_NO_FINAL_NOTIF", "SOFTBOUNCE");
    t.put("SVI_ERR_NO_FINAL_NOTIF", "SOFTBOUNCE");
    t.put("EMA_ERR_NO_FINAL_NOTIF", "SOFTBOUNCE");
    t.put("FAX_ERR_NO_FINAL_NOTIF", "SOFTBOUNCE");
    t.put("SMA_ERR_NO_FINAL_NOTIF", "SOFTBOUNCE");
    t.put("MMS_ERR_NO_FINAL_NOTIF", "SOFTBOUNCE");
    t.put("CENVO", "ENVOYE");
    t.put("CNENV", "NON_ENVOYE");
    t.put("CNPAI", "NPAI");
    t.put("CVALI", "ADRESSE_VALIDE");
    t.put("CCOUP", "COUPON_RETOURNE");
    t.put("CCOUN", "COUPON_NON_TRAITABLE");
    t.put("COPTO", "DESABONNE");
    t.put("UNKNOWN", "AUTRE");
    t.put("GAME_CONSOLE", "CONSOLE JEU");
    t.put("DMR", "MEDIACENTER");
    t.put("MOBILE", "MOBILE");
    t.put("WEARABLE", "MONTRE");
    t.put("COMPUTER", "ORDINATEUR");
    t.put("TABLET", "TABLETTE");
    t.put("Other", "AUTRE");
    t.put("Console", "CONSOLE JEU");
    t.put("Smartphone", "MOBILE");
    t.put("PC/Mac", "ORDINATEUR");
    t.put("Server", "SERVEUR");
    t.put("Tablette", "TABLETTE");

    return t;
  }
  
  /********************************************************************
   * TAR.GZ and ZIP FILE
   * @throws CustomException 
   ********************************************************************/
  
  public static List<String> getTarGzContent(PortableDataStream pds){
    List<String> a=new ArrayList<>();
    TarArchiveInputStream tarInput=null;
    TarArchiveEntry currentEntry = null;
    try{
     tarInput = new TarArchiveInputStream(new GzipCompressorInputStream(pds.open()));
      while ((currentEntry=tarInput.getNextTarEntry()) != null) {
        a.add(currentEntry.getName());
      }
      tarInput.close();
    }catch(IOException e){
//      throw new CustomException(" n'est un tar.gz file: " + e.getMessage() +" : "+ pds.getPath());
      a.add(pds.getPath()); // add filename if can't be decompressed
    }
    

      return a;
  }

  public static List<String> getZipContent(PortableDataStream pds){
    List<String> a=new ArrayList<>();
    ZipInputStream zis=null;
    ZipEntry entry = null;
   
    try {
    zis = new ZipInputStream(pds.open());
      while((entry=zis.getNextEntry())!=null){
         a.add(entry.getName());
       }
      zis.close();

    } catch (IOException e) {
//      throw new CustomException(" n'est un zip file: " + e.getMessage() +" : "+ pds.getPath());
      a.add(pds.getPath()); // add filename if can't be decompressed
    }
    return a;
  }

  /**
   * decompress tar.gz or zip file to dir
   * 
   * @param inputDir
   * @param outputDir
   */
  public static void decompress(String inputDir,String outputDir){
    ApplicationContext context = ApplicationContext.getInstance();
    HdfsConnector hdfs = context.getHdfs();
    String[] streamFolders = inputDir.split(";", -1);
    String temporaryFolder = outputDir;

    for (int i = 0; i < streamFolders.length; i++) {
      String dir = streamFolders[i];

      System.out.println(dir);
//      hdfs.setFileNamePatterns(context.getProperty(Constants.PROPERTIES_APPLICATION_ARCHIVAGE).split(";", -1));
      try {
        hdfs.uncompressDirFiles(dir, temporaryFolder,"");
      } catch (IOException | ConnectorException e) {
        e.printStackTrace();
//        logger.error(Constants.ERROR_HDFS, "unable to finish uncompression : " + e.getMessage());
      }
    }

    context.closeContext();
  }
  // ---------------------------------------------------------------------------------------
  // DATA MEMBERS
  // ---------------------------------------------------------------------------------------
  private static final HashMap<String, String> TRANSCODER = createTranscoder();
}
