package fr.edf.dco.contacts.bhc.entities.contact.targeting;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Element;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;
import fr.edf.dco.contacts.bhc.entities.cartography.Cartography;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;

/**
 * Targeting Contact records abstraction
 * 
 * @author ahmed-externe.dridi@edf.fr
 */
public abstract class TargetingRecord extends AbstractContactRecord {

  public TargetingRecord(String file, String separator, String contactStream, int fieldsCount, String header, boolean isArchived) {
    super(file, separator, Constants.CONTACT_TYPE_SORTANT, contactStream, fieldsCount, header, isArchived);
  }

  protected void archive() throws IOException {
    // override if archive is needed
  }

  protected void loadCartography() throws CustomException {
    setCartography();

    if (targetingLine.cartography != null) {
      line.template = buildTemplate(targetingLine.cartography.getTemplate());
      line.strategy = buildStrategy(targetingLine.cartography.getStrategy());
    }

    line.contactInformation = buildContactInformation();
    line.chanel = buildChanel();
  }
  
  /**
   * get all champs_source and its position number if code_regroupement matches in bhc_param_alim
   * 
   * @param fields
   * @return Map
   * @throws CustomException
   */
  protected Map<String,String> loadBhcParamAlim(String [] fields) throws CustomException {
    ResultSet result = ApplicationContext.getInstance().getBhcParamAlim();
    Map<String,String> hm = new HashMap<String,String>();
    try {
      while(result.next()){
        if(result.getString(2).equals(line.groupCode)){
          if(Utils.isNotEmptyOrSpace(result.getString(7)) && Utils.isParsableToInt(result.getString(5)) && ((Integer.parseInt(result.getString(5))-1) <= fields.length) )
          hm.put(result.getString(7),fields[Integer.parseInt(result.getString(5))]);
        }
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return hm;
   
  }
  
  /**
   * get all champs_source and its position number if code_regroupement matches in bhc_param_alim for inc insert facture xml
   * 
   * @param fields
   * @return Map
   * @throws CustomException
   */
  protected Map<String,String> loadBhcParamAlimForInca(Element identificationData,Element incaData) throws CustomException {
    ResultSet result = ApplicationContext.getInstance().getBhcParamAlim();
    Map<String,String> hm = new HashMap<String,String>();
    try {
      while(result.next()){
        if(result.getString(2).equals(line.groupCode)){
//          DONNEES_IDENTIFICATION ou DONNEES_INCA
          String champs = result.getString(5);
          String champshbase = result.getString(7);
          String[] tab = champs.split(";",-1);
          if(result.getString(4).equals("XML")){
            if(tab[0].equals("DONNEES_IDENTIFICATION"))
              hm.put(champshbase, Utils.xmlElementGetValue(identificationData, tab[1]));
            else if(tab[0].contains("DONNEES_INCA"))
              hm.put(champshbase, Utils.xmlElementGetValue(incaData, tab[1]));
            }
          }
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return hm;
  }

  protected void setCartography() throws CustomException {
    Set<Cartography> cartographies = ApplicationContext.getInstance().getCartography().get(line.groupCode);
    Iterator<Cartography> iterator = cartographies.iterator();

    while (iterator.hasNext()) {
      targetingLine.cartography = iterator.next();
      break;
    }
  }

  protected String buildAdress() {
    String result = targetingLine.adress1 + ',' + targetingLine.adress2 + ',' + targetingLine.adress3 + ',' + targetingLine.adress4 + ',' + targetingLine.adress5 + ',' + targetingLine.adress6 + ',' + targetingLine.adress7;

    while (result.contains(",,")) {
      result = result.replace(",,", ",");
    }

    if (result.endsWith(",")) {
      result = result.substring(0, result.length() - 1);
    }

    return result;
  }

  protected String buildTemplate(String temp) {
    String result = "";

    if (temp != null && temp != "") {
      String[] fields = temp.split(";");
      ArrayList<String> list = new ArrayList<String>();

      for (String field : fields) {
        if (field.contains("SMS") && Utils.isNotEmptyOrSpace(targetingLine.mobilePhone)) {
          list.add(field.trim());
        }

        if ((field.contains("EMAIL")) && Utils.isNotEmptyOrSpace(targetingLine.email)) {
          list.add(field.trim());
        }

        if (field.contains("VOCAL") && (Utils.isNotEmptyOrSpace(targetingLine.homePhone) || Utils.isNotEmptyOrSpace(targetingLine.workPhone))) {
          list.add(field.trim());
        }

        if (field.contains("COURRIER") && targetingLine.adressOk && (Utils.isNotEmptyOrSpace(targetingLine.adress))) {
          list.add(field.trim());
        }
      }

      for (String field : list) {
        if (result != "") {
          result = result.concat(";");
        }

        result = result.concat(field.trim());
      }

      if (result == "") {
        result = line.groupCode + "_" + Constants.CONTACT_CANAL_NO_COORD;
      }
    }

    return result;
  }

  protected String buildStrategy(String strat) {
    String result = "";

    if ((strat != null) && (strat != "")) {
      String[] fields = strat.split(";");
      ArrayList<String> list = new ArrayList<String>();

      for (String field : fields) {
        if ("SMS".equals(field.trim()) && Utils.isNotEmptyOrSpace(targetingLine.mobilePhone)) {
          list.add(field.trim());
        }

        if ("EMAIL".equals(field.trim()) && Utils.isNotEmptyOrSpace(targetingLine.email)) {
          list.add(field.trim());
        }

        if ("PUSH_VOCAL".equals(field.trim()) && (Utils.isNotEmptyOrSpace(targetingLine.homePhone) || Utils.isNotEmptyOrSpace(targetingLine.workPhone))) {
          list.add(field.trim());
        }

        if ("COURRIER".equals(field.trim()) && (Utils.isNotEmptyOrSpace(targetingLine.adress)) && targetingLine.adressOk) {
          list.add(field.trim());
        }
      }

      for (String field : list) {
        if (result != "") {
          result = result.concat(";");
        }

        result = result.concat(field.trim());
      }
    }

    return result;
  }

  protected String buildContactInformation() {
    String information = "";

    if (line.strategy != null) {
      String[] fields = line.strategy.split(";");

      for (String field : fields) {
        if (!information.equals("")) {
          information = information.concat(";");
        }

        if (field.contains("EMAIL")) {
          information = information.concat(targetingLine.email);
        }

        if (field.contains("SMS")) {
          information = information.concat(targetingLine.mobilePhone);
        }

        if (field.contains("COURRIER")) {
          information = information.concat(targetingLine.adress);
        }

        if (field.contains("VOCAL")) {
          if (targetingLine.homePhone != null && targetingLine.homePhone != "") {
            information = information.concat(targetingLine.homePhone);
          } else {
            information = information.concat(targetingLine.workPhone);
          }
        }
      }
    }

    return information;
  }

  protected String buildChanel() {
    String result = "";

    if (line.strategy != null) {
      if (line.strategy.contains(";")) {
        result = Constants.CONTACT_CANAL_MULTI;
      } else {
        if (line.strategy.contains("SMS")) {
          result = Constants.CONTACT_CANAL_SMS;
        } else if (line.strategy.contains("EMAIL")) {
          result = Constants.CONTACT_CANAL_EMAIL;
        } else if (line.strategy.contains("VOCAL")) {
          result = Constants.CONTACT_CANAL_PUSH_VOCAL;
        } else if (line.strategy.contains("COURRIER")) {
          result = Constants.CONTACT_CANAL_COURRIER;
        }
      }

      if (result == "") {
        result = Constants.CONTACT_CANAL_NO_COORD;
      }
    }

    return result;
  }

  public void storeToHbase() throws IOException {
    if (line.communicationID != null && !targetingLine.temoin) {

      line.put = Utils.getContactPut(line.communicationID);
      line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_ciblage"), Utils.getBytes(line.raw));
      line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source"), Utils.getBytes(fileName));

      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_bp"), Utils.getBytes(line.businessPartner));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_pdl"), Utils.getBytes(targetingLine.deliveryPoint));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_accord_co"), Utils.getBytes(targetingLine.comAgree));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_num_fact"), Utils.getBytes(targetingLine.billNumber));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_date"), Utils.getBytes(targetingLine.targetingDate));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_code_regroupement"), Utils.getBytes(line.groupCode));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_template"), Utils.getBytes(line.template));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_strategie"), Utils.getBytes(line.strategy));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_coordonnees"), Utils.getBytes(line.contactInformation));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_canal"), Utils.getBytes(line.chanel));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_code_traitement"), Utils.getBytes(line.processCode));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_region"), Utils.getBytes(targetingLine.region));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_local"), Utils.getBytes(targetingLine.local));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), Utils.getLongTimestamp(targetingLine.targetingDate, "dd/MM/yyyy HH:mm:ss"), Utils.getBytes(line.status));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_type_nenv"), Utils.getBytes(line.noSendType));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_type"), Utils.getBytes(contactType));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_flux"), Utils.getBytes(contactStream));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_email_pj"), Utils.getBytes(Boolean.toString(targetingLine.emailIsAttachement)));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_outil_source"), Utils.getBytes(targetingLine.sourceTool));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_chaine_envoi"), Utils.getBytes(targetingLine.sendChanel));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_acteur_source"), Utils.getBytes(targetingLine.sourceActor));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_doc"), Utils.getBytes(targetingLine.documentRef));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_taille_message"), Utils.getBytes(targetingLine.messageSize));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_nb_pages"), Utils.getBytes(targetingLine.pageNumber));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_url_archive"), Utils.getBytes(targetingLine.urlArchive));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), Utils.getBytes(targetingLine.market));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_contrat"), Utils.getBytes(targetingLine.contract));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ma_id_dvs"), Utils.getBytes(targetingLine.quotation));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ma_ref_pf"), Utils.getBytes(targetingLine.pfRef));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ma_id_flx"), Utils.getBytes(targetingLine.felix));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ma_ref_cco"), Utils.getBytes(targetingLine.account));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ma_cco_ctr"), Utils.getBytes(targetingLine.contractAccount));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ma_pf_part"), Utils.getBytes(targetingLine.partnerAccount));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ma_ref_int"), Utils.getBytes(targetingLine.intRef));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ma_ref_dem"), Utils.getBytes(targetingLine.request));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ma_ref_aff"), Utils.getBytes(targetingLine.businessRef));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_id_pli"), Utils.getBytes(targetingLine.idPli));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_phy1"), Utils.getBytes(targetingLine.insertPhy1));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_phy2"), Utils.getBytes(targetingLine.insertPhy2));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_phy3"), Utils.getBytes(targetingLine.insertPhy3));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_phy4"), Utils.getBytes(targetingLine.insertPhy4));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_phy5"), Utils.getBytes(targetingLine.insertPhy5));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_phy6"), Utils.getBytes(targetingLine.insertPhy6));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_log1"), Utils.getBytes(targetingLine.insertLog1));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_log2"), Utils.getBytes(targetingLine.insertLog2));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_log3"), Utils.getBytes(targetingLine.insertLog3));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_log4"), Utils.getBytes(targetingLine.insertLog4));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_log5"), Utils.getBytes(targetingLine.insertLog5));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_log6"), Utils.getBytes(targetingLine.insertLog6));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_log7"), Utils.getBytes(targetingLine.insertLog7));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_log8"), Utils.getBytes(targetingLine.insertLog8));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_log9"), Utils.getBytes(targetingLine.insertLog9));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_log10"), Utils.getBytes(targetingLine.insertLog10));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_num_dossier"), Utils.getBytes(targetingLine.fileNumber));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_nom_partenaire"), Utils.getBytes(targetingLine.partnerName));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_priorite"), Utils.getBytes(targetingLine.priority));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_debut_validite"), Utils.getBytes(targetingLine.startValidity));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_fin_validite"), Utils.getBytes(targetingLine.endValidity));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_mkt_log"), Utils.getBytes(targetingLine.insertLog));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_mkt_phy"), Utils.getBytes(targetingLine.insertPhy));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_type_energie"), Utils.getBytes(targetingLine.typeEnergy));
    
      
      // add content of HashMap loaded from bhcparamalim
      if(!targetingLine.hm.isEmpty()){
      for (Map.Entry<String, String> entry : targetingLine.hm.entrySet()) {
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(entry.getKey()), Utils.getBytes(entry.getValue()));
      }
      }

    }
  }

  public Cartography getCartography() {
    return targetingLine.cartography;
  }

  public String getGroupCode() {
    return line.groupCode;
  }

  protected class TargetingLine {

    protected Cartography cartography; // Cartography
    protected boolean temoin = false;
    protected String local; // C_LOCAL
    protected String deliveryPoint; // C_PDL
    protected String comAgree; // C_ACCORD_CO
    protected String billNumber; // Bill Number
    protected String targetingDate; // C_DATE
    protected String targetingDateBase; // DATE FROM FILE NAME
    protected String homePhone; // Phone number for vocal push
    protected String workPhone; // Second phone number for vocal push
    protected String mobilePhone; // Mobile phone number for sms
    protected String email; // Email adress
    protected boolean emailIsAttachement;
    protected String sourceTool;
    protected String sendChanel;
    protected String sourceActor;
    protected String documentRef;
    protected String messageSize;
    protected String pageNumber;
    protected String urlArchive;
    protected String market;
    protected String contract;
    protected String quotation;
    protected String pfRef;
    protected String felix;
    protected String account;
    protected String contractAccount;
    protected String partnerAccount;
    protected String intRef;
    protected String request;
    protected String businessRef;
    protected String region;
    protected String adress1;
    protected String adress2;
    protected String adress3;
    protected String adress4;
    protected String adress5;
    protected String adress6;
    protected String adress7;
    protected String adress8;
    protected String adress9;
    protected String adress10;
    protected String eanCode;
    protected String adress; // Postal adress
    protected boolean adressOk = true;
    protected String idPli;
    protected String insertPhy1;
    protected String insertPhy2;
    protected String insertPhy3;
    protected String insertPhy4;
    protected String insertPhy5;
    protected String insertPhy6;
    protected String insertLog1;
    protected String insertLog2;
    protected String insertLog3;
    protected String insertLog4;
    protected String insertLog5;
    protected String insertLog6;
    protected String insertLog7;
    protected String insertLog8;
    protected String insertLog9;
    protected String insertLog10;
    protected String fileNumber;
    protected String partnerName;
    protected String priority;
    protected String startValidity;
    protected String endValidity;
    protected String insertPhy;
    protected String insertLog;
    protected String typeEnergy;
    
    protected Map<String,String> hm = new HashMap<String,String>();
  }

  protected TargetingLine targetingLine;
}