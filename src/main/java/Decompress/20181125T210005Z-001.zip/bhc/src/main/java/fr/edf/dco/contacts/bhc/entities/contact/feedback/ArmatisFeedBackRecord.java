package fr.edf.dco.contacts.bhc.entities.contact.feedback;

import java.io.IOException;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * Armatis FEA feed back contact Record
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class ArmatisFeedBackRecord extends FeedBackRecord {

  // -------------------------------------------------------------------
  // CONSTRUCTORS
  // -------------------------------------------------------------------

  public ArmatisFeedBackRecord(String file, String type) {
    super(file, "\\|", type, 27, Constants.CONTACT_HEADER_ARMATIS_FEED_BACK, false);
    trialId = 11;
  }

  // -------------------------------------------------------------------
  // IMPLENTATION
  // -------------------------------------------------------------------

  @Override
  protected void process(String[] fields) throws CustomException {
    String sendHour = null;
    String statusHour = null;

    if (fields[11].trim().equals("00:00:00")) {
      sendHour = "00:05:00";
    } else {
      sendHour = fields[11].trim();
    }

    sendDate = Utils.getLongTimestamp(fields[10].trim() + " " + sendHour, "yyyyMMdd HH:mm:ss");
    line.chanel = fields[5].trim();
    line.template = fields[4].trim() + "_" + line.chanel;

    if (contactStream.equals(Constants.CONTACT_STREAM_ARMATIS_DPNR)) {
      line.communicationID = "ARMMM" + fields[16].trim() + "DPNR" + fields[10].trim();
    } else if (contactStream.equals(Constants.CONTACT_STREAM_ARMATIS_FEA)) {
      line.communicationID = "ARMMM" + fields[16].trim() + "FEA" + fields[10].trim();
      line.template = line.template.replace("CIBLE", "FACTU_ELEVEE");
    } else {
      throw new CustomException("Unable To find Armatis Feed Back Type : " + contactStream);
    }

    sendStatus = Constants.CONTACT_STATUS_ENVOYE;

    if (fields[11].trim().equals("00:00:00")) {
      statusHour = "00:10:00";
    } else {
      statusHour = fields[11].trim();
    }

    statusDate = Utils.getLongTimestamp(fields[14].trim() + " " + statusHour, "yyyyMMdd HH:mm:ss");
    resultStatus = Utils.transcode(fields[12].trim());
    statusDetail = fields[13].trim();
    line.contactInformation = fields[6].trim();
  }

  @Override
  public void storeToHbase() throws IOException {
    if (Utils.isNotEmptyOrSpace(line.communicationID)) {
      String initial = "t_" + trialId + "_";

      line.put = Utils.getContactPut(line.communicationID);
      
      line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), sendDate, Utils.getBytes(line.raw));
      line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), sendDate, Utils.getBytes(fileName));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), sendDate, Utils.getBytes(Constants.CONTACT_MARKET_MM));

      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "template"), Utils.getBytes(line.template));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "canal"), Utils.getBytes(line.chanel));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "coordonnee"), Utils.getBytes(line.contactInformation));

      if (sendDate != 0) {
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "statut_envoi"), sendDate, Utils.getBytes(sendStatus));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), sendDate, Utils.getBytes(sendStatus));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_type_nenv"), Utils.getBytes(""));

        if (!Utils.valueAlreadyExists(line.communicationID, String.valueOf(trialId), "S", "a_tentative")) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_tentative"), sendDate, Utils.getBytes(Integer.toString(trialId)));
        }
      }

      if (statusDate != 0) {
        if (resultStatus.equals(Constants.CONTACT_STATUS_SOFTBOUNCE) || resultStatus.equals(Constants.CONTACT_STATUS_HARDBOUNCE) || resultStatus.equals(Constants.CONTACT_STATUS_SPAM)) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "resultat_envoi"), statusDate, Utils.getBytes(resultStatus));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), statusDate, Utils.getBytes(resultStatus));
        } else if (resultStatus.equals(Constants.CONTACT_STATUS_OUVERT)) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), statusDate, Utils.getBytes(Constants.CONTACT_STATUS_OPEN));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), statusDate, Utils.getBytes(resultStatus));
        } else if (resultStatus.equals(Constants.CONTACT_STATUS_OPTOUT)) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), statusDate, Utils.getBytes(Constants.CONTACT_STATUS_OPTOUT));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "optout"), statusDate, Utils.getBytes(resultStatus));
        } else if (resultStatus.equals(Constants.CONTACT_STATUS_CLICK)) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), statusDate, Utils.getBytes(Constants.CONTACT_STATUS_CLIC));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction_clic_url"), statusDate, Utils.getBytes(statusDetail));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction_clic_liburl"), statusDate, Utils.getBytes(statusDetail));
        }
      }
    }
  }

  // -------------------------------------------------------------------
  // DATA MEMBERS
  // -------------------------------------------------------------------

  private long sendDate;
  private String sendStatus;
  private long statusDate;
  private String resultStatus;
  private String statusDetail;
}
