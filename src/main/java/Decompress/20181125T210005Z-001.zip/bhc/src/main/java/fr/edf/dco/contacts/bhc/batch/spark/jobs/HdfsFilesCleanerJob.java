package fr.edf.dco.contacts.bhc.batch.spark.jobs;


import org.apache.hadoop.fs.Path;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.VoidFunction;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.common.connector.hadoop.HdfsConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import scala.Tuple2;

/**
 * Clean hdfs files containing invalid line breakers for AWL
 * 
 * @author ahmed-externe.dridi@edf.fr
 *
 */
public class HdfsFilesCleanerJob {

  public static void main(String[] args) {

    // Defining spark application
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HDFS_CLEANER);
    @SuppressWarnings("resource")
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);

    JavaPairRDD<String, String> filesRDD = sparkContext.wholeTextFiles("/user/dco_app_bhc/workretourtmp")
        .filter(new Function<Tuple2<String, String>, Boolean>() {

          @Override
          public Boolean call(Tuple2<String, String> line) throws Exception {
            return line._1().contains(Constants.CONTACT_FILE_AWL_MESSAGES_RECEIVED)
                || line._1().contains(Constants.CONTACT_FILE_AWL_MESSAGES_SENT);
          }

          private static final long serialVersionUID = 2470843582804459195L;
        });

    filesRDD.foreach(new VoidFunction<Tuple2<String, String>>() {

      @Override
      public void call(Tuple2<String, String> entryfile) throws Exception {
        HdfsConnector hdfs = ApplicationContext.getInstance().getHdfs();
        int fieldsCount = 0;
        String path = entryfile._1();

        if (path.contains(Constants.CONTACT_FILE_AWL_MESSAGES_SENT)) {
          fieldsCount = 17;
        } else if (path.contains(Constants.CONTACT_FILE_AWL_MESSAGES_RECEIVED)) {
          fieldsCount = 9;
        } else {
          throw new CustomException("INVALID FILE NAME");
        }

        String[] oldLines = entryfile._2().split("\r", -1);
        int j = 0;
        String newLines = "";
        while (j < oldLines.length && oldLines[j] != null) {
          String l1 = oldLines[j].replaceAll("\n", "");
//          il ya des ligne qui continnent ; dans les sms
          while ((j < oldLines.length - 1) && ((l1.split("\";\"")).length < fieldsCount) ) {
            l1 = (l1 + oldLines[++j]);
          }
          newLines = newLines + l1 + "\r";
          j++;
        }
        hdfs.deleteFile(new Path(path));
        hdfs.appendToFile(path , newLines);
        

      }

      private static final long serialVersionUID = -1873877989454733669L;
    });
    sparkContext.stop();
  }

}
