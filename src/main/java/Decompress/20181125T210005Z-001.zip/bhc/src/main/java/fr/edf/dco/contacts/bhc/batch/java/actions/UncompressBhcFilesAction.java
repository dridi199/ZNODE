package fr.edf.dco.contacts.bhc.batch.java.actions;

import java.io.IOException;

import fr.edf.com.dacc.HDFSLogger;
import fr.edf.dco.common.connector.base.ConnectorException;
import fr.edf.dco.common.connector.hadoop.HdfsConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;

/**
 * Bhc Workflow Preparation Step : Uncompressing targz and zip files
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class UncompressBhcFilesAction {

  public static void main(String[] args) {
    ApplicationContext context = ApplicationContext.getInstance();
    HdfsConnector hdfs = context.getHdfs();
    HDFSLogger logger = context.getLogger(UncompressBhcFilesAction.class, Constants.CONTACT_PROCESS_GOLABAL);
    String[] streamFolders = "/user/dco_app_bhc/FilesNotProcessed/archiveToBackup/".split(";", -1);
    String temporaryFolder = "/user/dco_app_bhc/FilesNotProcessed/tmp/";

    for (int i = 0; i < streamFolders.length; i++) {
      String dir = streamFolders[i];

      System.out.println(dir);
//      hdfs.setFileNamePatterns(context.getProperty(Constants.PROPERTIES_APPLICATION_CONTACTS_FILES).split(";", -1));
      try {
        hdfs.uncompressDirFiles(dir, temporaryFolder,"/user/dco_app_bhc/FilesNotProcessed/NotDecompressed/");
//        System.out.println("here");
      } catch (IOException | ConnectorException e) {
        e.printStackTrace();
        logger.error(Constants.ERROR_HDFS, "unable to finish uncompression : " + e.getMessage());
      }
    }

    context.closeContext();
  }
}
