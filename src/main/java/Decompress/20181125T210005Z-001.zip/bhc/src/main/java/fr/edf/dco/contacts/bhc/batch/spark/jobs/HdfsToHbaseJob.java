package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.io.StringReader;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.base.Utils;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;
import scala.Tuple2;

/**
 * An ETL spark job where extraction is based on a HDFS directory,
 * transformation on an Abstract factory and loading on HBASE tables
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class HdfsToHbaseJob {

  public static void main(String[] args) {
    // Instantiating environment settings
    ApplicationContext context = ApplicationContext.getInstance();

    // Defining spark application
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HDFS_HBASE);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);

    // creating RDD from HDFS
    JavaPairRDD<String, String> filesRDD = sparkContext.wholeTextFiles(context.getProperty(Constants.PROPERTIES_HDFS_WORK_DIR), new Integer(context.getProperty(Constants.PROPERTIES_SPARK_CONTACTS_PARTITIONS)).intValue());

    // writing to hbase
    filesRDD.foreachPartition(new VoidFunction<Iterator<Tuple2<String, String>>>() {

      @Override
      public void call(Iterator<Tuple2<String, String>> files) throws Exception {
        ApplicationContext context = ApplicationContext.getInstance();
        ContactFactory factory = new ContactFactory();
        AbstractContactRecord record = null;

        Tuple2<String, String> file = null;
        String fileName = null;
        String[] lines = null;
        NodeList xmlNodes = null;

        while (files.hasNext()) {
          file = files.next();
          fileName = file._1;

          try {
            record = factory.createRecord(fileName);
          } catch (CustomException e) {
            // do nothing
          }

          if (fileName.contains("xml")) {
            xmlNodes = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(file._2))).getElementsByTagName(record.getXmlNodesTag());

            for (int i = 0; i < xmlNodes.getLength(); i++) {
              try {
                record.parse(Utils.xmlElementToString((Element) xmlNodes.item(i)));
                record.storeToHbase();
              } catch (Exception e) {
                // do nothing
              }
            }
          } else {
            lines = file._2.split("\\n", -1);

            for (String line : lines) {
              try {
                record.parse(line);
                record.storeToHbase();
              } catch (Exception e) {
                // do nothing
              }
            }
          }
        }

        context.flushContacts(true);
      }

      private static final long serialVersionUID = -6327199749951900949L;
    });

    sparkContext.close();
  }
}
