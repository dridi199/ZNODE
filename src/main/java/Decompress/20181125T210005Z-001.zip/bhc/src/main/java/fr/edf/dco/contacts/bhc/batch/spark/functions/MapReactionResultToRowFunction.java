package fr.edf.dco.contacts.bhc.batch.spark.functions;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NavigableMap;

import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import fr.edf.dco.contacts.bhc.base.Utils;

public class MapReactionResultToRowFunction implements FlatMapFunction<Result, Row> {

  // ------------------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------------------

  @Override
  public Iterable<Row> call(Result result) throws Exception {
    List<Row> list = new ArrayList<Row>();
    String id = Bytes.toString(result.getRow());
    NavigableMap<byte[], NavigableMap<Long, byte[]>> mapWithTimestamp = result.getMap().get(Utils.getBytes("S"));

    List<Cell> trials = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_tentative"));

    if (trials.size() > 0) {
      String trialId = null;
      String device = null;
      String os = null;
      String osVersion = null;
      String browser = null;
      String browserVersion = null;

      
   
      for (Cell trialCell : trials) {
        trialId = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(trialCell)));
        
        device = "";
        os = "";
        osVersion = "";
        browser = "";
        browserVersion = "";
        
        String flux = null;
        List<Cell> cf = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("c_flux"));
        String c= null;
        for (Cell f : cf) {
          c = Bytes.toString(CellUtil.cloneValue(f));
          if (Utils.isNotEmptyOrSpace(c)) {
            flux = c;
            break;
          }
        }
        String marche = null;
        List<Cell> cm = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"));
        String m= null;
        for (Cell mt : cm) {
          m = Bytes.toString(CellUtil.cloneValue(mt));
          if (Utils.isNotEmptyOrSpace(m)) {
            marche = m;
            break;
          }
        }

        String reaction = "";
        Timestamp reactionDate = new Timestamp(0);
        String url = "";
        String raisondesabo = "";

        List<Cell> openCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_reaction"));
        if (openCells.size() > 0) {
          for (Cell openCell : openCells) {
            reaction = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(openCell)));
            long currentTimestamp = openCell.getTimestamp();
            if (reaction.equals("OUVERT")) {
              if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device"))!=null)
              device=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device")).get(currentTimestamp)));
              if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois"))!=null)
              os=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois")).get(currentTimestamp)));
              if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois_version"))!=null)
              osVersion=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois_version")).get(currentTimestamp)));
              if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser"))!=null)
              browser=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser")).get(currentTimestamp)));
              if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser_version"))!=null)
              browserVersion=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser_version")).get(currentTimestamp)));
              reactionDate = Utils.getSqlTimestamp(currentTimestamp);
              list.add(RowFactory.create(id + "_" + trialId, reaction, reactionDate, url, device, os, osVersion, browser, browserVersion, new Timestamp(new Date().getTime()),flux,marche,raisondesabo));
            }
          }
        }
        device = "";
        os = "";
        osVersion = "";
        browser = "";
        browserVersion = "";

        List<Cell> clickCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_reaction_clic_url"));
        if (clickCells.size() > 0) {
          for (Cell clickCell : clickCells) {
            long currentTimestamp = clickCell.getTimestamp();
            reaction = "CLIC";
            reactionDate = Utils.getSqlTimestamp(clickCell.getTimestamp());
            url = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(clickCell)));
            
                if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device"))!=null)
                device=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device")).get(currentTimestamp)));
                if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois"))!=null)
                os=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois")).get(currentTimestamp)));
                if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois_version"))!=null)
                osVersion=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois_version")).get(currentTimestamp)));
                if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser"))!=null)
                browser=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser")).get(currentTimestamp)));
                if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser_version"))!=null)
                browserVersion=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser_version")).get(currentTimestamp)));
               
                
           
                list.add(RowFactory.create(id + "_" + trialId, reaction, reactionDate, url, device, os, osVersion, browser, browserVersion, new Timestamp(new Date().getTime()),flux,marche,raisondesabo));
          }
        }
        
        device = "";
        os = "";
        osVersion = "";
        browser = "";
        browserVersion = "";
        url = "";

        List<Cell> optoutCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_optout"));

        if (optoutCells.size() > 0) {
          for (Cell optoutCell : optoutCells) {
            reaction = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(optoutCell)));
            reactionDate = Utils.getSqlTimestamp(optoutCell.getTimestamp());
            raisondesabo = Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_optout_detail"))); // on a une seule version dans hbase
            
            list.add(RowFactory.create(id + "_" + trialId, reaction, reactionDate, url, device, os, osVersion, browser, browserVersion, new Timestamp(new Date().getTime()),flux,marche,raisondesabo));
          }
        }

        List<Cell> mirrorCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_mirror"));
        raisondesabo="";
        
        if (mirrorCells.size() > 0) {
          for (Cell mirrorCell : mirrorCells) {
            long currentTimestamp = mirrorCell.getTimestamp();
            reaction = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(mirrorCell)));
            reactionDate = Utils.getSqlTimestamp(mirrorCell.getTimestamp());
              if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device"))!=null)
              device=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device")).get(currentTimestamp)));
              if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois"))!=null)
              os=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois")).get(currentTimestamp)));
              if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois_version"))!=null)
              osVersion=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_ois_version")).get(currentTimestamp)));
              if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser"))!=null)
              browser=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser")).get(currentTimestamp)));
              if(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser_version"))!=null)
              browserVersion=Utils.getEmptyIfNull(Bytes.toString(mapWithTimestamp.get(Utils.getBytes("t_" + trialId + "_device_browser_version")).get(currentTimestamp)));

            list.add(RowFactory.create(id + "_" + trialId, reaction, reactionDate, url, device, os, osVersion, browser, browserVersion, new Timestamp(new Date().getTime()),flux,marche,raisondesabo));
          }
        }
        
      
      }
    }

    return list;
  }

  // ------------------------------------------------------------------------------
  // DATA MEMEBERS
  // ------------------------------------------------------------------------------

  private static final long serialVersionUID = -8612486796252609130L;

  public final StructType REACTION_SCHEMA_SQL = new StructType(new StructField[] {
      new StructField("ID_TENTATIVE", DataTypes.StringType, true, Metadata.empty()),
      new StructField("LIB_TYPE_REACTION", DataTypes.StringType, true, Metadata.empty()),
      new StructField("DATE_REACTION", DataTypes.TimestampType, true, Metadata.empty()),
      new StructField("LIB_URL", DataTypes.StringType, true, Metadata.empty()),
      new StructField("LIB_DEVICE", DataTypes.StringType, true, Metadata.empty()),
      new StructField("LIB_OS", DataTypes.StringType, true, Metadata.empty()),
      new StructField("VERSION_OS", DataTypes.StringType, true, Metadata.empty()),
      new StructField("LIB_BROWSER", DataTypes.StringType, true, Metadata.empty()),
      new StructField("VERSION_BROWSER", DataTypes.StringType, true, Metadata.empty()),
      new StructField("DATE_INSERTION", DataTypes.TimestampType, true, Metadata.empty()),
      new StructField("FLUX", DataTypes.StringType, true, Metadata.empty()),
      new StructField("MARCHE", DataTypes.StringType, true, Metadata.empty()),
      new StructField("RAISON_DESABO", DataTypes.StringType, true, Metadata.empty())
  });
}
