package fr.edf.dco.contacts.bhc.batch.spark.functions;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import fr.edf.dco.contacts.bhc.base.Utils;

public class MapEditicResultToRowFunction implements Function<Result, Row> {

  // ------------------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------------------

  @Override
  public Row call(Result result) throws Exception {
    String id = Utils.getEmptyIfNull(Bytes.toString(result.getRow()));
    String statut = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("a_statut"))));

    List<Cell> cells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_statut"));
    long ts = 0;
    for (Cell cell : cells) {
      if (cell.getTimestamp() > ts) {
        ts = cell.getTimestamp();
      }
    }

    Timestamp dateStatut = new Timestamp(ts);
//    Date date = new Date(dateStatut.getTime());
    String source = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("B"), Utils.getBytes("source"))));
    List<Cell> cs = result.getColumnCells(Utils.getBytes("B"), Utils.getBytes("source_retour"));
    String source_retour = null;
    String v = null;
    for (Cell c : cs) {
      v = Bytes.toString(CellUtil.cloneValue(c));
      if (Utils.isNotEmptyOrSpace(v)) {
        source_retour = v;
        break;
      }
    }
    
   
    
    return RowFactory.create(1,id,new Timestamp(new Date().getTime()), statut, dateStatut,source,source_retour);
  }

  // ------------------------------------------------------------------------------
  // DATA MEMEBERS
  // ------------------------------------------------------------------------------

  private static final long serialVersionUID = 3502180062965228839L;
 

  
  
  public final StructType EDITIC_SCHEMA_ORACLE = new StructType(new StructField[] {
      new StructField("ID_FLUX", DataTypes.IntegerType, true, Metadata.empty()),
      new StructField("ID_TECH", DataTypes.StringType, true, Metadata.empty()),
      new StructField("D_INSERT", DataTypes.TimestampType, true, Metadata.empty()),
      new StructField("CTCSTATUS", DataTypes.StringType, true, Metadata.empty()),
      new StructField("STATUSDT", DataTypes.TimestampType, true, Metadata.empty()),
      new StructField("NOM_ARCHIVE_INCA", DataTypes.StringType, true, Metadata.empty()),
      new StructField("NOM_FICHIER_EDITIQUE", DataTypes.StringType, true, Metadata.empty())
  });
}
