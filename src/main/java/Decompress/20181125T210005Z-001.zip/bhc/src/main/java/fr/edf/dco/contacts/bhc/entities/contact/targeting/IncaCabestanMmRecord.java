package fr.edf.dco.contacts.bhc.entities.contact.targeting;

import java.text.ParseException;

import org.apache.commons.lang.StringUtils;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * Inca Cabestan MM targeting contact record
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class IncaCabestanMmRecord extends TargetingRecord {

  // ------------------------------------------------------------------
  // CONSTRUCTOR
  // ------------------------------------------------------------------

  /**
   * Constructs new INCA CABESTAN CIBLAGE MM contact record
   */
  public IncaCabestanMmRecord(String file) {
    super(file, "\\|", Constants.CONTACT_STREAM_INCA_CABESTAN_MM, 32, "ID_TECH", false);
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------

  /**
   * Parsing raw data into record structure
   */
  protected void process(String[] fields) throws CustomException {
    this.targetingLine = new TargetingLine();
    targetingLine.market = Constants.CONTACT_MARKET_MM;

    line.communicationID = fields[0].trim();

    if (!line.communicationID.startsWith("MM")) {
      throw new CustomException("Invalid Inca Cabestan Row Key : " + line.communicationID);
    }

    targetingLine.email = fields[1].trim();
    line.businessPartner = fields[3].trim();
    line.processCode = fields[2].trim();
    targetingLine.local = fields[6].trim().equals("0") ? "" : fields[6].trim();
    line.groupCode = fileName.substring(StringUtils.ordinalIndexOf(fileName, "_", 7) + 1, StringUtils.ordinalIndexOf(fileName, "_", 8));

    targetingLine.targetingDateBase = fileName.substring(fileName.indexOf(".txt") - 8, fileName.indexOf(".txt"));

    try {
      targetingLine.targetingDate = Utils.formatDate(targetingLine.targetingDateBase, "yyyyMMdd", "dd/MM/yyyy HH:mm:ss");
    } catch (ParseException e) {
      throw new CustomException("could not parse date : " + targetingLine.targetingDate + " from yyyyMMdd to dd/MM/yyyy HH:mm:ss format");
    }

    loadCartography();
    targetingLine.hm = loadBhcParamAlim(fields);
    line.status = Constants.CONTACT_STATUS_TRANSMIS;
  }

}
