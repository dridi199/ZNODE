package fr.edf.dco.contacts.bhc.batch.spark.jobs.fix;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.IteratorUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.VoidFunction;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;
import scala.Tuple2;

public class HbasePostInitJob {

  public static void main(String[] args) {

    // getting environment context
    ApplicationContext app = ApplicationContext.getInstance();
    HbaseConnector hbase = app.getHbase();

    // configuring HBASE
    Configuration hbaseConfiguration = hbase.getConfiguration();
    hbaseConfiguration.set(TableInputFormat.SCAN_MAXVERSIONS, "100");
    hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, app.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));

    // spark application settings
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HBASE_HIVE);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);

    // creating RDD from HBASE tables
    JavaPairRDD<ImmutableBytesWritable, Result> hbaseRDD = sparkContext.newAPIHadoopRDD(hbaseConfiguration, TableInputFormat.class, ImmutableBytesWritable.class, Result.class);

    // insert missing values
    JavaRDD<Put> putsRDD = hbaseRDD.mapPartitions(new FlatMapFunction<Iterator<Tuple2<ImmutableBytesWritable, Result>>, Put>() {

      private static final long serialVersionUID = -9172223650101169251L;

      @SuppressWarnings("deprecation")
      @Override
      public Iterable<Put> call(Iterator<Tuple2<ImmutableBytesWritable, Result>> rows) throws Exception {
        this.puts = new ArrayList<Put>();
        this.insertsToUpdate = new HashMap<String, Long>();

        Result row = null;
        List<Cell> trials = null;
        List<Cell> statusCells = null;
        List<Cell> lines = null;
        String template = null;
        String coordonnes = null;
        String canal = null;
        String flux = null;
        String status = null;
        ArrayList<String> inserts = null;
        Put p = null;

        while (rows.hasNext()) {
          row = rows.next()._2();
          flux = Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes("c_flux"))));

          if (flux.equals(Constants.CONTACT_STREAM_INCA_CABESTAN_MM) || flux.equals(Constants.CONTACT_STREAM_INCA_EMISSAIRES_MM) || flux.equals(Constants.CONTACT_STREAM_EDITIC) || flux.equals(Constants.CONTACT_STREAM_INCA_INSERT)) {
            if (flux.equals(Constants.CONTACT_STREAM_INCA_INSERT)) {
              p = new Put(row.getRow());

              lines = row.getColumnCells(Utils.getBytes("B"), Utils.getBytes("ligne_ciblage"));
              if (lines.size() > 0) {
                for (Cell lineCell : lines) {
                  if (Bytes.toString(CellUtil.cloneValue(lineCell)).contains("SUPPRESSION")) {
                    Date date = Utils.getValueTimestamp(Bytes.toString(row.getRow()), "S", "a_statut", "TRANSMIS_SIMM");

                    if (date != null) {
                      date.setSeconds(date.getSeconds() + 5);
                      String stringDate = Utils.stringFromDate(date, "dd/MM/yyyy HH:mm:ss");
                      p.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), Utils.getLongTimestamp(stringDate, "dd/MM/yyyy HH:mm:ss"), Utils.getBytes(Constants.CONTACT_STATUS_ABANDONED));
                    } else {
                      throw new CustomException("Could not get TRANSMIS_SIMM status timestamp for key : " + Bytes.toString(row.getRow()));
                    }
                  }
                }
              }

              if (insertsToUpdate.containsKey(Bytes.toString(row.getRow()))) {
                if (!Utils.isNotEmptyOrSpace(Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes("t_11_template")))))) {
                  template = Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes("c_template"))));
                  p.addColumn(Utils.getBytes("S"), Utils.getBytes("t_11_template"), insertsToUpdate.get(Bytes.toString(row.getRow())), Utils.getBytes(template));
                }

                if (!Utils.isNotEmptyOrSpace(Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes("t_11_canal")))))) {
                  canal = Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes("c_canal"))));
                  p.addColumn(Utils.getBytes("S"), Utils.getBytes("t_11_canal"), insertsToUpdate.get(Bytes.toString(row.getRow())), Utils.getBytes(canal));
                }
              }
            }

            trials = row.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_tentative"));

            if (trials.size() > 0) {
              String initial = null;
              p = new Put(row.getRow());

              for (Cell trialCell : trials) {
                initial = "t_" + Bytes.toString(CellUtil.cloneValue(trialCell)) + "_";

                if (!Utils.isNotEmptyOrSpace(Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes(initial + "template")))))) {
                  template = Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes("c_template"))));
                  p.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "template"), trialCell.getTimestamp(), Utils.getBytes(template));
                }

                if (flux.equals(Constants.CONTACT_STREAM_INCA_CABESTAN_MM) || flux.equals(Constants.CONTACT_STREAM_INCA_EMISSAIRES_MM)) {
                  if (!Utils.isNotEmptyOrSpace(Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes(initial + "coordonnee")))))) {
                    coordonnes = Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes("c_coordonnees"))));
                    p.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "coordonnee"), trialCell.getTimestamp(), Utils.getBytes(coordonnes));
                  }
                }

                if (flux.equals(Constants.CONTACT_STREAM_EDITIC) || flux.equals(Constants.CONTACT_STREAM_INCA_INSERT)) {
                  if (!Utils.isNotEmptyOrSpace(Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes(initial + "canal")))))) {
                    canal = Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes("c_canal"))));
                    p.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "canal"), trialCell.getTimestamp(), Utils.getBytes(canal));
                  }

                  // updating insert rows
                  if (flux.equals(Constants.CONTACT_STREAM_EDITIC)) {
                    inserts = new ArrayList<String>();
                    inserts.add(Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes(("c_ref_insert_log1"))))));
                    inserts.add(Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes(("c_ref_insert_log2"))))));
                    inserts.add(Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes(("c_ref_insert_log3"))))));
                    inserts.add(Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes(("c_ref_insert_log4"))))));
                    inserts.add(Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes(("c_ref_insert_log5"))))));
                    inserts.add(Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes(("c_ref_insert_log6"))))));

                    statusCells = row.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_status"));
                    for (Cell statusCell : statusCells) {
                      status = Bytes.toString(CellUtil.cloneValue(statusCell));

                      if (!status.equals(Constants.CONTACT_STATUS_TRANSMIS)) {
                        break;
                      }
                    }

                    updateInca(inserts, trialCell.getTimestamp(), Bytes.toString(CellUtil.cloneValue(trialCell)), Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("B"), Utils.getBytes(("ligne_retour"))))), Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("B"), Utils.getBytes(("source_retour"))))), status);
                  }
                }
              }

              if (!p.isEmpty()) {
                this.puts.add(p);
              }
            }
          }
        }

        return this.puts;
      }

      private void updateInca(ArrayList<String> inserts, long ts, String trialId, String raw, String fileName, String status) {
        Put p = null;

        for (String insert : inserts) {
          if (Utils.isNotEmptyOrSpace(insert)) {
            String[] fields = insert.split(";", -1);

            if (fields.length == 3 && Utils.isNotEmptyOrSpace(fields[2]) && !fields[1].contains("0")) {
              String idTech = fields[2];

              p = new Put(Utils.getBytes(idTech));
              insertsToUpdate.put(idTech, ts);

              p.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), ts, Utils.getBytes(raw));
              p.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), ts, Utils.getBytes(fileName));
              p.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), ts, Utils.getBytes(Constants.CONTACT_MARKET_MM));

              if (status.equals(Constants.CONTACT_STATUS_RAW_ABANDONED)) {
                p.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), ts, Utils.getBytes(Constants.CONTACT_STATUS_NON_ENVOYE));
              } else if (status.equals(Constants.CONTACT_STATUS_ENVOYE)) {
                p.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), ts, Utils.getBytes(Constants.CONTACT_STATUS_ENVOYE));
                p.addColumn(Utils.getBytes("S"), Utils.getBytes("a_tentative"), ts, Utils.getBytes(trialId));
                p.addColumn(Utils.getBytes("S"), Utils.getBytes("t_11_statut_envoi"), ts, Utils.getBytes(Constants.CONTACT_STATUS_ENVOYE));
              }
            }
          }

          if (!p.isEmpty()) {
            this.puts.add(p);
          }
        }
      }

      private List<Put> puts;
      private Map<String, Long> insertsToUpdate;
    });

    putsRDD.foreachPartition(new VoidFunction<Iterator<Put>>() {

      private static final long serialVersionUID = -2242133943222001948L;

      @SuppressWarnings("unchecked")
      @Override
      public void call(Iterator<Put> t) throws Exception {
        ApplicationContext context = ApplicationContext.getInstance();
        HbaseConnector hbase = context.getHbase();
        hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
        hbase.multiPut(IteratorUtils.toList(t));
      }
    });

    sparkContext.close();
  }
}
