package fr.edf.dco.contacts.bhc.entities.contact.targeting;

import java.text.ParseException;
import java.util.Iterator;
import java.util.Set;

import org.apache.hadoop.hbase.client.Put;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;
import fr.edf.dco.contacts.bhc.entities.cartography.Cartography;

/**
 * EDITIC targeting record representation
 * 
 * @author fahd-externe.essid@edf.fr
 *
 */
public class EditicTargetingRecord extends TargetingRecord {

  // ------------------------------------------------------------------
  // CONSTRUCTOR
  // ------------------------------------------------------------------

  /**
   * Constructs new Editic targeting record
   * 
   * @param file
   */
  public EditicTargetingRecord(String file) {
    super(file, "\\|", Constants.CONTACT_STREAM_EDITIC, 59, "ID_CONTACT", false);
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------

  @Override
  protected void process(String[] fields) throws CustomException {
    this.targetingLine = new TargetingLine();

    line.communicationID = fields[0].trim();

    if (line.communicationID.startsWith("TIC_") || !line.communicationID.startsWith("TIC")) {
      throw new CustomException("invalid communication id : " + line.communicationID);
    }

    line.status = Constants.CONTACT_STATUS_TRANSMIS;

    targetingLine.targetingDateBase = fields[2].trim();

    if (!Utils.isNotEmptyOrSpace(targetingLine.targetingDateBase)) {
      if (line.communicationID.length() >= 14) {
        targetingLine.targetingDateBase = line.communicationID.substring(6, 14);
      } else {
        throw new CustomException("invalid communication id : " + line.communicationID);
      }

      try {
        targetingLine.targetingDate = Utils.formatDate(targetingLine.targetingDateBase, "yyyyMMdd", "dd/MM/yyyy HH:mm:ss");
      } catch (ParseException e) {
        throw new CustomException("could not parse date : " + targetingLine.targetingDate + " from yyyyMMdd to dd/MM/yyyy HH:mm:ss format");
      }
    } else {
      try {
        targetingLine.targetingDate = Utils.formatDate(targetingLine.targetingDateBase, "yyyy-MM-dd'T'HH-mm-ss", "dd/MM/yyyy HH:mm:ss");
      } catch (ParseException e) {
        throw new CustomException("could not parse date : " + targetingLine.targetingDate + " from yyyy-MM-dd'T'HH-mm-ss to dd/MM/yyyy HH:mm:ss format");
      }
    }

    line.chanel = fields[3].trim();
    targetingLine.emailIsAttachement = Utils.getBoolean(fields[4].trim());
    targetingLine.email = fields[5].trim();
    targetingLine.mobilePhone = fields[6].trim();

    if (!Utils.isNotEmptyOrSpace(targetingLine.mobilePhone) && fields[7].trim().startsWith("06")) {
      targetingLine.mobilePhone = fields[7].trim();
    }

    targetingLine.adress1 = fields[8].trim();
    targetingLine.adress2 = fields[9].trim();
    targetingLine.adress3 = fields[10].trim();
    targetingLine.adress4 = fields[11].trim();
    targetingLine.adress5 = fields[12].trim();
    targetingLine.adress6 = fields[13].trim();
    targetingLine.adress7 = fields[14].trim();
    targetingLine.adress = buildAdress();

    targetingLine.eanCode = fields[15].trim();
    targetingLine.sourceTool = fields[16].trim();
    targetingLine.sendChanel = fields[17].trim();
    targetingLine.sourceActor = fields[18].trim();
    line.groupCode = fields[19].trim();
    targetingLine.documentRef = fields[20].trim();
    targetingLine.messageSize = fields[21].trim();
    targetingLine.pageNumber = fields[22].trim();
    targetingLine.urlArchive = fields[23].trim();
    targetingLine.market = fields[24].trim();
    targetingLine.idPli = fields[25].trim();

    targetingLine.insertPhy1 = fields[26].trim();
    targetingLine.insertPhy2 = fields[27].trim();
    targetingLine.insertPhy3 = fields[28].trim();
    targetingLine.insertPhy4 = fields[29].trim();
    targetingLine.insertPhy5 = fields[30].trim();
    targetingLine.insertPhy6 = fields[31].trim();

    targetingLine.insertLog1 = fields[32].trim();
    targetingLine.insertLog2 = fields[33].trim();
    targetingLine.insertLog3 = fields[34].trim();
    targetingLine.insertLog4 = fields[35].trim();
    targetingLine.insertLog5 = fields[36].trim();
    targetingLine.insertLog6 = fields[37].trim();

    if (targetingLine.market.equals(Constants.CONTACT_MARKET_MM)) {
      targetingLine.deliveryPoint = fields[38].trim();
      line.businessPartner = fields[39].trim();
      targetingLine.comAgree = fields[40].trim();
      targetingLine.contract = fields[41].trim();
      targetingLine.local = fields[42].trim();
    } else if (targetingLine.market.equals(Constants.CONTACT_MARKET_MA)) {
      targetingLine.deliveryPoint = fields[43].trim();
      targetingLine.quotation = fields[44].trim();
      targetingLine.pfRef = fields[45].trim();
      targetingLine.felix = fields[46].trim();
      targetingLine.account = fields[47].trim();
      targetingLine.contractAccount = fields[48].trim();
      targetingLine.partnerAccount = fields[49].trim();
      targetingLine.intRef = fields[50].trim();
      targetingLine.request = fields[51].trim();
      targetingLine.businessRef = fields[52].trim();
    }

    targetingLine.fileNumber = fields[53].trim();
    targetingLine.partnerName = fields[54].trim();
    targetingLine.typeEnergy =  fields[55].trim();
    
		if (fields.length > 56) {
			targetingLine.insertLog7 = fields[56].trim();
			targetingLine.insertLog8 = fields[57].trim();
			targetingLine.insertLog9 = fields[58].trim();
			targetingLine.insertLog10 = fields[59].trim();
		}
    loadCartography();
    targetingLine.hm = loadBhcParamAlim(fields);
    updateInca();
  }

  private void updateInca() {
    doUpdateInca(targetingLine.insertLog1);
    doUpdateInca(targetingLine.insertLog2);
    doUpdateInca(targetingLine.insertLog3);
    doUpdateInca(targetingLine.insertLog4);
    doUpdateInca(targetingLine.insertLog5);
    doUpdateInca(targetingLine.insertLog6);
    doUpdateInca(targetingLine.insertLog7);
    doUpdateInca(targetingLine.insertLog8);
    doUpdateInca(targetingLine.insertLog9);
    doUpdateInca(targetingLine.insertLog10);
  }

  private void doUpdateInca(String insert) {
    if (Utils.isNotEmptyOrSpace(insert)) {
      String[] fields = insert.split(",|;", -1);

      if (fields.length == 3 && Utils.isNotEmptyOrSpace(fields[2])) {
        Put p = Utils.getContactPut(fields[2]);
        long ts = Utils.getLongTimestamp(targetingLine.targetingDate, "dd/MM/yyyy HH:mm:ss");

        if (fields[1].contains("0")) {
          p.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), ts, Utils.getBytes(Constants.CONTACT_STATUS_UNPRIORITIZED));
        } else if (fields[1].contains("1")) {
          p.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), ts, Utils.getBytes(Constants.CONTACT_STATUS_TRANSMIS));
        }
        
        p.addColumn(Utils.getBytes("S"), Utils.getBytes("c_code_regroupement_editic"), ts, Utils.getBytes(line.groupCode));
        p.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), ts, Utils.getBytes(targetingLine.market));

        p.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), ts, Utils.getBytes(line.raw));
        p.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), ts, Utils.getBytes(fileName));
      }
    }
  }

  @Override
  protected void setCartography() throws CustomException {
    Set<Cartography> cartographies = ApplicationContext.getInstance().getCartography().get(line.groupCode);
    Iterator<Cartography> iterator = cartographies.iterator();

    while (iterator.hasNext()) {
      Cartography entry = iterator.next();
      if (entry.getStrategy().contains(line.chanel)) {
        targetingLine.cartography = entry;
        break;
      }
    }
  }

  @Override
  protected void loadCartography() throws CustomException {
    setCartography();

    if (targetingLine.cartography != null) {
      if (Utils.isNotEmptyOrSpace(targetingLine.email) && (line.chanel.equals(Constants.CONTACT_CANAL_EMAIL))) {
        line.template = targetingLine.cartography.getTemplate();
        line.strategy = targetingLine.cartography.getStrategy();
        line.contactInformation = targetingLine.email;
      } else if (Utils.isNotEmptyOrSpace(targetingLine.mobilePhone) && line.chanel.equals(Constants.CONTACT_CANAL_SMS)) {
        line.template = targetingLine.cartography.getTemplate();
        line.strategy = targetingLine.cartography.getStrategy();
        line.contactInformation = targetingLine.mobilePhone;
      } else if (Utils.isNotEmptyOrSpace(targetingLine.adress) && (!targetingLine.adress.equals(Constants.CONTACT_DEFAULT_NULL_ADDRESS)) && (line.chanel.equals(Constants.CONTACT_CANAL_COURRIER) || line.chanel.equals(Constants.CONTACT_CANAL_IMPLOC))) {
        line.template = targetingLine.cartography.getTemplate();
        line.strategy = targetingLine.cartography.getStrategy();
        line.contactInformation = targetingLine.adress;
      } else if (Utils.isNotEmptyOrSpace(targetingLine.eanCode) && line.chanel.equals(Constants.CONTACT_CANAL_EDI)) {
        line.template = targetingLine.cartography.getTemplate();
        line.strategy = targetingLine.cartography.getStrategy();
        line.contactInformation = targetingLine.eanCode;
      } else {
        line.chanel = Constants.CONTACT_CANAL_NO_COORD;
        line.template = line.groupCode + "_" + Constants.CONTACT_CANAL_NO_COORD;
      }
    } else {
      if (Utils.isNotEmptyOrSpace(targetingLine.email) && (line.chanel.equals(Constants.CONTACT_CANAL_EMAIL))) {
        line.contactInformation = targetingLine.email;
      } else if (Utils.isNotEmptyOrSpace(targetingLine.mobilePhone) && line.chanel.equals(Constants.CONTACT_CANAL_SMS)) {
        line.contactInformation = targetingLine.mobilePhone;
      } else if (Utils.isNotEmptyOrSpace(targetingLine.adress) && (!targetingLine.adress.equals(Constants.CONTACT_DEFAULT_NULL_ADDRESS)) && (line.chanel.equals(Constants.CONTACT_CANAL_COURRIER) || line.chanel.equals(Constants.CONTACT_CANAL_IMPLOC))) {
        line.contactInformation = targetingLine.adress;
      } else if (Utils.isNotEmptyOrSpace(targetingLine.eanCode) && line.chanel.equals(Constants.CONTACT_CANAL_EDI)) {
        line.contactInformation = targetingLine.eanCode;
      }
    }
  }
}