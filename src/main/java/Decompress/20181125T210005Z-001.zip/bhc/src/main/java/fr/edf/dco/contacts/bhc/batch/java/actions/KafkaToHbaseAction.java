package fr.edf.dco.contacts.bhc.batch.java.actions;

import java.io.IOException;

import fr.edf.com.dacc.HDFSLogger;
import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.common.connector.misc.KafkaConnector;
import fr.edf.dco.common.connector.misc.KafkaConnector.KafkaMessage;
import fr.edf.dco.common.factory.AbstractFactory;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;
import kafka.consumer.ConsumerTimeoutException;

/**
 * Storing contacts to habse table
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class KafkaToHbaseAction {

  public static void main(String[] args) {
    ApplicationContext context = ApplicationContext.getInstance();
    String streamTopic = context.getProperty(Constants.PROPERTIES_KAFKA_STREAM_TOPICS);
    KafkaConnector kafka = context.getKafka(streamTopic);
    HDFSLogger logger = context.getLogger(KafkaToHbaseAction.class, Constants.CONTACT_PROCESS_KAFKA_TO_HBASE);

    try {
      readTopic(kafka, logger);
    } catch (ConsumerTimeoutException e) {
      completeJob(context);
    }

    completeJob(context);
  }

  /**
   * Read kafka topic and parse its content
   * 
   * @param kafka
   * @param report
   * @param logger
   * @throws ConsumerTimeoutException
   */
  public static void readTopic(KafkaConnector kafka, HDFSLogger logger) throws ConsumerTimeoutException {
    AbstractFactory factory = new ContactFactory();
    AbstractContactRecord record = null;
    KafkaMessage message = null;

    while ((message = kafka.getKeyedMessage()) != null) {
      try {
        record = (AbstractContactRecord) factory.createRecord(Constants.CONTACT_MESSAGE_EDIWAY_EDIFUZ);
        
      } catch (CustomException e) {
        logger.warn(Constants.WARNING_DATA, "Unknown contacts file : " + Constants.CONTACT_MESSAGE_EDIWAY_EDIFUZ);
        logger.warn(Constants.WARNING_DATA, "Message contacts file : " + message.getMessage());

      }

      if (record != null) {
        try {
          record.parse(message.getMessage());
          record.storeToHbase();
        } catch (IOException e) {
          logger.error(Constants.ERROR_HBASE, "unable to write row to hbase " + e.getMessage());
        } catch (CustomException e) {
          logger.warn(Constants.WARNING_DATA, "Contact line could not be parsed : " + message.getMessage());
        }
      }

    }
  }

  /**
   * Job completion tasks
   */
  public static void completeJob(ApplicationContext context) {
    context.flushContacts(true);
    context.removeDuplicatesFromFile();
    context.closeContext();
  }
}
