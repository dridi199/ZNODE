package fr.edf.dco.contacts.bhc.entities.contact.targeting;

import java.text.ParseException;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * Armatis Dpnr targeting data
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class ArmatisDpnrRecord extends TargetingRecord {

  // ------------------------------------------------------------------
  // CONSTRUCTOR
  // ------------------------------------------------------------------

  /**
   * Constructs new ARMATIS DPNR contact record
   */
  public ArmatisDpnrRecord(String file) {
    super(file, ";", Constants.CONTACT_STREAM_ARMATIS_DPNR, 31, "AdresseSiteInternetEdfPart", false);
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------

  /**
   * Parsing raw data into record structure
   */
  protected void process(String[] fields) throws CustomException {
    this.targetingLine = new TargetingLine();

    targetingLine.market = Constants.CONTACT_MARKET_MM;

    line.businessPartner = fields[4].trim();
    line.groupCode = fileName.substring(fileName.lastIndexOf("_") - 4, fileName.lastIndexOf("_"));

    line.noSendType = fields[30].trim();

    targetingLine.comAgree = fields[22].trim();
    targetingLine.deliveryPoint = fields[25].trim();

    targetingLine.adress1 = fields[11].trim();
    targetingLine.adress2 = fields[12].trim();
    targetingLine.adress3 = fields[13].trim();
    targetingLine.adress4 = fields[14].trim();
    targetingLine.adress5 = fields[15].trim();
    targetingLine.adress6 = fields[16].trim();
    targetingLine.adress7 = fields[17].trim();

    targetingLine.adress = buildAdress();
    targetingLine.adressOk = Utils.isNotEmptyOrSpace(targetingLine.adress1) && Utils.isNotEmptyOrSpace(targetingLine.adress4) && Utils.isNotEmptyOrSpace(targetingLine.adress6);
    targetingLine.email = fields[29].trim();

    targetingLine.targetingDateBase = fileName.substring(fileName.indexOf(".txt") - 8, fileName.indexOf(".txt"));

    try {
      targetingLine.targetingDate = Utils.formatDate(targetingLine.targetingDateBase, "yyyyMMdd", "dd/MM/yyyy HH:mm:ss");
    } catch (ParseException e) {
      throw new CustomException("could not parse date : " + targetingLine.targetingDate + " from yyyyMMdd to dd/MM/yyyy HH:mm:ss format");
    }

    line.communicationID = "ARMMM" + line.businessPartner + line.groupCode + targetingLine.targetingDateBase;

    if (line.noSendType.contains(Constants.CONTACT_ARMATIS_DPNR_CIBLE_COURRIER) || line.noSendType.equals(Constants.CONTACT_ARMATIS_DPNR_CIBLE_EMAIL)) {
      line.status = Constants.CONTACT_STATUS_TRANSMIS;
    } else {
      line.status = Constants.CONTACT_STATUS_NON_ENVOYE;
      if (!Utils.isNotEmptyOrSpace(line.noSendType)) {
        line.noSendType = "NO_TYPE";
      }
    }

    loadCartography();
    targetingLine.hm = loadBhcParamAlim(fields);
  }

  @Override
  protected void loadCartography() throws CustomException {
    super.loadCartography();

    if (line.strategy != null && !line.strategy.isEmpty()) {

      if (line.noSendType.contains("CIBLE_COURRIER")) {
        line.chanel = Constants.CONTACT_CANAL_COURRIER;

        String[] stratFields = line.strategy.split(";");
        for (String s : stratFields) {
          if (s.contains("COURRIER")) {
            line.strategy = s;
          }
        }

        line.noSendType = "";
        line.contactInformation = targetingLine.adress;
      } else if (line.noSendType.contains("CIBLE_EMAIL")) {

        if (targetingLine.adressOk) {
          line.chanel = Constants.CONTACT_CANAL_MULTI;
          line.noSendType = "";
        } else {
          line.chanel = Constants.CONTACT_CANAL_EMAIL;
          String[] stratFields = line.strategy.split(";");
          for (String s : stratFields) {
            if (s.contains("EMAIL")) {
              line.strategy = s;
            }
          }

          String[] tempFields = line.template.split(";");
          for (String t : tempFields) {
            if (t.contains("EMAIL")) {
              line.template = t;
            }
          }

          line.noSendType = "";
          line.contactInformation = targetingLine.email;
        }
      } else {
        line.chanel = Constants.CONTACT_CANAL_NO_COORD;
        line.template = line.groupCode + "_NO_COORD";
        line.strategy = "";
        line.contactInformation = "";
      }
    }
  }
}
