package fr.edf.dco.contacts.bhc.entities.contact.targeting;

import java.text.ParseException;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * Satho actco targeting contact record
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class SathoActcoRecord extends TargetingRecord {

  // ------------------------------------------------------------------
  // CONSTRUCTOR
  // ------------------------------------------------------------------

  /**
   * Constructs new SATHO ACTCO contact record
   */
  public SathoActcoRecord(String file) {
    super(file, ";", Constants.CONTACT_STREAM_SATHO_ACTCO, 8, "NUMERO", false);
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------

  /**
   * Parsing raw data into record structure
   */
  protected void process(String[] fields) throws CustomException {
    this.targetingLine = new TargetingLine();

    targetingLine.market = Constants.CONTACT_MARKET_MM;

    String[] ids = fields[1].split("\\|", -1);

    targetingLine.mobilePhone = fields[0].trim();
    targetingLine.region = ids[2].trim();
    line.businessPartner = ids[8].trim();
    line.groupCode = fields[2].trim();

    targetingLine.targetingDateBase = fileName.substring(fileName.indexOf('.') - 8, fileName.indexOf('.'));

    try {
      targetingLine.targetingDate = Utils.formatDate(targetingLine.targetingDateBase, "yyyyMMdd", "dd/MM/yyyy HH:mm:ss");
    } catch (ParseException e) {
      throw new CustomException("could not parse date : " + targetingLine.targetingDate + " from yyyyMMdd to dd/MM/yyyy HH:mm:ss format");
    }

    line.communicationID = "CRMMM" + line.businessPartner + line.groupCode + targetingLine.targetingDateBase;
    loadCartography();
    targetingLine.hm = loadBhcParamAlim(fields);
    line.status = Constants.CONTACT_STATUS_TRANSMIS;
  }
}
