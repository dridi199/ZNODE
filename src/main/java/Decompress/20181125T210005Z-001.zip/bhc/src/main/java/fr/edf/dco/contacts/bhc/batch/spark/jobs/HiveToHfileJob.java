package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NavigableMap;
import java.util.TreeSet;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.RegionLocator;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.HFileOutputFormat2;
import org.apache.hadoop.mapreduce.Job;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;

import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;
import scala.Tuple2;

public class HiveToHfileJob {

  public static void main(String[] args) {
    // application parameters
    ApplicationContext context = ApplicationContext.getInstance();
    HbaseConnector hbase = context.getHbase();

    final String table = args[0];
    final String separator = args[1];
    final String distributionColumn = args[2];

    // spark application settings
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HIVE_HBASE);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);
    HiveContext hiveContext = new HiveContext(sparkContext);

    // Retrieving Hive table
    JavaRDD<Row> tableContentRDD = hiveContext.sql("select * from " + table + " DISTRIBUTE BY " + distributionColumn).toJavaRDD();

    // hbase key-values
    JavaRDD<KeyValue> hbaseRDD = tableContentRDD.mapPartitions(new FlatMapFunction<Iterator<Row>, KeyValue>() {

      private static final long serialVersionUID = -5844753255324191699L;

      @SuppressWarnings("deprecation")
      @Override
      public Iterable<KeyValue> call(Iterator<Row> rows) throws Exception {
        TreeSet<KeyValue> result = new TreeSet<KeyValue>(KeyValue.COMPARATOR);

        ContactFactory factory = new ContactFactory();
        AbstractContactRecord record = null;

        String line = null;
        Put p = null;
        NavigableMap<byte[], List<KeyValue>> map = null;

        while (rows.hasNext()) {

          try {
            line = rows.next().mkString(separator);
            record = factory.createRecord(line.substring(0, line.indexOf(separator)));

            record.parse(line.substring(line.indexOf(separator) + 1, line.length()));
            record.storeToHbase();
            p = record.getHbasePut();
            if (p != null) {
              map = p.getFamilyMap();
              for (byte[] f : map.keySet()) {
                for (KeyValue kv : map.get(f)) {
                  result.add(kv);
                }
              }
            }
          } catch (Exception e) {
            e.printStackTrace();
          }
        }

        return result;
      }
    });

    // hbase key-values with row keys
    JavaPairRDD<ImmutableBytesWritable, KeyValue> hbaseRDD2 = hbaseRDD.mapPartitionsToPair(new PairFlatMapFunction<Iterator<KeyValue>, ImmutableBytesWritable, KeyValue>() {

      private static final long serialVersionUID = 1801099052030727667L;

      @SuppressWarnings("deprecation")
      @Override
      public Iterable<Tuple2<ImmutableBytesWritable, KeyValue>> call(Iterator<KeyValue> kvs) throws Exception {
        List<Tuple2<ImmutableBytesWritable, KeyValue>> result = new ArrayList<Tuple2<ImmutableBytesWritable, KeyValue>>();

        KeyValue kv = null;
        while (kvs.hasNext()) {
          kv = kvs.next();
          result.add(new Tuple2<ImmutableBytesWritable, KeyValue>(new ImmutableBytesWritable(kv.getRow()), kv));
        }

        return result;
      }
    });

    // creating HFiles
    Configuration hbaseConfiguration = hbase.getConfiguration();

    try {
      Job job = Job.getInstance(hbaseConfiguration);
      Table htable = hbase.getConnection().getTable(TableName.valueOf(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE)));
      RegionLocator regionLocator = hbase.getConnection().getRegionLocator(htable.getName());
      HFileOutputFormat2.configureIncrementalLoad(job, htable, regionLocator);
      hbaseRDD2.saveAsNewAPIHadoopFile(context.getProperty(Constants.PROPERTIES_HFILE_PATH), ImmutableBytesWritable.class, KeyValue.class, HFileOutputFormat2.class, job.getConfiguration());
    } catch (IOException e) {
      e.printStackTrace();
    }

  }
}
