package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.io.IOException;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SaveMode;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.common.connector.jdbc.OracleConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;
import fr.edf.dco.contacts.bhc.batch.spark.functions.MapEditicResultToRowFunction;

/**
 * publie les donnees depuis hbase vers ZE_HADOOP
 * 
 * @author ahmed-externe.dridi@edf.fr
 *
 */
public class HbaseToZEHadoop {

  public static void main(String[] args) throws CustomException {

    // getting environment context
    ApplicationContext context = ApplicationContext.getInstance();
    HbaseConnector hbase = context.getHbase();
      
    // configuring HBASE
    Configuration hbaseConfiguration = hbase.getConfiguration();
    hbaseConfiguration.set(TableInputFormat.SCAN_MAXVERSIONS, "30");
//    hbaseConfiguration.set(TableInputFormat.SCAN_COLUMN_FAMILY, "S");
    hbaseConfiguration.setInt("hbase.rpc.timeout", 24000000);
    hbaseConfiguration.setInt("hbase.client.scanner.timeout.period", 24000000);

    // spark application settings
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HBASE_ORACLE_SERVER);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);
    SQLContext sqlContext = new SQLContext(sparkContext);

    // creating RDD from HBASE tables
    if (args.length>0 && args[0].equals("full")) {
      hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
      hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));   
    } else {
      hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_ZETEMP_TABLE));
      hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_ZETEMP_TABLE));
    }

    // Due to instability in the newAPIHadoopRDD function we will parallelize data from a hbase Java API Scan
    JavaRDD<Result> hbaseOracleRDD = sparkContext.newAPIHadoopRDD(hbaseConfiguration, TableInputFormat.class, ImmutableBytesWritable.class, Result.class).values();
    
    // Filter flux (INCA_INSERT_MKT)
    hbaseOracleRDD=hbaseOracleRDD.filter(new Function<Result, Boolean>() {
      private static final long serialVersionUID = -8734939700009133492L;

      @Override
      public Boolean call(Result result) throws Exception {
        String flux=Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_flux"))));
        String statut=Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("a_statut"))));
        return (flux!=null && flux.equals("INCA_INSERT_MKT")) && ((statut.equals("ENVOYE") || statut.equals("DEPRIORISE") || statut.equals("NON_ENVOYE")));
      }
    });
    
    OracleConnector oracleConn = null;
    try {
       oracleConn = ApplicationContext.getInstance().getOracleConnector(Constants.PROPERTIES_ORACLE_SERVER_DATABASE,context.getProperty(Constants.PROPERTIES_ORACLE_SERVER_TARGET));
    } catch (CustomException e) {
      e.printStackTrace();
    throw new CustomException("can not  connect to Oracle database : " + context.getProperty(Constants.PROPERTIES_ORACLE_SERVER_DATABASE)) ;
}
    hbaseToOracleServer(oracleConn, hbaseOracleRDD, sqlContext);


    // ------------------------------------------------------------------------------
    // Purging HBase temporary table
    // ------------------------------------------------------------------------------
    if (args.length==0 || !args[0].equals("full")) {
      hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_ZETEMP_TABLE));
      try {
        hbase.truncate();
      } catch (IOException e) {
        e.printStackTrace();
      } 
      
    }

  }

  private static void hbaseToOracleServer(OracleConnector oracleServer, JavaRDD<Result> hbaseRDD, SQLContext sqlContext) {
    ApplicationContext context = ApplicationContext.getInstance();
    Properties oracleServerOptions = new Properties();

    oracleServerOptions.put("driver", oracleServer.getDriverClassName());
    oracleServerOptions.put("url", oracleServer.getConnectionUrl());
    oracleServerOptions.put("user", oracleServer.getUser());
    oracleServerOptions.put("password", oracleServer.getUserPwd());   

    // initializing spark user defined functions
    MapEditicResultToRowFunction targetingFunction = new MapEditicResultToRowFunction();

    // ------------------------------------------------------------------------------
    // Processing Targeting Records
    // ------------------------------------------------------------------------------
    
    // creating RDD of SQLServer rows
    JavaRDD<Row> sqlTargetingRows = hbaseRDD.map(targetingFunction);
    // converting hive rows RDD to data frame
    DataFrame targetingDataFrame = sqlContext.createDataFrame(sqlTargetingRows, targetingFunction.EDITIC_SCHEMA_ORACLE);
    targetingDataFrame.write().mode(SaveMode.Append).jdbc(oracleServer.getConnectionUrl(), context.getProperty(Constants.PROPERTIES_ORACLE_SERVER_EDITIC_TABLE), oracleServerOptions);
  }
  
}
