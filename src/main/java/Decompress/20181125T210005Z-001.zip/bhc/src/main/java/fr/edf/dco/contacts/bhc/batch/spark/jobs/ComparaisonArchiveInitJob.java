package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.fs.Path;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.input.PortableDataStream;

import fr.edf.dco.common.connector.hadoop.HdfsConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Utils;
import scala.Tuple2;

/**
 * trouver les fichier qui ont été archiver mais pas dans l'init
 * @author ahmed-externe.dridi@edf.fr
 *
 */
public class ComparaisonArchiveInitJob {
  public static void main(String[] args) {
   
   
    String date=args[1];
    String yearFolder = date.substring(0,4); // extract year from arg
    SparkConf sparkconfiguration = new SparkConf().setAppName("FileNotProcessedFinder");
    sparkconfiguration.set("spark.hadoop.io.compression.codecs", "org.apache.hadoop.io.compress.GzipCodec");
    JavaSparkContext javaSparkContext = new JavaSparkContext(sparkconfiguration);

    String archiveAWLrouteurs = archiveDir + "routeurs/AWL/";
    String archiveCABESTANrouteurs = archiveDir + "routeurs/CABESTAN/";
    String archiveARMATISrouteurs = archiveDir + "routeurs/ARMATIS/";
    String archiveETLSIMMRetours = archiveDir + "simm/ETL/AWL/";
    String archiveEMISSSAIRESRetours = archiveDir + "routeurs/EMISSAIRES/MM/";

    String archiveAWLciblage = archiveDir + "inca/ciblage/ATOS/MM/";
    String archiveCABESTANciblage = archiveDir + "inca/ciblage/CABESTAN/MM/";
    String archiveETLSIMMciblage = archiveDir + "inca/ciblage/SIMM/";
    String archiveEMISSAIRESciblage = archiveDir + "inca/ciblage/EMISSAIRES/MM/";
    String archiveEDITIC = archiveDir +"editique/EDITIC/";
    
    
    if(args[0].equals("awlRetours") || args[0].equals("all"))
    Compare(archiveAWLrouteurs, "awlRetours", javaSparkContext,date,yearFolder);
    if(args[0].equals("cabestanRetours") || args[0].equals("all"))
    Compare(archiveCABESTANrouteurs, "cabestanRetours", javaSparkContext,date,yearFolder);
    if(args[0].equals("armatis") || args[0].equals("all"))
    Compare(archiveARMATISrouteurs, "armatis", javaSparkContext,date,yearFolder);
    if(args[0].equals("etlsimmRetours") || args[0].equals("all"))
    Compare(archiveETLSIMMRetours, "etlsimmRetours", javaSparkContext,date,yearFolder);
    if(args[0].equals("emissairesRetours") || args[0].equals("all"))
    Compare(archiveEMISSSAIRESRetours, "emissairesRetours", javaSparkContext,date,yearFolder);
//
    if(args[0].equals("awl") || args[0].equals("all"))
    Compare(archiveAWLciblage, "awl", javaSparkContext,date,yearFolder);
    if(args[0].equals("cabestan") || args[0].equals("all"))
    Compare(archiveCABESTANciblage, "cabestan", javaSparkContext,date,yearFolder);
    if(args[0].equals("inca_insert") || args[0].equals("all"))
    Compare(archiveETLSIMMciblage, "inca_insert", javaSparkContext,date,yearFolder);
    if(args[0].equals("emissaires") || args[0].equals("all"))
    Compare(archiveEMISSAIRESciblage, "emissaires", javaSparkContext,date,yearFolder);
    if(args[0].equals("editic") || args[0].equals("all"))
    Compare(archiveEDITIC, "editic", javaSparkContext,date,yearFolder);

}
  

  
  /**
   * Comparer les fichiers archiver
   * et ceux qui existent dans l'init
   * @param archivedir
   * @param fluxname
   * @param javaSparkContext
   * @param d
   */
  public static void Compare(String archivedir, String fluxname, JavaSparkContext javaSparkContext,String d,String folder) {
    ApplicationContext ctx = ApplicationContext.getInstance();
    HdfsConnector hdfs = ctx.getHdfs();
    
    try {
//      hdfs.deleteFolderContent("/user/dco_app_bhc/FilesNotProcessed/archiveToBackup/");
//      hdfs.deleteFolderContent("/user/dco_app_bhc/FilesNotProcessed/tmp/");
      
      if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/" + d)){
        if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/"+d+"/"+ fluxname+"_"+d))
          hdfs.deleteFile(new Path("/user/dco_app_bhc/FilesNotProcessed/historique/"+d+"/"+ fluxname+"_"+d));
      }else{
        hdfs.createDirectory("/user/dco_app_bhc/FilesNotProcessed/historique/" + d);
      }
    } catch (IllegalArgumentException | IOException e) {
      e.printStackTrace();
    } 
    
    //-------------------------------------------------------------------------------------------------------------
    //------------------------------------------------- collect archives and flat files ---------------------------
    //-------------------------------------------------------------------------------------------------------------
    JavaPairRDD<String, String> archive = null;
    if(fluxname.equals("editic"))
      archive = getEditicArchiveAsRDDWithoutDecompress(archivedir, javaSparkContext, d, folder); // special collect for editic (get name from archive)
    else
      archive = getArchiveAsRDD(archivedir, javaSparkContext, d, folder); // collect archives as RDD (archives that's can't retrive fluxname from archivename) 
    
    JavaPairRDD<String, String> flux = getMultiDirfluxAsRDD(fluxname, javaSparkContext, d);
    JavaPairRDD<String, String> rdd = archive.subtractByKey(flux); // comparer les deux rDD

//    String timenow = new SimpleDateFormat("YYYYMMddhhmm").format(Calendar.getInstance().getTime());
    
    // groupe file contained in the same archive (archivename,flux1,flux2,...)
    JavaPairRDD<String, Iterable<String>> rddGrouped = rdd.mapToPair(new PairFunction<Tuple2<String,String>, String, String>() {
      private static final long serialVersionUID = 3871413638868696259L;

      @Override
      public Tuple2<String, String> call(Tuple2<String, String> t) throws Exception {
        return new Tuple2<String, String>(t._2, t._1);
      }
    }).groupByKey();
    
    rddGrouped.foreach(new VoidFunction<Tuple2<String,Iterable<String>>>() {
      private static final long serialVersionUID = -7398508710760555357L;

      @Override
      public void call(Tuple2<String, Iterable<String>> t) throws Exception {
        Utils.copyFile(t._1,"/user/dco_app_bhc/FilesNotProcessed/archiveToBackup/");
      }
    });
    
    rddGrouped.saveAsTextFile("/user/dco_app_bhc/FilesNotProcessed/historique/"+d+"/"+ fluxname+"_"+d);
    
//    Utils.decompress("/user/dco_app_bhc/FilesNotProcessed/archiveToBackup/","/user/dco_app_bhc/FilesNotProcessed/tmp/"); // décompresser les archive sur tmp
  

//    rdd.foreach(new VoidFunction<Tuple2<String, String>>() {
//      private static final long serialVersionUID = -7067237849762217271L;
//
//      @Override
//      public void call(Tuple2<String, String> t) throws Exception {
//        ApplicationContext context = ApplicationContext.getInstance();
//        HdfsConnector hdfs = context.getHdfs();
//        String filename = "";
//
//        if (!t._1.contains(".tar") && !t._1.contains(".zip")) { 
//          if (t._2.contains(".tar.gz")) {
//            filename = "/user/dco_app_bhc/FilesNotProcessed/tmp/"+ t._2.substring(t._2.lastIndexOf("/") + 1, t._2.indexOf(".")) + "targzfile~" + t._1;
//          } else if (t._2.contains(".zip")) {
//            filename = "/user/dco_app_bhc/FilesNotProcessed/tmp/" + t._2.substring(t._2.lastIndexOf("/") + 1, t._2.indexOf(".")) + "zipfile~" + t._1;
//          }
//
//          if (hdfs.exists(filename)) {
//            moveFile(filename, "/user/dco_app_bhc/FilesNotProcessed/filesToReprise/");
//          } 
////          else {
////            hdfs.appendToFile("/user/dco_app_bhc/FilesNotProcessed/NotFound/"+fluxname + "_filesNotFound.txt",filename + " : " + t._2);
////          }
//         } else {// deplacer les archives multicompressé
//          moveFile(t._2, "/user/dco_app_bhc/FilesNotProcessed/MultiCompressedArchive/");
//        }
//      }
//    });
   
  }

/**
 * 
 * @param fluxdir
 * @param javaSparkContext
 * @param separator
 * @param d
 * @return
 */
  public static JavaPairRDD<String, String> getInitFluxAsRDD(String fluxdir, JavaSparkContext javaSparkContext, String separator,String d) {
    return javaSparkContext.wholeTextFiles(initDir + fluxdir)
        .mapToPair(new PairFunction<Tuple2<String, String>, String, String>() {
          private static final long serialVersionUID = -6587643686900977327L;

          @Override
          public Tuple2<String, String> call(Tuple2<String, String> t) throws Exception {
            return new Tuple2<String, String>(t._1().substring(t._1().indexOf(separator) + 1, t._1().indexOf(".") + 3), t._1());
          }
        });
  }

 
  public static JavaPairRDD<String, String> getMultiDirfluxAsRDD(String fluxname, JavaSparkContext javaSparkContext,String d) {
    
    List<String> listdir = new ArrayList<>();
    
    if (fluxname.equals("awlRetours")) {
      listdir.add("awl/messagesReceived");
      listdir.add("awl/messagesSent");
      listdir.add("awl/notifications");
      listdir.add("awl/emailTracking");
    } else if (fluxname.equals("armatis")) {
      listdir.add("armatis/dpnrRetours");
      listdir.add("armatis/feaRetours");
      listdir.add("armatis/dpnr");
      listdir.add("armatis/fea");
    } else if (fluxname.equals("cabestanRetours")) {
      listdir.add("cabestanRetours/mail");
      listdir.add("cabestanRetours/clics");
      listdir.add("cabestanRetours/devices");
    } else if (fluxname.equals("etlsimmRetours")) {
      listdir.add("etlsimm/echea");
      listdir.add("etlsimm/rationalise");
      listdir.add("etlsimm/satho");
    } else if (fluxname.equals("editic")) {
      listdir.add("editic/data");
      listdir.add("editic/acq");
    } else if (fluxname.equals("cabestan")) {
      listdir.add("cabestan");
    } else if (fluxname.equals("emissaires")) {
      listdir.add("emissaires");
    } else if (fluxname.equals("emissairesRetours")) {
      listdir.add("emissairesRetours");
    } else if (fluxname.equals("awl")) {
      listdir.add("awl/inca");
    } else if (fluxname.equals("inca_insert")) {
      listdir.add("inca_insert");
    }
    
    // get all init directorie
    JavaPairRDD<String, String> rdd = javaSparkContext.wholeTextFiles(initDir + listdir.get(0)).filter(new Function<Tuple2<String,String>, Boolean>() {
      private static final long serialVersionUID = -1685854924432799054L;

      @Override
      public Boolean call(Tuple2<String, String> v1) throws Exception {
        return Utils.getAfterDate(d, v1._1);
      }
    });
    for (int i = 1; i < listdir.size(); i++) {
      rdd=rdd.union(javaSparkContext.wholeTextFiles(initDir + listdir.get(i)));
    }

    return rdd.mapToPair(new PairFunction<Tuple2<String, String>, String, String>() {
      private static final long serialVersionUID = -6587643686900977327L;
      @Override
      public Tuple2<String, String> call(Tuple2<String, String> t) throws Exception {
        return new Tuple2<String, String>(t._1().substring(t._1().indexOf(separator) + 1, t._1().indexOf(".") + 4), t._1());
      }
    });
  }
  
  /**
   * get files names from archives without decompressing
   * 
   * @param archivedir
   * @param javaSparkContext
   * @param d
   * @param folder
   * @return
   */

  public static JavaPairRDD<String, String> getArchiveAsRDD(String archivedir, JavaSparkContext javaSparkContext, String d,String folder) {
    // union all folderDate from filterDate to 2017
    int year = Integer.parseInt(folder);
    JavaPairRDD<String, PortableDataStream> firstRdd = javaSparkContext.binaryFiles(archivedir+""+year);
    while(year>2017){
      year = year-1;
      firstRdd=javaSparkContext.binaryFiles(archivedir+""+year).union(firstRdd);
    }
    
    JavaPairRDD<String, String> rdd = firstRdd.filter(new Function<Tuple2<String,PortableDataStream>, Boolean>() {
      private static final long serialVersionUID = -3245521064298368643L;

      @Override
      public Boolean call(Tuple2<String, PortableDataStream> v1) throws Exception {
        if(archivedir.equals(archiveDir + "simm/ETL/AWL/")) // if etlsimmRetours get file 
          return true;
        else
        return  Utils.getAfterDate(d, v1._1);
      }
    }).mapToPair(new PairFunction<Tuple2<String, PortableDataStream>, String, List<String>>() {
          private static final long serialVersionUID = 4962718678631998765L;

          @Override
          public Tuple2<String, List<String>> call(Tuple2<String, PortableDataStream> t) throws Exception {
            if (t._1.contains(".tar.gz"))
              return new Tuple2<String, List<String>>(t._1, Utils.getTarGzContent(t._2));
            else if (t._1.contains(".zip"))
              return new Tuple2<String, List<String>>(t._1, Utils.getZipContent(t._2));
            else return null;
          }
        }).flatMapToPair(new PairFlatMapFunction<Tuple2<String, List<String>>, String, String>() {
          private static final long serialVersionUID = -6311196567237124306L;

          @Override
          public Iterable<Tuple2<String, String>> call(Tuple2<String, List<String>> t) throws Exception {
            List<Tuple2<String, String>> l = new ArrayList<>();
            for (String s : t._2) {
              Tuple2<String, String> tuple = new Tuple2<String, String>(s.substring(0, s.indexOf(".") + 4), t._1);
              if(tuple._1.substring(tuple._1.length()-3,tuple._1.length()).equals("tar")){
                
              }
              l.add(tuple);
            }
            return l;
          }
        }).filter(new Function<Tuple2<String, String>, Boolean>() {
          private static final long serialVersionUID = -8090258799073963290L;

          @Override
          public Boolean call(Tuple2<String, String> v1) throws Exception {
            if(archivedir.equals(archiveDir + "simm/ETL/AWL/")) // if etlsimmRetours get file 
              return  Utils.getAfterDate(d, v1._1) && (!v1._1.contains("EDF_MA") && !v1._1.contains("Followup") && !v1._1.contains("FORM")); // special treatements for etlsimmRetours
            else
            return (!v1._1.contains("EDF_MA") && !v1._1.contains("Followup") && !v1._1.contains("FORM"));
          }
        });
    return rdd;
  }
  
/**
 * special get for editic (extract files names from archives names)
 * 
 * @param archivedir
 * @param javaSparkContext
 * @param d
 * @param folder 
 * @return
 */
  
  public static JavaPairRDD<String, String> getEditicArchiveAsRDDWithoutDecompress(String archivedir, JavaSparkContext javaSparkContext, String d,String folder) {
    // union all folderDate from filterDate to 2017
    int year = Integer.parseInt(folder);
    JavaPairRDD<String, PortableDataStream> firstRdd = javaSparkContext.binaryFiles(archivedir+""+year);
    while(year>2017){
      year = year-1;
      firstRdd=javaSparkContext.binaryFiles(archivedir+""+year).union(firstRdd);
      
    }
    JavaPairRDD<String, String> rdd = firstRdd.filter(new Function<Tuple2<String,PortableDataStream>, Boolean>() {
      private static final long serialVersionUID = -1685854924432799054L;

      @Override
      public Boolean call(Tuple2<String, PortableDataStream> v1) throws Exception {
        return Utils.getAfterDate(d, v1._1);
      }
    }).mapToPair(new PairFunction<Tuple2<String,PortableDataStream>, String, String>() {
      private static final long serialVersionUID = -4319420623894020269L;

      @Override
      public Tuple2<String, String> call(Tuple2<String, PortableDataStream> t) throws Exception {
        return new Tuple2<String, String>(t._1.substring(t._1.lastIndexOf("/")+1,t._1.lastIndexOf(".")-3)+"csv", t._1);
      }
    });
    return rdd;
  }
  

  private static String archiveDir = "/user/dacc/archive/";
  private static String separator = "~";
  private static String initDir = "/user/dco_app_bhc/init/";
}
