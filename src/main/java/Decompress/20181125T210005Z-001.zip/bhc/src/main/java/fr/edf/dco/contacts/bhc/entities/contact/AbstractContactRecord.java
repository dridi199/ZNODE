package fr.edf.dco.contacts.bhc.entities.contact;

import java.io.IOException;
import java.util.Map;

import org.apache.hadoop.hbase.client.Put;

import fr.edf.com.dacc.HDFSLogger;
import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.common.factory.Recordable;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * BHC Contacts abstraction class that represents contacts records structures.
 * Every BHC contact stream must extend this class. Implements BhcRecordable
 * interface.
 * 
 * @author ahmed-externe.dridi@edf.fr
 */
public abstract class AbstractContactRecord implements Recordable {

  // ------------------------------------------------------------------
  // CONSTRUCTOR
  // ------------------------------------------------------------------

  public AbstractContactRecord(String file, String separator, String contactType, String contactStream, int fieldsCount, String headerWord, boolean isArchived) {
    String[] fields = file.split("~", -1);

    this.archiveName = fields[0];
    this.fileName = fields.length > 1 ? Utils.getFileName(fields[1]) : fields[0];

    this.separator = separator;
    this.contactType = contactType;
    this.contactStream = contactStream;
    this.fieldsCount = fieldsCount;
    this.headerWord = headerWord;
    this.isArchived = isArchived;
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------

  /**
   * Parsing raw data
   */
  public void parse(String rawInput) throws CustomException {
    ApplicationContext context = ApplicationContext.getInstance();
    this.logger = context.getLogger(this.getClass(), Constants.CONTACT_PROCESS_PARSING);

    line = new Line(rawInput);

    if (line.raw != null && !line.raw.trim().isEmpty()) {
      if (fieldsCount != 0) {
        String[] fields = line.raw.split(this.separator, -1);
        boolean condition = headerWord == null ? true : !(fields[0].contains(headerWord));

        if (fields.length >= fieldsCount && condition) {

          // special processing for AWL lines
          for (int i = 0; i < fields.length; i++) {
            try {
              fields[i] = fields[i].replace("\"", "");
            } catch (OutOfMemoryError e) {
              throw new CustomException("Could not ommit quotes, out of memory !! " + rawInput);
            }
          }

          process(fields);
        } else {
          throw new CustomException("Could Not parse line : " + line.raw);
        }
      } else {
        // Processing JSON messages or XML nodes
        String[] input = { line.raw };

        try {
          process(input);
        } catch (Exception e) {
          e.printStackTrace();
          throw new CustomException("Could Not parse Json line or XML message : " + line.raw + " Exception : ");
        }
      }

      if (isArchived && ApplicationContext.getInstance().getArchived()) {
        try {
          archive();
        } catch (IOException e) {
          logger.error(Constants.ERROR_HBASE, "Error while archiving contact messages : " + e.getMessage());
        }
      }
    } else {
      throw new CustomException("Could Not parse line : " + line.raw);
    }
  }

  protected abstract void archive() throws IOException;

  @Override
  public String toLine() {
    return null;
  }

  @Override
  public String getKey() {
    return null;
  }

  @Override
  public void storeToFile() {
  }

  @Override
  public void storeToElasticsearch() {
  }

  @Override
  public String toJson() {
    return null;
  }

  // ------------------------------------------------------------------
  // ABSTRACTION
  // ------------------------------------------------------------------

  /**
   * Process raw data parsing
   */
  protected abstract void process(String[] fields) throws CustomException;

  // ------------------------------------------------------------------
  // ACCESSORS
  // ------------------------------------------------------------------

  public String getContactType() {
    return this.contactType;
  }

  public String getContactStream() {
    return this.contactStream;
  }

  public String getArchive() {
    return this.archiveName;
  }

  public String getFileName() {
    return this.fileName;
  }

  public Put getHbasePut() {
    return line.put;
  }

  public String getCommunicationId() {
    return line.communicationID;
  }

  // to override by XML files stream type
  public String getXmlNodesTag() {
    return null;
  }

  // to overide if elasticsearch is used
  public Map<String, String> getMap() {
    return null;
  }

  // Single line representation
  protected class Line {

    // ------------------------------------------------------------------
    // DATA MEMBERS
    // ------------------------------------------------------------------

    public Line(String raw) {
      this.raw = raw;
    }

    public String raw; // Raw data before parsing
    public String communicationID; // ID_CONTACT
    public String businessPartner; // C_BP
    public String status; // A_STATUS
    public String strategy; // C_STRATEGIE
    public String groupCode; // C_CODE_REGROUPEMENT
    public String chanel; // C_CANAL
    public String template; // C_TEMPLATE
    public String contactInformation; // C_COORDONNEES
    public String noSendType; // C_TYPE_NENV
    public String referenceCategory;
    public String processCode; // C_CODE_TRAITEMENT
    public Put put;
  }

  protected final String fileName; // stream file name
  protected final String archiveName; // stream archive Name
  protected final String separator; // data fields separator
  protected final int fieldsCount;
  protected final String headerWord;
  protected final String contactType; // CIBLAGE, RETOUR ...
  protected final String contactStream; // ETL SIMM, AWL ...
  protected boolean isArchived;
  protected Line line;
  protected HDFSLogger logger;
}
