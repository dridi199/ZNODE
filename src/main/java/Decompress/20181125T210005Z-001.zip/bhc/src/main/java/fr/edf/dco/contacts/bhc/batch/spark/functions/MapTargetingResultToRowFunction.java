package fr.edf.dco.contacts.bhc.batch.spark.functions;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import fr.edf.dco.contacts.bhc.base.Utils;

public class MapTargetingResultToRowFunction implements Function<Result, Row> {

  // ------------------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------------------

  @Override
  public Row call(Result result) throws Exception {
    String id = Utils.getEmptyIfNull(Bytes.toString(result.getRow()));
    String codeRegroupement = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_code_regroupement"))));
    String traitement = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_code_traitement"))));
    String canal = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_canal"))));
    String statut = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("a_statut"))));

    List<Cell> cells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_statut"));
    long ts = 0;
    for (Cell cell : cells) {
      if (cell.getTimestamp() > ts) {
        ts = cell.getTimestamp();
      }
    }

    Timestamp dateStatut = new Timestamp(ts);

    String typeNonEnv = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_type_nenv"))));
    String tent = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("a_tentative"))));
    String tentative = Utils.getEmptyIfNull(Utils.isNotEmptyOrSpace(tent) ? id + "_" + tent : "");
    String bp = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_bp"))));

    if (bp != null && bp.length() > 10) {
      bp = bp.substring(0, 9);
    }

    String local = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_local"))));
    String accordCo = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_accord_co"))));
    String region = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_region"))));
    Timestamp dateCiblage = Utils.getSqlTimestamp(Utils.getLongTimestamp(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_date"))), "dd/MM/yyyy HH:mm:ss"));
    String flux = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_flux"))));
    String editicGroupCode = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_code_regroupement_editic"))));
    String logicalInsert = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_mkt_log"))));
    String physicalInsert = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_mkt_phy"))));
    String pagesCount = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_nb_pages"))));
    String marche = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"))));
    
    return RowFactory.create(id, codeRegroupement, traitement, canal, statut, dateStatut, typeNonEnv, tentative, bp, local, accordCo, region, dateCiblage, flux, marche, editicGroupCode, logicalInsert, physicalInsert, pagesCount, new Timestamp(new Date().getTime()));
  }

  // ------------------------------------------------------------------------------
  // DATA MEMEBERS
  // ------------------------------------------------------------------------------

  private static final long serialVersionUID = 3502180062965228839L;
 
  public final StructType TARGETING_SCHEMA_SQL = new StructType(new StructField[] {
      new StructField("ID_TECH", DataTypes.StringType, true, Metadata.empty()),
      new StructField("CODE_REGROUPEMENT", DataTypes.StringType, true, Metadata.empty()),
      new StructField("CODE_TRAITEMENT", DataTypes.StringType, true, Metadata.empty()),
      new StructField("LIB_CANAL_CIB", DataTypes.StringType, true, Metadata.empty()),
      new StructField("LIB_STATUT", DataTypes.StringType, true, Metadata.empty()),
      new StructField("DATE_STATUT", DataTypes.TimestampType, true, Metadata.empty()),
      new StructField("TYPE_NENV", DataTypes.StringType, true, Metadata.empty()),
      new StructField("ID_TENTATIVE", DataTypes.StringType, true, Metadata.empty()),
      new StructField("ID_CLIENT_BP", DataTypes.StringType, true, Metadata.empty()),
      new StructField("ID_CLIENT_LOCAL", DataTypes.StringType, true, Metadata.empty()),
      new StructField("ID_CLIENT_ACCORD_CO", DataTypes.StringType, true, Metadata.empty()),
      new StructField("CODE_REGION", DataTypes.StringType, true, Metadata.empty()),
      new StructField("DATE_CIBLAGE", DataTypes.TimestampType, true, Metadata.empty()),
      new StructField("FLUX", DataTypes.StringType, true, Metadata.empty()),
      new StructField("MARCHE", DataTypes.StringType, true, Metadata.empty()),
      new StructField("CODE_REGROUPEMENT_EDITIC", DataTypes.StringType, true, Metadata.empty()),
      new StructField("REF_INSERT_MKT_LOG", DataTypes.StringType, true, Metadata.empty()),
      new StructField("REF_INSERT_MKT_PHY", DataTypes.StringType, true, Metadata.empty()),
      new StructField("NB_PAGES", DataTypes.StringType, true, Metadata.empty()),
      new StructField("DATE_INSERTION", DataTypes.TimestampType, true, Metadata.empty()) 
  });
}
