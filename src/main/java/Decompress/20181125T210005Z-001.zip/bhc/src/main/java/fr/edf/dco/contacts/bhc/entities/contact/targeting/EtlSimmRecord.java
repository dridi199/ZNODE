package fr.edf.dco.contacts.bhc.entities.contact.targeting;

import java.text.ParseException;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * ETL SIMM contact record representation
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class EtlSimmRecord extends TargetingRecord {

  // ------------------------------------------------------------------
  // CONSTRUCTOR
  // ------------------------------------------------------------------

  /**
   * Constructs new ETL SIMM contact record
   */
  public EtlSimmRecord(String file) {
    super(file, ";", Constants.CONTACT_STREAM_ETL_SIMM, 27, "NUMERO_BP", false);
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------

  /**
   * Parsing raw data into record structure
   */
  protected void process(String[] fields) throws CustomException {
    this.targetingLine = new TargetingLine();

    targetingLine.market = Constants.CONTACT_MARKET_MM;

    targetingLine.targetingDateBase = fileName.substring(fileName.indexOf('.') - 8, fileName.indexOf('.'));

    try {
      targetingLine.targetingDate = Utils.formatDate(targetingLine.targetingDateBase, "yyyyMMdd", "dd/MM/yyyy HH:mm:ss");
    } catch (ParseException e) {
      throw new CustomException("could not parse date : " + targetingLine.targetingDate + " from yyyyMMdd to dd/MM/yyyy HH:mm:ss format");
    }

    line.businessPartner = fields[0].trim();
    targetingLine.deliveryPoint = fields[1].trim();
    line.communicationID = fields[2].trim();

    if (!line.communicationID.startsWith("CRMMM")) {
      throw new CustomException("Invalid ETLSIMM Row Key : " + line.communicationID);
    }

    targetingLine.temoin = fields[16].equals("OUI");
    line.groupCode = fields[10].trim();

    targetingLine.email = fields[6].trim();
    targetingLine.homePhone = fields[7].trim();
    targetingLine.workPhone = fields[8].trim();
    targetingLine.mobilePhone = fields[9].trim();

    loadCartography();
    targetingLine.hm = loadBhcParamAlim(fields);
    line.status = Constants.CONTACT_STATUS_TRANSMIS;
  }
}
