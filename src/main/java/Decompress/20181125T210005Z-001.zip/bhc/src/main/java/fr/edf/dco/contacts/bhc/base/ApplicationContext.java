package fr.edf.dco.contacts.bhc.base;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.security.alias.CredentialProviderFactory;

import com.google.common.collect.HashMultimap;

import fr.edf.com.dacc.HDFSLogger;
import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.common.connector.base.ConnectorException;
import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.common.connector.hadoop.HdfsConnector;
import fr.edf.dco.common.connector.jdbc.OracleConnector;
import fr.edf.dco.common.connector.jdbc.SqlServerConnector;
import fr.edf.dco.common.connector.misc.KafkaConnector;
import fr.edf.dco.contacts.bhc.entities.cartography.Cartography;

/**
 * Singleton Design Pattern Implementation that holds all configurations and
 * properties, along with instances of sources connections
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class ApplicationContext {

  // ---------------------------------------------------------------------------
  // CONSTRUCTOR
  // ---------------------------------------------------------------------------

  /**
   * Private singleton constructor
   */
  private ApplicationContext() {
    loadPropertiesEnv();

    if (getProperty(Constants.PROPERTIES_APPLICATION_LOGS).equals(Constants.LOG_CONSOLE)) {
      logger = new ConsoleLogger(this.getClass().getName(), Constants.CONTACT_PROCESS_GOLABAL);
    } else {
      logger = new HDFSLogger(this.getClass().getName(), Constants.CONTACT_PROCESS_GOLABAL);
    }
  }

  // ---------------------------------------------------------------------------
  // IMPLEMENTATION
  // ---------------------------------------------------------------------------

  /**
   * returns the ApplicationContext singleton unique instance
   */
  public static ApplicationContext getInstance() {
    if (singleton == null) {
      synchronized (ApplicationContext.class) {
        singleton = new ApplicationContext();
      }
    }

    return singleton;
  }

  /**
   * Close application context by closing all connections
   */
  public void closeContext() {
    // close HDFS Appenders
    closeAppenders();

    // closing HBASE connection
    if (hbase != null) {
      try {
        hbase.disconnect();
      } catch (ConnectorException e) {
        logger.error(Constants.ERROR_HBASE, "could not close hbase connection " + e.getMessage());
      }
    }

    // closing HDFS connection
    if (hdfs != null) {
      try {
        hdfs.disconnect();
      } catch (ConnectorException e) {
        logger.error(Constants.ERROR_HDFS, "could not close hdfs connection " + e.getMessage());
      }
    }

    // closing SQLServer connection
    if (sqlProd != null) {
      try {
        sqlProd.disconnect();
      } catch (ConnectorException e) {
        logger.error(Constants.ERROR_SQLSERVER, "could not close SQLServer connection " + e.getMessage());
      }
    }

    if (sqlPreprod != null) {
      try {
        sqlPreprod.disconnect();
      } catch (ConnectorException e) {
        logger.error(Constants.ERROR_SQLSERVER, "could not close SQLServer connection " + e.getMessage());
      }
    }

    // closing KAFKA connection
    if (kafka != null) {
      kafka.disconnect();
    }
  }

  /**
   * Load context properties from properties file
   */
//  private static void loadProperties() {
//    properties = new Properties();
//    FileInputStream inputStream;
//
//    try {
//      inputStream = new FileInputStream(Constants.PROPERTIES_APPLICATION_FILE_NAME);
//      properties.load(inputStream);
//      inputStream.close();
//    } catch (IOException e) {
//      logger.error(Constants.ERROR_OTHER, "Unable to locate properties file : " + Constants.PROPERTIES_APPLICATION_FILE_NAME);
//    }
//  }
  
  /**
   * Load context properties from properties file
   */
  private static void loadPropertiesEnv() {
    String propertiesFile=Constants.PROPERTIES_PROD_APPLICATION_FILE_NAME;
    properties = new Properties();
    FileInputStream inputStream;
    File f = new File(propertiesFile);
    if(f==null||!f.exists()) { 
      propertiesFile=Constants.PROPERTIES_DATALAB_APPLICATION_FILE_NAME;
    }
    try {
      inputStream = new FileInputStream(propertiesFile);
      properties.load(inputStream);
      inputStream.close();
    } catch (IOException e) {
      logger.error(Constants.ERROR_OTHER, "Unable to locate properties file : " + Constants.PROPERTIES_APPLICATION_FILE_NAME);
    }
  }
  // ---------------------------------------------------------------------------
  // ACCESSORS
  // ---------------------------------------------------------------------------

  /**
   * Access properties file attributes by its name
   */
  public String getProperty(String property) {
    if (properties.containsKey(property)) {
      return properties.getProperty(property);
    } else {
      logger.error(Constants.ERROR_OTHER, "Property : " + property + " ,is not defined in properties file : " + Constants.PROPERTIES_APPLICATION_FILE_NAME);
      return null;
    }
  }

  /**
   * Return unique instance of HbaseConnector
   */
  public HbaseConnector getHbase() {
    if (hbase == null) {
      hbase = new HbaseConnector(getProperty(Constants.PROPERTIES_KERBEROS_USER), getProperty(Constants.PROPERTIES_KERBEROS_KEYTAB), true);
      try {
        hbase.connect();
      } catch (ConnectorException e) {
        logger.error(Constants.ERROR_HBASE, "Unable to connect to hbase : " + e.getMessage());
      }
    }

    return hbase;
  }

  /**
   * Return unique instance of HDFSConnector
   */
  public HdfsConnector getHdfs() {
    if (hdfs == null) {
      hdfs = new HdfsConnector(getProperty(Constants.PROPERTIES_KERBEROS_USER), getProperty(Constants.PROPERTIES_KERBEROS_KEYTAB), true);

      try {
        hdfs.connect();
      } catch (ConnectorException e) {
        logger.error(Constants.ERROR_HDFS, "Unable to connect to hdfs : " + e.getMessage());
      }
    }

    return hdfs;
  }

  /**
   * Return unique instance of KafkaConnector
   */
  public KafkaConnector getKafka(String topic) {
    if (kafka == null) {
      kafka = new KafkaConnector(getProperty(Constants.PROPERTIES_KAFKA_ZOOKEEPER_QUORUM), getProperty(Constants.PROPERTIES_KAFKA_BROKERS_LIST), UUID.randomUUID().toString());
      kafka.setTopic(topic);
      kafka.connect();
    }

    return kafka;
  }

  public Map<String, Object> getKafkaParams() {
    Map<String, Object> kafkaParams = new HashMap<String, Object>();
    kafkaParams.put("bootstrap.servers", getProperty(Constants.PROPERTIES_KAFKA_BROKERS_LIST));
    kafkaParams.put("security.protocol", "SASL_SSL");
    kafkaParams.put("ssl.truststore.location", "./kafka.truststore.jks");
    kafkaParams.put("ssl.truststore.password", "ryba123");
    kafkaParams.put("key.deserializer", org.apache.kafka.common.serialization.StringDeserializer.class);
    kafkaParams.put("value.deserializer", org.apache.kafka.common.serialization.StringDeserializer.class);
    kafkaParams.put("enable.auto.commit", false);
    kafkaParams.put("auto.offset.reset", "earliest");
    kafkaParams.put("group.id", "ryba-consumer-group");
    return kafkaParams;
  }

  /**
   * Return HashMultimap of cartography entries
   */
  public HashMultimap<String, Cartography> getCartography() throws CustomException {
    if (cartgraphy == null) {
      cartgraphy = HashMultimap.create();

      // cartography entries are fetched from PMDBI SQLServer database

      try {
        // executing stored procedure and filling HashMultimap
        ResultSet result = getSqlServerProd(Constants.SQL_SERVER_CARTOGRAPHY_DB).procedure(getProperty(Constants.PROPERTIES_SQL_SERVER_CARTOGRAPHY_PROCEDURE));

        while (result.next()) {
          String id = result.getString(1);
          String template = result.getString(2);
          String strategy = result.getString(3);

          Cartography entry = new Cartography(id, strategy, template);
          cartgraphy.put(id, entry);
        }

        result.close();
      } catch (SQLException e) {
        logger.error(Constants.ERROR_SQLSERVER, "Error while executing SQLServer stored procedure : " + e.getMessage());
        throw new CustomException("Cartography fucked up");
      }
    }

    return cartgraphy;
  }
  
  
  /**
   * get mapping parametrable table BHC_PARAM_ALIM
   * @return
   * @throws CustomException
   */

  public ResultSet getBhcParamAlim() throws CustomException {

      // cartography entries are fetched from PMDBI SQLServer database

        // executing stored procedure and filling HashMultimap
        ResultSet result = null;
        try {
          result = getSqlServerProd(Constants.SQL_SERVER_CARTOGRAPHY_DB).procedureExec(getProperty(Constants.PROPERTIES_SQL_SERVER_PARAM_ALIM_PROCEDURE));
        } catch (SQLException e) {
          logger.error(Constants.ERROR_SQLSERVER, "Error while executing SQLServer stored procedure: " + e.getMessage());
          throw new CustomException("ParamAlim fucked up");
        }

    return result;
  }
  
  /**
   * Return all HBASE puts map by row keys
   */
  public HashMap<String, Put> getPuts() {
    if (contactsPuts == null) {
      contactsPuts = new HashMap<String, Put>();
    }

    return contactsPuts;
  }
  
  /**
   * 
   * @param alias
   * @param path
   * @return password from jceks file using alias
   * @throws CustomException
   */
  public String getCredentialPassword(String alias,String path) throws CustomException {
    String password = null;
    ApplicationContext context = ApplicationContext.getInstance();
    HdfsConnector hdfs = context.getHdfs();
    Configuration conf = hdfs.getConfiguration();
    conf.set(CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH,path);
    String credpath = conf.get(CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH);
    
    if (credpath == null) {
      credpath = System.getProperty(CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH);
      if (credpath == null)
        throw new CustomException("Property " + CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH + " is not defined");
        conf.set(CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH,path);
    }
    char[] pass = null;
    try {
      pass = conf.getPassword(alias);
      if (pass == null || pass.length == 0) {
        throw new CustomException("Cannot find password for alias " + alias + " in store " + credpath);
      } else {
        password = new String(pass);
      }
    } catch (IOException e) {
      throw new CustomException("Cannot read password from " + credpath);
    }
    return password;
  }
  
  
  /**
   * Return HDFS file appender for a given HDFS path
   */
  public BufferedWriter getHdfsFileAppender(String path) {
    if (!getAppenders().containsKey(path)) {
      HdfsConnector hdfs = getHdfs();
      BufferedWriter br = null;

      try {
        br = hdfs.getFileAppender(path);
      } catch (IOException e) {
        logger.error(Constants.ERROR_HDFS, "Unable to open fine appender for HDFS path : " + path + " " + e.getMessage());
      }

      if (br != null) {
        getAppenders().put(path, br);
      }
    }

    return getAppenders().get(path);
  }

  /**
   * Return a map for HDFS file appenders by path
   */
  public HashMap<String, BufferedWriter> getAppenders() {
    if (hdfsFileAppenders == null) {
      hdfsFileAppenders = new HashMap<String, BufferedWriter>();
    }

    return hdfsFileAppenders;
  }

  /**
   * close HDFS file appenders
   */
  private void closeAppenders() {
    if (hdfsFileAppenders != null && new Boolean(getProperty(Constants.PROPERTIES_APPLICATION_ARCHIVAGE))) {
      Iterator<String> files = hdfsFileAppenders.keySet().iterator();

      while (files.hasNext()) {
        try {
          hdfsFileAppenders.get(files.next()).close();
        } catch (IOException e) {
          logger.error(Constants.ERROR_HDFS, "unable to close HDFS file appender" + e.getMessage());
        }
      }
    }
  }

  /**
   * Remove duplicated lines from files appenders
   */
  public void removeDuplicatesFromFile() {
    Iterator<String> files = getAppenders().keySet().iterator();
    HdfsConnector hdfs = getHdfs();

    while (files.hasNext()) {
      String file = files.next();

      try {
        hdfs.removeDuplicateLines(file);
      } catch (IOException e) {
        logger.error(Constants.ERROR_HDFS, "unable to remove duplicates from HDFS file : " + file + " " + e.getMessage());
      }
    }
  }

  /**
   * flush Contacts in HBASE
   */
  public void flushContacts(boolean delta) {

    if (contactsPuts != null && contactsPuts.size() > 0) {
      try {
        HbaseConnector hbase = getHbase();
        hbase.setTable(getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
        hbase.multiPut(new ArrayList<Put>(contactsPuts.values()));

        if (delta) {
          for (String key : contactsPuts.keySet()) {
            contactsPuts.put(key, Utils.resultToNoVersionPut(hbase.getRow(key), Utils.getContactPut(key)));
          }

          hbase.setTable(getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
          hbase.multiPut(new ArrayList<Put>(contactsPuts.values()));
          
        }

        contactsPuts = new HashMap<String, Put>();
      } catch (IOException e) {
        e.printStackTrace();
        logger.error(Constants.ERROR_HBASE, "Could not write puts to hbase " + e.getMessage());
      }
    } else {
      logger.warn(Constants.WARNING_DATA, "No put operation executed; puts map was empty");
    }
  }
  
  /**
   * flush Contacts in HBASE (big + temp + zetemp)
   */
  public void flushContactsWithtZe(boolean delta) {

    if (contactsPuts != null && contactsPuts.size() > 0) {
      try {
        HbaseConnector hbase = getHbase();
        hbase.setTable(getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
        hbase.multiPut(new ArrayList<Put>(contactsPuts.values()));

        if (delta) {
          for (String key : contactsPuts.keySet()) {
            contactsPuts.put(key, Utils.resultToNoVersionPut(hbase.getRow(key), Utils.getContactPut(key)));
          }

          hbase.setTable(getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
          hbase.multiPut(new ArrayList<Put>(contactsPuts.values()));
          
          hbase.setTable(getProperty(Constants.PROPERTIES_HBASE_CONTACTS_ZETEMP_TABLE));
          hbase.multiPut(new ArrayList<Put>(contactsPuts.values()));
        }

        contactsPuts = new HashMap<String, Put>();
      } catch (IOException e) {
        e.printStackTrace();
        logger.error(Constants.ERROR_HBASE, "Could not write puts to hbase " + e.getMessage());
      }
    } else {
      logger.warn(Constants.WARNING_DATA, "No put operation executed; puts map was empty");
    }
  }

  /**
   * Flushing only Temporary table
   * 
   * @param delta
   */
  public void flushTempContacts() {

    if (contactsPuts != null && contactsPuts.size() > 0) {
      try {
        HbaseConnector hbase = getHbase();
        hbase.setTable(getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));

        for (String key : contactsPuts.keySet()) {
          contactsPuts.put(key, Utils.resultToNoVersionPut(hbase.getRow(key), Utils.getContactPut(key)));
        }

        hbase.setTable(getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
        hbase.multiPut(new ArrayList<Put>(contactsPuts.values()));

        contactsPuts = new HashMap<String, Put>();
      } catch (IOException e) {
        e.printStackTrace();
        logger.error(Constants.ERROR_HBASE, "Could not write puts to hbase " + e.getMessage());
      }
    } else {
      logger.warn(Constants.WARNING_DATA, "No put operation executed; puts map was empty");
    }
  }
  
  /**
   * Flushing only big table
   * 
   * @param full
   */
  public void flushBigContacts() {

    if (contactsPuts != null && contactsPuts.size() > 0) {
      try {
        HbaseConnector hbase = getHbase();
        hbase.setTable(getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
        hbase.multiPut(new ArrayList<Put>(contactsPuts.values()));

        for (String key : contactsPuts.keySet()) {
          contactsPuts.put(key, Utils.resultToNoVersionPut(hbase.getRow(key), Utils.getContactPut(key)));
        }

//        hbase.setTable(getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
//        hbase.multiPut(new ArrayList<Put>(contactsPuts.values()));

        contactsPuts = new HashMap<String, Put>();
      } catch (IOException e) {
        e.printStackTrace();
        logger.error(Constants.ERROR_HBASE, "Could not write puts to hbase " + e.getMessage());
      }
    } else {
      logger.warn(Constants.WARNING_DATA, "No put operation executed; puts map was empty");
    }
  }

  /**
   * Return the appropriate and unique HDFSLogger instance per class and process
   */
  @SuppressWarnings("rawtypes")
  public HDFSLogger getLogger(Class clazz, String process) {
    if (!getLoggers().containsKey(clazz + process)) {
      if (getProperty(Constants.PROPERTIES_APPLICATION_LOGS).equals(Constants.LOG_CONSOLE)) {
        getLoggers().put(clazz + process, new ConsoleLogger(clazz.getName(), process));
      } else {
        getLoggers().put(clazz + process, new HDFSLogger(clazz.getName(), process));
      }
    }

    return getLoggers().get(clazz + process);
  }

  /**
   * Return a map of all instances of HDFSLogger
   */
  private HashMap<String, HDFSLogger> getLoggers() {
    if (loggers == null) {
      loggers = new HashMap<String, HDFSLogger>();
    }

    return loggers;
  }

  /**
   * Return unique instance of SQLServerConnector for Prod env
   * @param database 
   */
  public SqlServerConnector getSqlServerProd(String database) {
    if (sqlProd == null || !sqlProd.getDatabase().equals(database)) {

      try {
        sqlProd = new SqlServerConnector(getProperty(Constants.PROPERTIES_SQL_SERVER_HOST_PROD), getProperty(Constants.PROPERTIES_SQL_SERVER_INSTANCE), getProperty(Constants.PROPERTIES_SQL_SERVER_USER), getCredentialPassword(getProperty(Constants.PROPERTIES_SQL_SERVER_USER), getProperty(Constants.PROPERTIES_SQL_SERVER_JCEKS_PROD_FILE_PATH)), database);
      } catch (CustomException e1) {
        e1.printStackTrace();
        logger.error(Constants.ERROR_SQLSERVER, "Error while getting password from jceks prod file : " + e1.getMessage());
      }

      try {
        sqlProd.connect();
      } catch (ConnectorException e) {
        logger.error(Constants.ERROR_SQLSERVER, "Error while connecting to SQLServer : " + e.getMessage());
      }
    }

    return sqlProd;
  }

  /**
   * Return unique instance of SQLServerConnector for Preprod env
   * @param database 
   */
  public SqlServerConnector getSqlServerPreprod(String database) {
    if (sqlPreprod == null || !sqlPreprod .getDatabase().equals(database)) {

      try {
        sqlPreprod  = new SqlServerConnector(getProperty(Constants.PROPERTIES_SQL_SERVER_HOST_PREPROD), getProperty(Constants.PROPERTIES_SQL_SERVER_INSTANCE), getProperty(Constants.PROPERTIES_SQL_SERVER_USER), getCredentialPassword(getProperty(Constants.PROPERTIES_SQL_SERVER_USER), getProperty(Constants.PROPERTIES_SQL_SERVER_JCEKS_PREPROD_FILE_PATH)), database);
      } catch (CustomException e1) {
        e1.printStackTrace();
        logger.error(Constants.ERROR_SQLSERVER, "Error while getting password from jceks preprod file : " + e1.getMessage());
      }

      try {
        sqlPreprod .connect();
      } catch (ConnectorException e) {
        logger.error(Constants.ERROR_SQLSERVER, "Error while connecting to SQLServer : " + e.getMessage());
      }
    }

    return sqlPreprod ;
  }
  
  
  
  public OracleConnector getOracleConnector(String database,String env) throws CustomException {
    if (env.equals("p")) {
      if (oracleConn == null || !oracleConn.getHost().equals(getProperty(Constants.PROPERTIES_ORACLE_SERVER_HOST_PROD))) {
        oracleConn = new OracleConnector(getProperty(Constants.PROPERTIES_ORACLE_SERVER_HOST_PROD),getProperty(Constants.PROPERTIES_ORACLE_SERVER_INSTANCE_PROD), getProperty(Constants.PROPERTIES_ORACLE_SERVER_USER), getCredentialPassword(getProperty(Constants.PROPERTIES_ORACLE_SERVER_USER), getProperty(Constants.PROPERTIES_ORACLE_SERVER_JCEKS_FILE_PROD_PATH)), getProperty(database));
      }
    } else if (env.equals("re7")) {
      if (oracleConn == null || !oracleConn.getHost().equals(getProperty(Constants.PROPERTIES_ORACLE_SERVER_HOST_RE7))) {
        oracleConn = new OracleConnector(getProperty(Constants.PROPERTIES_ORACLE_SERVER_HOST_RE7),getProperty(Constants.PROPERTIES_ORACLE_SERVER_INSTANCE_RE7), getProperty(Constants.PROPERTIES_ORACLE_SERVER_USER), getCredentialPassword(getProperty(Constants.PROPERTIES_ORACLE_SERVER_USER), getProperty(Constants.PROPERTIES_ORACLE_SERVER_JCEKS_FILE_RE7_PATH)), getProperty(database));
      }
    }
    else if (env.equals("pp")) {
      if (oracleConn == null || !oracleConn.getHost().equals(getProperty(Constants.PROPERTIES_ORACLE_SERVER_HOST_PREPROD))) {
        oracleConn = new OracleConnector(getProperty(Constants.PROPERTIES_ORACLE_SERVER_HOST_PREPROD),getProperty(Constants.PROPERTIES_ORACLE_SERVER_INSTANCE_PREPROD), getProperty(Constants.PROPERTIES_ORACLE_SERVER_USER), getCredentialPassword(getProperty(Constants.PROPERTIES_ORACLE_SERVER_USER), getProperty(Constants.PROPERTIES_ORACLE_SERVER_JCEKS_FILE_PREPROD_PATH)), getProperty(database));
      }
    }
    try {
      oracleConn.connect();
    } catch (ConnectorException e) {
      logger.error(Constants.ERROR_SQLSERVER, "Error while connecting to SQLServer : " + e.getMessage());
    }
    return oracleConn;
  }
  

  /**
   * Return wether the archiving processess is enabled
   * 
   * @return
   */
  public boolean getArchived() {
    return new Integer(getProperty(Constants.PROPERTIES_APPLICATION_ARCHIVAGE)).intValue() > 0;
  }

  public HashMap<String, Put> getContactPuts() {
    return contactsPuts;
  }

  public void resetContactPuts() {
    contactsPuts = new HashMap<String, Put>();
  }

  /**
   * Hbase to SQLServer acquittal action
   * @param table sqlServer target table 
   * @param action start or end
   */
  public void acquitHbaseToSql(String table, String action, Timestamp ts, String env) {
    String query = "INSERT INTO " + getProperty(Constants.PROPERTIES_SQL_SERVER_ACQUITTAL_TABLE) + " (TABLE_CIBLE, ACTION, [DATE/HEURE]) " + "VALUES('" + table + "', '" + action + "', '" + ts +"')";
    
    SqlServerConnector sql = env.equals("Prod") ? getSqlServerProd(Constants.SQL_SERVER_REPORTING_DB) : getSqlServerPreprod(Constants.SQL_SERVER_REPORTING_DB); 
    
    try {
      sql.executeUpdate(query);
    } catch (SQLException e) {
      logger.error(Constants.ERROR_SQLSERVER, "Could not write to SQLServer acquittal table : " + e.getMessage());
    }
  }

  // ---------------------------------------------------------------------------
  // DATA MEMBERS
  // ---------------------------------------------------------------------------

  private static volatile ApplicationContext singleton = null;
  private static Properties properties;
  private static HDFSLogger logger;
  private static HbaseConnector hbase = null;
  private static HdfsConnector hdfs = null;
  private static KafkaConnector kafka = null;
  private static OracleConnector oracleConn = null;
  private static SqlServerConnector sqlProd = null;
  private static SqlServerConnector sqlPreprod = null;
  private static HashMultimap<String, Cartography> cartgraphy = null;
  private static HashMap<String, Put> contactsPuts = null;
  private static HashMap<String, BufferedWriter> hdfsFileAppenders = null;
  private static HashMap<String, HDFSLogger> loggers = null;
}
