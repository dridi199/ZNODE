package fr.edf.dco.contacts.bhc.batch.java.actions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import fr.edf.com.dacc.HDFSLogger;
import fr.edf.dco.common.connector.base.ConnectorException;
import fr.edf.dco.common.connector.hadoop.HdfsConnector;
import fr.edf.dco.common.connector.hadoop.HdfsConnector.HadoopFile;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;

public class HdfsFilesFilterAction {

  public static void main(String[] args) {
    ApplicationContext context = ApplicationContext.getInstance();
    HdfsConnector hdfs = context.getHdfs();
    HDFSLogger logger = context.getLogger(HdfsToHbaseAction.class, Constants.CONTACT_PROCESS_HDFS_TO_HBASE);
    String[] dirs = context.getProperty(Constants.PROPERTIES_HDFS_WORK_DIR).split(";", -1);

    List<HadoopFile> files = new ArrayList<HadoopFile>();

    for (String workDir : dirs) {
      try {
        files = hdfs.getFiles(workDir);
      } catch (IOException | ConnectorException e) {
        e.printStackTrace();
        logger.error(Constants.ERROR_HDFS, "unable to read HDFS folder : " + workDir + " " + e.getMessage());
      }

      for (HadoopFile file : files) {
        String date = file.getName().substring(file.getName().indexOf(".tar.gz") - 8, file.getName().indexOf(".tar.gz"));

        //
        if (date.contains("2015")) {
          try {
            hdfs.deleteFile(file.getPath());
          } catch (IOException e) {
            logger.error(Constants.ERROR_HDFS, "could not process delete file : " + file.getName() + " " + e.getMessage());
          }
        }
      }
    }

    context.closeContext();
  }
}
