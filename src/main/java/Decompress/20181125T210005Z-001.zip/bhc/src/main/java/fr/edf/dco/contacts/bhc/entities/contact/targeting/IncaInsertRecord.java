package fr.edf.dco.contacts.bhc.entities.contact.targeting;

import java.io.IOException;
import java.io.StringReader;
import java.text.ParseException;
import java.util.Date;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * INCA Marketing insert targeting record
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class IncaInsertRecord extends TargetingRecord {

  // ------------------------------------------------------------------
  // CONSTRUCTOR
  // ------------------------------------------------------------------

  /**
   * Constructs new Inca insert record
   */
  public IncaInsertRecord(String file) {
    super(file, null, Constants.CONTACT_STREAM_INCA_INSERT, 0, null, false);
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------

  @Override
  protected void process(String[] fields) throws CustomException {
    this.targetingLine = new TargetingLine();

    targetingLine.market = Constants.CONTACT_MARKET_MM;

    Element identificationData = null;
    Element incaData = null;

    try {
      Element element = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(fields[0]))).getDocumentElement();

      if (element.getNodeType() != Node.ELEMENT_NODE) {
        throw new CustomException("Node is not an element : " + fields[0]);
      }

      NodeList identificationNodeList = element.getElementsByTagName("DONNEES_IDENTIFICATION");
      if (identificationNodeList == null || identificationNodeList.getLength() > 1) {
        throw new CustomException("Obligatory bloc DONNEES_IDENTIFICATION absent or too many nodes found: " + fields[0]);
      } else {
        identificationData = (Element) identificationNodeList.item(0);
      }

      NodeList incaNodeList = element.getElementsByTagName("DONNEES_INCA");
      if (incaNodeList == null || incaNodeList.getLength() > 1) {
        throw new CustomException("Obligatory bloc DONNEES_INCA absent or too many nodes found: : " + fields[0]);
      } else {
        incaData = (Element) incaNodeList.item(0);
      }

    } catch (SAXException | IOException | ParserConfigurationException e) {
      throw new CustomException("Could not parse Xml node : " + fields[0] + " Exception Message : " + e.getMessage());
    }

    line.status = Utils.xmlElementGetValue(identificationData, "ACTION");
    targetingLine.comAgree = Utils.xmlElementGetValue(identificationData, "NUM_CPT");
    line.businessPartner = Utils.xmlElementGetValue(identificationData, "NUM_CLI");
    targetingLine.insertLog = Utils.xmlElementGetValue(identificationData, "REF");
    targetingLine.priority = Utils.xmlElementGetValue(identificationData, "PRIORITE");
    targetingLine.startValidity = Utils.xmlElementGetValue(identificationData, "DEBUT_VALIDITE");
    targetingLine.endValidity = Utils.xmlElementGetValue(identificationData, "FIN_VALIDITE");
    line.communicationID = Utils.xmlElementGetValue(incaData, "ID_TECH");
    line.processCode = Utils.xmlElementGetValue(incaData, "CODE_TRAITEMENT");
    line.groupCode = Utils.xmlElementGetValue(incaData, "CODE_OFFRE");
    targetingLine.insertPhy = Utils.xmlElementGetValue(incaData, "ENVELOPPE");
   
    targetingLine.targetingDateBase = fileName.substring(fileName.indexOf('.') - 8, fileName.indexOf('.'));

    try {
      targetingLine.targetingDate = Utils.formatDate(targetingLine.targetingDateBase, "yyyyMMdd", "dd/MM/yyyy HH:mm:ss");
    } catch (ParseException e) {
      throw new CustomException("could not parse date : " + targetingLine.targetingDate + " from yyyyMMdd to dd/MM/yyyy HH:mm:ss format");
    }

    validate();
    loadCartography();
    targetingLine.hm=loadBhcParamAlimForInca(identificationData, incaData);
  }

  @SuppressWarnings("deprecation")
  private void validate() throws CustomException {
    if (line.status.equals("CREATION")) {
      line.status = "TRANSMIS_SIMM";
    } else if (line.status.equals("SUPPRESSION")) {
      if (!Utils.isInit()) {
        line.status = Constants.CONTACT_STATUS_ABANDONED;

        try {
          Date date = Utils.getValueTimestamp(line.communicationID, "S", "a_statut", "TRANSMIS_SIMM");

          if (date != null) {
            date.setSeconds(date.getSeconds() + 5);
            targetingLine.targetingDate = Utils.stringFromDate(date, "dd/MM/yyyy HH:mm:ss");
          } else {
            throw new CustomException("Could not get TRANSMIS_SIMM status timestamp for key : " + line.communicationID);
          }
        } catch (Exception e) {
          throw new CustomException("Parsing date exception" + e.getMessage());
        }
      }
    } else {
      throw new CustomException("Unknow Insert Marketing Action : " + line.status);
    }
  }

  @Override
  protected void loadCartography() throws CustomException {
    setCartography();

    line.chanel = Constants.CONTACT_CANAL_COURRIER;

    if (targetingLine.cartography != null) {
      line.strategy = targetingLine.cartography.getStrategy();
      line.template = targetingLine.cartography.getTemplate();
    }
  }

  /**
   * Return node tag name
   */
  public String getXmlNodesTag() {
    return "INSERT";
  }
}
