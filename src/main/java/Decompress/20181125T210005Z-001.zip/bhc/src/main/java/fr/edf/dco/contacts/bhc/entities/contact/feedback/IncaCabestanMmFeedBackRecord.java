package fr.edf.dco.contacts.bhc.entities.contact.feedback;

import java.io.IOException;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * Inca Cabestan MM feed back contact record
 * 
 * @author fahd-externe.essid@edf.fr
 */
public abstract class IncaCabestanMmFeedBackRecord extends FeedBackRecord {

  // -------------------------------------------------------------------
  // CONSTRUCTORS
  // -------------------------------------------------------------------

  public IncaCabestanMmFeedBackRecord(String file, String separator, int fieldsCount, String header) {
    super(file, separator, Constants.CONTACT_STREAM_INCA_CABESTAN_MM, fieldsCount, header, false);
    this.trialId = 11;
  }

  // -------------------------------------------------------------------
  // IMPLENTATION
  // -------------------------------------------------------------------

  public static IncaCabestanMmFeedBackRecord getRecord(String file) throws CustomException {
    if (file.contains("ROUTAGEEMAIL")) {
      return new MailRootingFeedBack(file);
    } else if (file.contains("CLICS")) {
      return new ClickFeedBack(file);
    } else if (file.contains("COMPL1")) {
      return new DeviceFeedBack(file);
    } else {
      throw new CustomException("Unknown Inca Cabestan Feed Back File " + file);
    }
  }

  // -------------------------------------------------------------------
  // INNER CLASS : MailRootingFeedBack
  // -------------------------------------------------------------------

  private static class MailRootingFeedBack extends IncaCabestanMmFeedBackRecord {

    public MailRootingFeedBack(String file) {
      super(file, "\\|", 11, null);
    }

    @Override
    protected void process(String[] fields) throws CustomException {
      line.communicationID = fields[0].trim();

      if (!line.communicationID.startsWith("MM")) {
        throw new CustomException("Invalid Inca Cabestan Row Key : " + line.communicationID);
      }
      
      this.sendStatus = Utils.transcode(fields[1].trim());
      this.sendDate = Utils.getLongTimestamp(fields[2].trim(), "MM/dd/yyyy HH:mm:ss");
      this.sendResult = Utils.transcode(fields[3].trim());
      this.sendResultDetail = Utils.transcode(fields[4].trim());
      this.sendResultDate = Utils.getLongTimestamp(fields[5].trim(), "MM/dd/yyyy HH:mm:ss");
      this.clientResponse = Utils.transcode(fields[6].trim());
      this.clientResponseDate = Utils.getLongTimestamp(fields[7].trim(), "MM/dd/yyyy HH:mm:ss");
      this.clientUnsubscribe = Utils.transcode(fields[8].trim());
      this.clientUnsubscribeReason = Utils.transcode(fields[9].trim());
      this.clientUnsubscribeDate = Utils.getLongTimestamp(fields[10].trim(), "MM/dd/yyyy HH:mm:ss");
    }

    @Override
    public void storeToHbase() throws IOException {
      if (Utils.isNotEmptyOrSpace(line.communicationID)) {
        String initial = "t_" + trialId + "_";

        line.put = Utils.getContactPut(line.communicationID);
        
        if (!Utils.isInit()) {
          line.template = Utils.getExistingValue(line.communicationID, "S", "c_template");
          line.contactInformation = Utils.getExistingValue(line.communicationID, "S", "c_coordonnees");

          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "template"), sendDate, Utils.getBytes(line.template));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "coordonnee"), sendDate, Utils.getBytes(line.contactInformation));
        }
        
        // get milliseconde from file_name and add it to timestamp
        long milliSeconde = Long.parseLong(fileName.substring(fileName.length()-16, fileName.length()-13));
        long newSendDate = milliSeconde + sendDate;
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), newSendDate, Utils.getBytes(line.raw));
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), newSendDate, Utils.getBytes(fileName));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), sendDate, Utils.getBytes(Constants.CONTACT_MARKET_MM));

        if (sendDate > 0) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), sendDate, Utils.getBytes(sendStatus));
        }

        if (sendStatus.equals("ENVOYE")) {

          if (sendDate != 0) {
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "statut_envoi"), sendDate, Utils.getBytes(sendStatus));
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), sendDate, Utils.getBytes(sendStatus));
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_tentative"), sendDate, Utils.getBytes(Integer.toString(trialId)));

            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "canal"), sendDate, Utils.getBytes(Constants.CONTACT_CANAL_EMAIL));
          }

          if (sendResultDate != 0) {
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "resultat_envoi"), sendResultDate, Utils.getBytes(sendResult));
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "resultat_envoi_detail"), sendResultDate, Utils.getBytes(sendResultDetail));
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), sendResultDate, Utils.getBytes(sendResult));
          }

          if (clientResponseDate != 0) {
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), clientResponseDate, Utils.getBytes(clientResponse));
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), clientResponseDate, Utils.getBytes(clientResponse));
          }

          if (clientUnsubscribeDate != 0) {
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), clientResponseDate, Utils.getBytes(Constants.CONTACT_STATUS_OUVERT));
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "optout"), clientUnsubscribeDate, Utils.getBytes(clientUnsubscribe));
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "optout_detail"), clientUnsubscribeDate, Utils.getBytes(clientUnsubscribeReason));
          }
        }

        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_type_nenv"), Utils.getBytes(""));
      }
    }

    private String sendStatus;
    private long sendDate;
    private String sendResult;
    private String sendResultDetail;
    private long sendResultDate;
    private String clientResponse;
    private long clientResponseDate;
    private String clientUnsubscribe;
    private String clientUnsubscribeReason;
    private long clientUnsubscribeDate;
  }

  // -------------------------------------------------------------------
  // INNER CLASS : ClickFeedBack
  // -------------------------------------------------------------------
  private static class ClickFeedBack extends IncaCabestanMmFeedBackRecord {

    public ClickFeedBack(String file) {
      super(file, "\\|", 4, null);
    }

    @Override
    protected void process(String[] fields) throws CustomException {
      line.communicationID = fields[0].trim();

      if (!line.communicationID.startsWith("MM")) {
        throw new CustomException("Invalid Inca Cabestan Row Key : " + line.communicationID);
      }

      this.url = fields[1].trim();
      this.urlLabel = fields[2].trim();
      this.clickDate = Utils.getLongTimestamp(fields[3].trim(), "MM/dd/yyyy HH:mm:ss");
    }

    @Override
    public void storeToHbase() {
      if (Utils.isNotEmptyOrSpace(line.communicationID)) {

        String initial = "t_" + trialId + "_";

        line.put = Utils.getContactPut(line.communicationID);
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), clickDate, Utils.getBytes(line.raw));
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), clickDate, Utils.getBytes(fileName));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), clickDate, Utils.getBytes(Constants.CONTACT_MARKET_MM));

        if (clickDate != 0) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), clickDate, Utils.getBytes("CLIC"));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction_clic_url"), clickDate, Utils.getBytes(url));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction_clic_liburl"), clickDate, Utils.getBytes(urlLabel));
        }
      }
    }

    private String url;
    private String urlLabel;
    private long clickDate;
  }

  // -------------------------------------------------------------------
  // INNER CLASS : DeviceFeedBack
  // -------------------------------------------------------------------

  private static class DeviceFeedBack extends IncaCabestanMmFeedBackRecord {

    public DeviceFeedBack(String file) {
      super(file, "\\|", 7, null);
    }

    @Override
    protected void process(String[] fields) throws CustomException {
      line.communicationID = fields[0].trim();

      if (!line.communicationID.startsWith("MM")) {
        throw new CustomException("Invalid Inca Cabestan Row Key : " + line.communicationID);
      }

      this.device = fields[1].trim();
      this.deviceLabel = Utils.transcode(fields[2].trim());
      this.deviceSystem = fields[3].trim();
      this.smtp = fields[4].trim();
      this.deviceDate = Utils.getLongTimestamp(fields[5].trim(), "MM/dd/yyyy HH:mm:ss");
      this.deviceOrSmtp = fields[6].trim();
    }

    @Override
    public void storeToHbase() {
      if (Utils.isNotEmptyOrSpace(line.communicationID)) {

        String initial = "t_" + trialId + "_";

        line.put = Utils.getContactPut(line.communicationID);
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), deviceDate, Utils.getBytes(line.raw));
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), deviceDate, Utils.getBytes(fileName));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), deviceDate, Utils.getBytes(Constants.CONTACT_MARKET_MM));

        if (deviceDate != 0) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "devicebrut"), deviceDate, Utils.getBytes(device));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "device"), deviceDate, Utils.getBytes(deviceLabel));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "device_ois"), deviceDate, Utils.getBytes(deviceSystem));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "smtp"), deviceDate, Utils.getBytes(smtp));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "deviceois_smtp"), deviceDate, Utils.getBytes(deviceOrSmtp));
        }
      }
    }

    private String device;
    private String deviceLabel;
    private String deviceSystem;
    private String smtp;
    private long deviceDate;
    private String deviceOrSmtp;
  }
}
