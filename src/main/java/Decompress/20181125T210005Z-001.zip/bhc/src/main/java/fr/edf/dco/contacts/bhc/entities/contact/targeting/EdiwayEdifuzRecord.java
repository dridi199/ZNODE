package fr.edf.dco.contacts.bhc.entities.contact.targeting;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;
import fr.edf.dco.contacts.bhc.entities.cartography.Cartography;

/**
 * Ediway Edifuz Targeting contact record
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class EdiwayEdifuzRecord extends TargetingRecord {

  // ------------------------------------------------------------------
  // CONSTRUCTOR
  // ------------------------------------------------------------------

  /**
   * Constructs new Ediway Edifuz contact record
   */
  public EdiwayEdifuzRecord(String file) {
    super(file, null, Constants.CONTACT_STREAM_EDIWAY_EDIFUZ, 0, null, true);
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------

  @Override
  protected void process(String[] fields) throws CustomException {
    this.targetingLine = new TargetingLine();
    JSONObject json = null;
    JSONObject jsonContact = null;
    ArrayList<JSONObject> contacts = new ArrayList<JSONObject>();

    try {
      json = new JSONObject(fields[0]);
      JSONArray jsonContactsArray = json.getJSONArray("tns:CONTACT");

      for (int i = 0; i < jsonContactsArray.length(); i++) {
        contacts.add(jsonContactsArray.getJSONObject(i));
      }

      jsonContact = contacts.get(0);
      line.communicationID = Utils.getJsonString(json, "tns:ID_CONTACT");
    } catch (JSONException e) {
      throw new CustomException("Json non valide : " + e.getMessage());
    }

    JSONObject jsonAdress = Utils.getJsonObject(jsonContact, "tns:ADRESSE_ENVOI_POSTAL");
    JSONObject jsonClient = Utils.getJsonObject(json, "tns:INFOCLIENT");
    JSONObject jsonMCP = Utils.getJsonObject(jsonClient, "tns:InfosMCP");
    JSONObject jsonMA = Utils.getJsonObject(jsonClient, "tns:InfosMA");

    targetingLine.market = Utils.getJsonString(json, "tns:MARCHE");
    targetingLine.fileNumber = Utils.getJsonString(json, "tns:COM_NUM_DOS");
    line.status = Utils.getJsonString(jsonContact, "tns:STATUT_CONTACT");

    try {
      targetingLine.targetingDate = Utils.formatDate(Utils.getJsonString(jsonContact, "tns:STATUT_CONTACT_DATE").replace("T", " "), "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy HH:mm:ss");
    } catch (ParseException e) {
      try {
        targetingLine.targetingDate = Utils.formatDate(line.communicationID.substring(6, 14) + " 00:00:00", "yyyyMMdd HH:mm:ss", "dd/MM/yyyy HH:mm:ss");
      } catch (ParseException e1) {
        throw new CustomException("Invalid date : " + e1.getMessage());
      }
    }

    line.chanel = Utils.getJsonString(jsonContact, "tns:CANAL");
    for (JSONObject o : contacts) {
      if (targetingLine.email == null) {
        targetingLine.email = "";
      }

      this.targetingLine.email += ";" + Utils.getJsonString(o, "tns:EMAIL");
    }

    if (targetingLine.email.startsWith(";")) {
      targetingLine.email = targetingLine.email.substring(1, targetingLine.email.length());
    }

    targetingLine.emailIsAttachement = new Boolean(Utils.getJsonString(jsonContact, "tns:FLAG_EMAIL_PJ")).booleanValue();
    targetingLine.mobilePhone = Utils.getJsonString(jsonContact, "tns:TEL_MOBILE");

    targetingLine.adress1 = Utils.getJsonString(jsonAdress, "tns:ADRESSE1");
    targetingLine.adress2 = Utils.getJsonString(jsonAdress, "tns:ADRESSE2");
    targetingLine.adress3 = Utils.getJsonString(jsonAdress, "tns:ADRESSE3");
    targetingLine.adress4 = Utils.getJsonString(jsonAdress, "tns:ADRESSE4");
    targetingLine.adress5 = Utils.getJsonString(jsonAdress, "tns:ADRESSE5");
    targetingLine.adress6 = Utils.getJsonString(jsonAdress, "tns:ADRESSE6");
    targetingLine.adress7 = Utils.getJsonString(jsonAdress, "tns:CODE_PAYS");

    targetingLine.adress = buildAdress();

    targetingLine.sourceTool = Utils.getJsonString(json, "tns:OUTIL_SOURCE");

    targetingLine.sendChanel = Utils.getJsonString(json, "tns:CHAINE_ENVOI");
    targetingLine.sourceActor = Utils.getJsonString(json, "tns:ACTEUR_SOURCE");
    line.groupCode = Utils.getJsonString(json, "tns:ID_MESSAGE");
    targetingLine.documentRef = Utils.getJsonString(json, "tns:REF_DOC");
    targetingLine.messageSize = Utils.getJsonString(json, "tns:TAILLE_MESSAGE");
    targetingLine.pageNumber = Utils.getJsonString(json, "tns:NB_PAGES");
    targetingLine.urlArchive = Utils.getJsonString(json, "tns:URL_ARCHIVE");

    if (targetingLine.market.equals(Constants.CONTACT_MARKET_MM)) {
      targetingLine.deliveryPoint = Utils.getJsonString(jsonMCP, "tns:ID_PDL");
      line.businessPartner = Utils.getJsonString(jsonMCP, "tns:BP");
      targetingLine.comAgree = Utils.getJsonString(jsonMCP, "tns:ACCORD_CO");
      targetingLine.contract = Utils.getJsonString(jsonMCP, "tns:ID_CONTRAT");
      targetingLine.local = Utils.getJsonString(jsonMCP, "tns:ID_LOCAL");
      targetingLine.typeEnergy =  Utils.getJsonString(jsonMCP, "tns:TYPE_ENERGIE");
    } else if (targetingLine.market.equals(Constants.CONTACT_MARKET_MA)) {
      targetingLine.deliveryPoint = Utils.getJsonString(jsonMA, "tns:ID_PDL");
      targetingLine.quotation = Utils.getJsonString(jsonMA, "tns:ROW_ID_DEVIS");
      targetingLine.pfRef = Utils.getJsonString(jsonMA, "tns:REF_PF");
      targetingLine.felix = Utils.getJsonString(jsonMA, "tns:ID_FELIX");
      targetingLine.account = Utils.getJsonString(jsonMA, "tns:REF_COMPTE");
      targetingLine.contractAccount = Utils.getJsonString(jsonMA, "tns:REF_COMPTE_CONTRACTANT");
      targetingLine.partnerAccount = Utils.getJsonString(jsonMA, "tns:REF_COMPTE_PF_PARTENAIRE");
      targetingLine.intRef = Utils.getJsonString(jsonMA, "tns:REF_INT");
      targetingLine.request = Utils.getJsonString(jsonMA, "tns:REF_DEMANDE");
      targetingLine.businessRef = Utils.getJsonString(jsonMA, "tns:REF_AFFAIRE");
    }

    loadCartography();
  }

  @Override
  protected void setCartography() throws CustomException {
    Set<Cartography> cartographies = ApplicationContext.getInstance().getCartography().get(line.groupCode);
    Iterator<Cartography> iterator = cartographies.iterator();

    while (iterator.hasNext()) {
      Cartography entry = iterator.next();
      if (entry.getStrategy().contains(line.chanel)) {
        targetingLine.cartography = entry;
        break;
      }
    }
  }

  @Override
  protected void loadCartography() throws CustomException {
    setCartography();

    if (targetingLine.cartography != null) {
      if (Utils.isNotEmptyOrSpace(targetingLine.email) && (line.chanel.equals(Constants.CONTACT_CANAL_EMAIL) || line.chanel.equals(Constants.CONTACT_CANAL_DOUBLE_CLIC))) {
        line.template = targetingLine.cartography.getTemplate();
        line.strategy = targetingLine.cartography.getStrategy();
        line.contactInformation = targetingLine.email;
      } else if (Utils.isNotEmptyOrSpace(targetingLine.mobilePhone) && line.chanel.equals(Constants.CONTACT_CANAL_SMS)) {
        line.template = targetingLine.cartography.getTemplate();
        line.strategy = targetingLine.cartography.getStrategy();
        line.contactInformation = targetingLine.mobilePhone;
      } else if (Utils.isNotEmptyOrSpace(targetingLine.adress) && (!targetingLine.adress.equals(Constants.CONTACT_DEFAULT_NULL_ADDRESS)) && line.chanel.equals(Constants.CONTACT_CANAL_COURRIER)) {
        line.template = targetingLine.cartography.getTemplate();
        line.strategy = targetingLine.cartography.getStrategy();
        line.contactInformation = targetingLine.adress;
      } else if (line.chanel.equals(Constants.CONTACT_CANAL_IMPLOC)) {
        line.template = targetingLine.cartography.getTemplate();
        line.strategy = targetingLine.cartography.getStrategy();
      } else {
        line.chanel = Constants.CONTACT_CANAL_NO_COORD;
        line.template = line.groupCode + "_" + Constants.CONTACT_CANAL_NO_COORD;
      }
    } else {
      if (Utils.isNotEmptyOrSpace(targetingLine.email) && (line.chanel.equals(Constants.CONTACT_CANAL_EMAIL))) {
        line.contactInformation = targetingLine.email;
      } else if (Utils.isNotEmptyOrSpace(targetingLine.mobilePhone) && line.chanel.equals(Constants.CONTACT_CANAL_SMS)) {
        line.contactInformation = targetingLine.mobilePhone;
      } else if (Utils.isNotEmptyOrSpace(targetingLine.adress) && (!targetingLine.adress.equals(Constants.CONTACT_DEFAULT_NULL_ADDRESS)) && (line.chanel.equals(Constants.CONTACT_CANAL_COURRIER) || line.chanel.equals(Constants.CONTACT_CANAL_IMPLOC))) {
        line.contactInformation = targetingLine.adress;
      } else if (Utils.isNotEmptyOrSpace(targetingLine.eanCode) && line.chanel.equals(Constants.CONTACT_CANAL_EDI)) {
        line.contactInformation = targetingLine.eanCode;
      }
    }
  }

  protected void archive() throws IOException {
    ApplicationContext app = ApplicationContext.getInstance();

    String month = targetingLine.targetingDate.substring(targetingLine.targetingDate.indexOf("/") + 1, targetingLine.targetingDate.indexOf("/") + 3);
    String year = targetingLine.targetingDate.substring(targetingLine.targetingDate.lastIndexOf("/") + 1, targetingLine.targetingDate.lastIndexOf("/") + 5);

    String filePath = app.getProperty(Constants.PROPERTIES_HDFS_ARCHIVE_DIR) + "EDIWAY_EDIFUZ/" + year + "/" + "KAFKA_CSSTREAM_EDIFUZ_" + year + month + ".txt";

    app.getHdfsFileAppender(filePath).write(line.raw);
    app.getHdfsFileAppender(filePath).newLine();
  }

}
