package fr.edf.dco.contacts.bhc.batch.spark.jobs.fix;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.IteratorUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.VoidFunction;

import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import scala.Tuple2;

public class HbaseEcheaCorrectorJob {

  public static void main(String[] args) {

    // getting environment context
    ApplicationContext app = ApplicationContext.getInstance();
    HbaseConnector hbase = app.getHbase();

    // configuring HBASE
    Configuration hbaseConfiguration = hbase.getConfiguration();
    hbaseConfiguration.set(TableInputFormat.SCAN_MAXVERSIONS, "100");
    hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, app.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));

    // spark application settings
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HBASE_HIVE);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);

    // creating RDD from HBASE tables
    JavaPairRDD<ImmutableBytesWritable, Result> hbaseRDD = sparkContext.newAPIHadoopRDD(hbaseConfiguration, TableInputFormat.class, ImmutableBytesWritable.class, Result.class);

    // deleting wrong values
    JavaRDD<Delete> deletesRDD = hbaseRDD.mapPartitions(new FlatMapFunction<Iterator<Tuple2<ImmutableBytesWritable, Result>>, Delete>() {

      private static final long serialVersionUID = -9172223650101169251L;

      @Override
      public Iterable<Delete> call(Iterator<Tuple2<ImmutableBytesWritable, Result>> rows) throws Exception {
        List<Delete> deletes = new ArrayList<Delete>();

        Result row = null;
        while (rows.hasNext()) {
          row = rows.next()._2();

          if (Bytes.toString(row.getRow()).startsWith("CRMMMnullnull") || Bytes.toString(row.getRow()).startsWith("CRMMMECHEA_APURESMS")) {
            deletes.add(new Delete(row.getRow()));
          }
        }

        return deletes;
      }
    });

    deletesRDD.foreachPartition(new VoidFunction<Iterator<Delete>>() {

      private static final long serialVersionUID = -2242133943222001948L;

      @SuppressWarnings("unchecked")
      @Override
      public void call(Iterator<Delete> t) throws Exception {
        ApplicationContext context = ApplicationContext.getInstance();
        HbaseConnector hbase = context.getHbase();
        hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
        System.out.println("DELETES SIZE IS : " + IteratorUtils.toList(t).size());
        hbase.multiMutate(IteratorUtils.toList(t));
      }
    });

    sparkContext.close();
  }
}
