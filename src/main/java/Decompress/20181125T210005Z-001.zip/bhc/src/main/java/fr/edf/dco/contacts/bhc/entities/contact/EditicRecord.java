package fr.edf.dco.contacts.bhc.entities.contact;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.entities.contact.feedback.EditicFeedBackRecord;
import fr.edf.dco.contacts.bhc.entities.contact.targeting.EditicTargetingRecord;

/**
 * Editic contacts records creation class
 * 
 * @author fahd-externe.essid@edf.fr
 *
 */
public class EditicRecord {

  /**
   * Return Editic Targeting or Feedback record instance given the input file
   * name
   */
  public static AbstractContactRecord getRecord(String fileName) throws CustomException {
    if (fileName.contains(Constants.CONTACT_FILE_EDITIC_TARGETING)) {
      return new EditicTargetingRecord(fileName);
    } else if (fileName.contains(Constants.CONTACT_FILE_EDITIC_FEED_BACK)) {
      return new EditicFeedBackRecord(fileName);
    } else {
      throw new CustomException("Unknown Editic file : " + fileName);
    }
  }
}
