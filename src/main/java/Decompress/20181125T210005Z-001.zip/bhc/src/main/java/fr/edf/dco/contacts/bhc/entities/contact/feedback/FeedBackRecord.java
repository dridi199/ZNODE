package fr.edf.dco.contacts.bhc.entities.contact.feedback;

import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;

/**
 * Feed Back contact record abstraction
 * 
 * @author fahd-externe.essid@edf.fr
 */
public abstract class FeedBackRecord extends AbstractContactRecord {

  public FeedBackRecord(String file, String separator, String contactStream, int fieldsCount, String header, boolean isArchived) {
    super(file, separator, Constants.CONTACT_TYPE_SORTANT, contactStream, fieldsCount, header, isArchived);
  }

  protected void archive() {
    // override if archive is needed
  }

  protected int trialId;
}
