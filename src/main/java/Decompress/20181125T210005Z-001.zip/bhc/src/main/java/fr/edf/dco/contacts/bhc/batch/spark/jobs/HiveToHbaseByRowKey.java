package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.util.Iterator;
import java.util.Map;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;
import scala.Tuple2;

/**
 * Update Hbase from hive with a given list of RowKeys as textfile with ',' or
 * ';' separator and the filename must has the same name as the hive table
 * 
 * @author ahmed-externe.dridi@edf.fr
 *
 */
public class HiveToHbaseByRowKey {

  public static void main(String[] args) {
    final String separator = "|";
    SparkConf sparkconf = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HIVE_HBASE_UPDATE);
    JavaSparkContext jsc = new JavaSparkContext(sparkconf);
    HiveContext hiveContext = new HiveContext(jsc);
    JavaPairRDD<String, String> RowKeyFiles = jsc.wholeTextFiles("/user/dco_app_bhc/tmp/RowKeysToUpdate/");

    RowKeyFiles = RowKeyFiles.mapToPair(new PairFunction<Tuple2<String, String>, String, String>() {
      private static final long serialVersionUID = 5584200452699132177L;

      @Override
      public Tuple2<String, String> call(Tuple2<String, String> t) throws Exception {
        String filename = t._1.contains(".") ? t._1.substring((t._1.lastIndexOf("/") + 1), t._1.lastIndexOf("."))  :  t._1.substring((t._1.lastIndexOf("/") + 1), t._1.length());
        return new Tuple2<String, String>(filename, "'" + t._2.replaceAll(";", ",").replaceAll("[^0-9A-Z,]", "").replaceAll("\n", "").replaceAll(",,", ",").replaceAll(",", "','") + "'");
      }
    });
    
    Map<String, String> map = RowKeyFiles.collectAsMap();

 //consomme la map dans l'ordre
    if (map.get("inca_cabestan_mail_init_orc") != null) {
      updateHbaseRowKeys("inca_cabestan_mail_init_orc", map.get("inca_cabestan_mail_init_orc"), hiveContext, separator);
      map.remove("inca_cabestan_mail_init_orc");
    }
    if (map.get("inca_cabestan_devices_init_orc") != null) {
      updateHbaseRowKeys("inca_cabestan_devices_init_orc", map.get("inca_cabestan_devices_init_orc"), hiveContext, separator);
      map.remove("inca_cabestan_devices_init_orc");
    }
    if (map.get("inca_cabestan_clics_init_orc") != null) {
      updateHbaseRowKeys("inca_cabestan_clics_init_orc", map.get("inca_cabestan_clics_init_orc"), hiveContext, separator);
      map.remove("inca_cabestan_clics_init_orc");
    }
   if(map.size()>0){
    // //iterate over key
    for (String key : map.keySet()) {
      String value = map.get(key);
      updateHbaseRowKeys(key, value, hiveContext, separator);
    }
   }
  }

  public static void updateHbaseRowKeys(String tableName, String FilterRowKeysCollection, HiveContext hiveContext, String separator) {

    JavaRDD<Row> rowKeysRDD = hiveContext.sql("select * from bhc_db." + tableName + " where " + tableName + ".id_tech in (" + FilterRowKeysCollection + ")").toJavaRDD();
  
    
    // sort RDD rows by file_name thats contatins date 
    rowKeysRDD=rowKeysRDD.sortBy(new Function<Row, String>() {
      private static final long serialVersionUID = 5985452979335347872L;

      @Override
      public String call(Row row) throws Exception {
        return row.getString(0);
      }
    }, true, 1);
    
    rowKeysRDD.foreachPartition(new VoidFunction<Iterator<Row>>() {
      private static final long serialVersionUID = -5844753255324191699L;

      @Override
      public void call(Iterator<Row> rows) throws Exception {
        ApplicationContext context = ApplicationContext.getInstance();
        ContactFactory factory = new ContactFactory();

        String line = null;
        AbstractContactRecord record = null;
        while (rows.hasNext()) {
          try {
            line = rows.next().mkString(separator);
            record = factory.createRecord(line.substring(0, line.indexOf(separator)));
            record.parse(line.substring(line.indexOf(separator) + 1, line.length()));
            record.storeToHbase();
          } catch (Exception e) {
            // log later ..
          }
        }
        context.flushContacts(true);
      }
    });

  }

}
