package fr.edf.dco.contacts.bhc.entities.contact.targeting;

import java.text.ParseException;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * Echea Apur Targeting contact record
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class EcheaApureRecord extends TargetingRecord {

  // ------------------------------------------------------------------
  // CONSTRUCTOR
  // ------------------------------------------------------------------

  /**
   * Constructs new ECHEA APURE contact record
   */
  public EcheaApureRecord(String file) {
    super(file, ";", Constants.CONTACT_STREAM_ECHEA_APURE, 8, "NUMERO", false);
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------

  /**
   * Parsing raw data into record structure
   */
  protected void process(String[] fields) throws CustomException {
    if (fields[0].contains("userftp") || fields[0].contains("END")) {
      throw new CustomException("Could not parse line : " + line.raw);
    } else {
      this.targetingLine = new TargetingLine();
      String[] ids = fields[1].split(",", -1);

      targetingLine.market = Constants.CONTACT_MARKET_MM;

      targetingLine.mobilePhone = fields[0].trim();
      line.businessPartner = ids[0].trim();
      line.groupCode = fields[2].trim();

      targetingLine.targetingDateBase = fileName.substring(fileName.indexOf('.') - 8, fileName.indexOf('.'));

      try {
        targetingLine.targetingDate = Utils.formatDate(targetingLine.targetingDateBase, "yyyyMMdd", "dd/MM/yyyy HH:mm:ss");
      } catch (ParseException e) {
        throw new CustomException("could not parse date : " + targetingLine.targetingDate + " from yyyyMMdd to dd/MM/yyyy HH:mm:ss format");
      }

      line.communicationID = "CRMMM" + line.businessPartner + line.groupCode + targetingLine.targetingDateBase;

      loadCartography();
      targetingLine.hm = loadBhcParamAlim(fields);
      line.status = Constants.CONTACT_STATUS_TRANSMIS;
    }
  }
}
