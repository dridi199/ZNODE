package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.function.VoidFunction;

import fr.edf.dco.common.connector.hadoop.HdfsConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Utils;
import scala.Tuple2;

public class FilesExtractorJob {
  public static void main(String[] args) {
    String fluxName = args[0];
    String dateFilter = args[1];
    SparkConf sparkConf = new SparkConf().setAppName("FilesExtractor");
    JavaSparkContext jsc = new JavaSparkContext(sparkConf);
    if(fluxName.equals("all")){
      ApplicationContext context = ApplicationContext.getInstance();
      HdfsConnector hdfs = context.getHdfs();
      try {
        if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/"+dateFilter+"/awl"+"_"+dateFilter))
          processFiles(jsc,dateFilter,"awl");
        if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/"+dateFilter+"/awlRetours"+"_"+dateFilter))
          processFiles(jsc,dateFilter,"awlRetours");
        if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/"+dateFilter+"/cabestan"+"_"+dateFilter))
          processFiles(jsc,dateFilter,"cabestan");
        if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/"+dateFilter+"/cabestanRetours"+"_"+dateFilter))
          processFiles(jsc,dateFilter,"cabestanRetours");
        if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/"+dateFilter+"/emissaires"+"_"+dateFilter))
          processFiles(jsc,dateFilter,"emissaires");
        if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/"+dateFilter+"/emissairesRetours"+"_"+dateFilter))
          processFiles(jsc,dateFilter,"emissairesRetours");
        if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/"+dateFilter+"/editic"+"_"+dateFilter))
          processFiles(jsc,dateFilter,"editic");
        if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/"+dateFilter+"/inca_insert"+"_"+dateFilter))
          processFiles(jsc,dateFilter,"inca_insert");
        if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/"+dateFilter+"/etlsimmRetours"+"_"+dateFilter))
          processFiles(jsc,dateFilter,"etlsimmRetours");
        if(hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/historique/"+dateFilter+"/armatis"+"_"+dateFilter))
          processFiles(jsc,dateFilter,"armatis");
        
        
        hdfs.deleteFolderContent("/user/dco_app_bhc/FilesNotProcessed/archiveToBackup/");
        hdfs.deleteFolderContent("/user/dco_app_bhc/FilesNotProcessed/tmp/");
      } catch (IOException e) {
        e.printStackTrace();
      }
    }else{
      processFiles(jsc,dateFilter,fluxName);
    }
    jsc.close();
  }
  
  
  public static void processFiles(JavaSparkContext jsc,String directorie, String fluxName){
    JavaRDD<String> listOfFiles = jsc.textFile("/user/dco_app_bhc/FilesNotProcessed/historique/"+directorie+"/"+fluxName+"_"+directorie);
    JavaPairRDD<String, Iterable<String>> rddOfFiles = listOfFiles.mapToPair(new PairFunction<String, String, Iterable<String>>() {
      private static final long serialVersionUID = 6926339464920505306L;

      @Override
      public Tuple2<String, Iterable<String>> call(String line) throws Exception {
        String archiveName = line.substring(1,line.indexOf(","));
        List<String> listOfFiles = new ArrayList<>();
        listOfFiles = Arrays.asList(line.substring(line.indexOf("[")+1,line.indexOf("]")).split(", ",-1));
        
        return new Tuple2<String, Iterable<String>>(archiveName, listOfFiles);
      }
    });
    
    rddOfFiles.foreach(new VoidFunction<Tuple2<String,Iterable<String>>>() {
      private static final long serialVersionUID = -7403640673197816255L;

      @Override
      public void call(Tuple2<String, Iterable<String>> t) throws Exception {
      ApplicationContext context = ApplicationContext.getInstance();
      HdfsConnector hdfs = context.getHdfs();
      String archiveName = t._1.substring(t._1.lastIndexOf("/") + 1, t._1.length());
      for(String filename : t._2){
        
        if (archiveName.contains(".tar.gz")) {
          filename = "/user/dco_app_bhc/FilesNotProcessed/tmp/"+ archiveName.substring(0,archiveName.indexOf(".")) + "targzfile~" + filename;
        } else if (archiveName.contains(".zip")) {
          filename = "/user/dco_app_bhc/FilesNotProcessed/tmp/" + archiveName.substring(0,archiveName.indexOf(".")) + "zipfile~" + filename;
        }
        if(hdfs.exists(filename))
          Utils.moveFile(filename, "/user/dco_app_bhc/FilesNotProcessed/filesToReprise/");
        else if (!hdfs.exists("/user/dco_app_bhc/FilesNotProcessed/NotFound/"+archiveName) && hdfs.exists(archiveName))
          Utils.moveFile(t._1, "/user/dco_app_bhc/FilesNotProcessed/NotFound/");
        
      }
      }
    });
    
  }
}
