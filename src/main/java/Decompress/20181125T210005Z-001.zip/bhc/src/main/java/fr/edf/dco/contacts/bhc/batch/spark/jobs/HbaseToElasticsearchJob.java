package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.elasticsearch.spark.rdd.api.java.JavaEsSpark;

import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.batch.spark.functions.MapFeedBackResultToJsonFunction;
import fr.edf.dco.contacts.bhc.batch.spark.functions.MapReactionResultToJsonFunction;
import fr.edf.dco.contacts.bhc.batch.spark.functions.MapTargetingResultToJsonFunction;

public class HbaseToElasticsearchJob {

  public static void main(String[] args) {
    // getting environment context
    ApplicationContext context = ApplicationContext.getInstance();
    HbaseConnector hbase = context.getHbase();

    // configuring HBASE
    Configuration hbaseConfiguration = hbase.getConfiguration();
    hbaseConfiguration.set(TableInputFormat.SCAN_MAXVERSIONS, "100");

    // spark application settings
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HBASE_HIVE);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);

    // initializing spark user defined functions
    MapTargetingResultToJsonFunction targetingFunction = new MapTargetingResultToJsonFunction();
    MapFeedBackResultToJsonFunction feedBackFunction = new MapFeedBackResultToJsonFunction();
    MapReactionResultToJsonFunction reactionFunction = new MapReactionResultToJsonFunction();

    // creating RDD from HBASE tables
    if (args[0].equals("full")) {
      hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
    } else {
      hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
    }

    JavaPairRDD<ImmutableBytesWritable, Result> hbaseRDD = sparkContext.newAPIHadoopRDD(hbaseConfiguration, TableInputFormat.class, ImmutableBytesWritable.class, Result.class);
    if ((args.length > 1 && args[1].equals("cib")) || (args.length == 1)) {
      JavaPairRDD<Object, Object> targetingJsons = hbaseRDD.mapToPair(targetingFunction);
      targetingJsons.saveAsTextFile("/user/dco_app_bhc/kafka/JSON/CIB");
      JavaEsSpark.saveToEsWithMeta(targetingJsons, context.getProperty(Constants.PROPERTIES_ELASTIC_TARGETING_INDEX));
    }

    if ((args.length > 1 && args[1].equals("int")) || (args.length == 1)) {
      JavaPairRDD<Object, Object> feedBackJsons = hbaseRDD.flatMapToPair(feedBackFunction);
      
      feedBackJsons.saveAsTextFile("/user/dco_app_bhc/kafka/JSON/INT");
      JavaEsSpark.saveToEsWithMeta(feedBackJsons, context.getProperty(Constants.PROPERTIES_ELASTIC_FEED_BACK_INDEX));
    }

    if ((args.length > 1 && args[1].equals("rea")) || (args.length == 1)) {
      JavaPairRDD<Object, Object> reactionJsons = hbaseRDD.flatMapToPair(reactionFunction);
      reactionJsons.saveAsTextFile("/user/dco_app_bhc/kafka/JSON/REA");
      JavaEsSpark.saveToEsWithMeta(reactionJsons, context.getProperty(Constants.PROPERTIES_ELASTIC_REACTION_INDEX));
    }

    sparkContext.close();
  }
}
