package fr.edf.dco.contacts.bhc.batch.spark.functions;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import fr.edf.dco.contacts.bhc.base.Utils;

public class MapFeedBackResultToRowFunction implements FlatMapFunction<Result, Row> {

  // ------------------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------------------

  @Override
  public Iterable<Row> call(Result result) throws Exception {
    List<Row> list = new ArrayList<Row>();

    String id = Utils.getEmptyIfNull(Bytes.toString(result.getRow()));

    List<Cell> trials = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_tentative"));

    if (trials.size() > 0) {
      String trialId = null;
      String chanel = null;
      String sendResultDetails = null;

      for (Cell trialCell : trials) {
        trialId = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(trialCell)));
        chanel = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_canal"))));
        sendResultDetails = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_resultat_envoi_detail"))));

        String coordonnees = null;
        List<Cell> cs = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_coordonnee"));
        String v = null;
        for (Cell c : cs) {
          v = Bytes.toString(CellUtil.cloneValue(c));
          if (Utils.isNotEmptyOrSpace(v)) {
            coordonnees = v.indexOf("@")!= -1 ? v.substring(v.indexOf("@"),v.length()) : v;
            break;
          }
        }
        
        String template = null;
        List<Cell> ts = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_template"));
        String w = null;
        for (Cell t : ts) {
          w = Bytes.toString(CellUtil.cloneValue(t));
          if (Utils.isNotEmptyOrSpace(w)) {
            template = w;
            break;
          }
        }

        String sendStatus = "";
        Timestamp interactionDate = new Timestamp(0);
        List<Cell> sendStatusCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_statut_envoi"));
        if (sendStatusCells.size() > 0) {
          Cell sendStatusCell = sendStatusCells.get(0);

          sendStatus = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(sendStatusCell)));
          interactionDate = Utils.getSqlTimestamp(sendStatusCell.getTimestamp());
        }

        String sendResult = "";
        Timestamp resultDate = new Timestamp(0);

        List<Cell> sendResultCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_resultat_envoi"));
        if (sendResultCells.size() > 0) {
          Cell sendResultCell = sendResultCells.get(0);

          sendResult = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(sendResultCell)));
          resultDate = Utils.getSqlTimestamp(sendResultCell.getTimestamp());
        }
        
        String flux = null;
        List<Cell> cf = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("c_flux"));
        String c= null;
        for (Cell f : cf) {
          c = Bytes.toString(CellUtil.cloneValue(f));
          if (Utils.isNotEmptyOrSpace(c)) {
            flux = c;
            break;
          }
        }
        
        String marche = null;
        List<Cell> cm = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"));
        String m= null;
        for (Cell mt : cm) {
          m = Bytes.toString(CellUtil.cloneValue(mt));
          if (Utils.isNotEmptyOrSpace(m)) {
            marche = m;
            break;
          }
        }
        list.add(RowFactory.create(id + "_" + trialId, id, sendStatus, interactionDate, sendResult, sendResultDetails, resultDate, chanel, template, new Timestamp(new Date().getTime()), coordonnees,flux,marche));
      }
    }

    return list;
  }

  // ------------------------------------------------------------------------------
  // DATA MEMEBERS
  // ------------------------------------------------------------------------------

  private static final long serialVersionUID = -8910485128148385287L;

  public final StructType FEED_BACK_SCHEMA_SQL = new StructType(new StructField[] {
      new StructField("ID_TENTATIVE", DataTypes.StringType, true, Metadata.empty()),
      new StructField("ID_TECH", DataTypes.StringType, true, Metadata.empty()),
      new StructField("CODE_STATUT", DataTypes.StringType, true, Metadata.empty()),
      new StructField("DATE_INTERACTION", DataTypes.TimestampType, true, Metadata.empty()),
      new StructField("CODE_RES_ENV", DataTypes.StringType, true, Metadata.empty()),
      new StructField("CODE_RES_ENV_DETAIL", DataTypes.StringType, true, Metadata.empty()),
      new StructField("DATE_RES_ENV", DataTypes.TimestampType, true, Metadata.empty()),
      new StructField("LIB_CANAL_RET", DataTypes.StringType, true, Metadata.empty()),
      new StructField("CD_MESSAGE", DataTypes.StringType, true, Metadata.empty()),
      new StructField("DATE_INSERTION", DataTypes.TimestampType, true, Metadata.empty()), 
      new StructField("COORDONNEE", DataTypes.StringType, true, Metadata.empty()),
      new StructField("FLUX", DataTypes.StringType, true, Metadata.empty()),
      new StructField("MARCHE", DataTypes.StringType, true, Metadata.empty())
  });
}
