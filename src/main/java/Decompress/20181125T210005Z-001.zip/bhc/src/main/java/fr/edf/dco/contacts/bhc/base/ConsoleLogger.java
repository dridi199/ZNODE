package fr.edf.dco.contacts.bhc.base;

import fr.edf.com.dacc.HDFSLogger;

/**
 * Bypassing HDFSLogger when not needed !! (or when the shit hits the fan)
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class ConsoleLogger extends HDFSLogger {

  public ConsoleLogger(String name, String traitement) {
    super(name, traitement);
  }

  @Override
  public void error(String messageID, String message) {
    System.out.println(message);
  }

  @Override
  public void warn(String messageID, String message) {
    System.out.println(message);
  }

  @Override
  public void info(String messageID, String message) {
    System.out.println(message);
  }

  @Override
  public void debug(String messageID, String message) {
    System.out.println(message);
  }
}
