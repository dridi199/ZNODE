package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.util.Iterator;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;

import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;
/**
 * reputake data from hive table using not structured data (file_name,line) like work_table_orc
 * tablename 
 * flushcondition : where to push data
 * (big : principale table, temp : temporary table or bigtemp)
 * and 
 * the filter condition : name contains _2017 (get only 2017 data)
 * 
 * @author ahmed-externe.dridi@edf.fr
 *
 */
public class HiveToHbaseInitWorkJob {

  public static void main(String[] args) {

    // spark application settings
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HIVE_HBASE);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);
    HiveContext hiveContext = new HiveContext(sparkContext);
    String tablename = args[0];
    String filter =args[1]; //  for example filter = _201702 

    // Retrieving Hive table ciblage & retour
    JavaRDD<Row> tableContentRDD = hiveContext.sql("select * from "+tablename+" DISTRIBUTE BY line").toJavaRDD();
    tableContentRDD=tableContentRDD.filter(new Function<Row, Boolean>() {
      private static final long serialVersionUID = 4523838807664399787L;

      @Override
      public Boolean call(Row row) throws Exception {
        return row.getString(0).contains(filter);
      }
    }).cache();
    processRDD(tableContentRDD);
  }

  private static void processRDD(JavaRDD<Row> rdd) {
    // contacts puts RDD
    rdd.foreachPartition(new VoidFunction<Iterator<Row>>() {

      private static final long serialVersionUID = -5844753255324191699L;

      @Override
      public void call(Iterator<Row> rows) throws Exception {
        ApplicationContext context = ApplicationContext.getInstance();
        ContactFactory factory = new ContactFactory();

        Row row = null;
        AbstractContactRecord record = null;
        while (rows.hasNext()) {
          row = rows.next();

          try {
            record = factory.createRecord(row.getString(0));
            record.parse(row.getString(1));
            record.storeToHbase();
          } catch (Exception e) {
            // log later
          }
        }

        context.flushBigContacts();
      }
    });
  }

}
