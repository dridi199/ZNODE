package fr.edf.dco.contacts.bhc.batch.spark.functions;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.function.PairFlatMapFunction;

import fr.edf.dco.contacts.bhc.base.Utils;
import scala.Tuple2;

public class MapReactionResultToJsonFunction implements PairFlatMapFunction<Tuple2<ImmutableBytesWritable, Result>, Object, Object> {

  // ------------------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------------------

  @Override
  public Iterable<Tuple2<Object, Object>> call(Tuple2<ImmutableBytesWritable, Result> row) throws Exception {
    Result result = row._2;
    List<Tuple2<Object, Object>> list = new ArrayList<Tuple2<Object, Object>>();
    String id = Bytes.toString(result.getRow());

    List<Cell> trials = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_tentative"));

    if (trials.size() > 0) {
      String trialId = null;
      String device = null;
      String os = null;
      String osVersion = null;
      String browser = null;
      String browserVersion = null;

      Map<String, Object> json = null;
      for (Cell trialCell : trials) {

        trialId = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(trialCell)));
        device = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_device"))));
        os = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_device_ois"))));
        osVersion = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_device_ois_version"))));
        browser = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_device_browser"))));
        browserVersion = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_device_browser_version"))));

        String reaction = "";
        Timestamp reactionDate = new Timestamp(0);
        String url = "";

        List<Cell> openCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_reaction"));
        if (openCells.size() > 0) {
          for (Cell openCell : openCells) {
            reaction = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(openCell)));

            if (reaction.equals("OUVERT")) {
              reactionDate = Utils.getSqlTimestamp(openCell.getTimestamp());

              json = new HashMap<String, Object>();

              json.put("ID_TENTATIVE", id + "_" + trialId);
              json.put("LIB_TYPE_REACTION", reaction);
              json.put("DATE_REACTION", reactionDate);
              json.put("LIB_URL", url);
              json.put("LIB_DEVICE", device);
              json.put("LIB_OS", os);
              json.put("VERSION_OS", osVersion);
              json.put("LIB_BROWSER", browser);
              json.put("VERSION_BROWSER", browserVersion);
              json.put("DATE_INSERTION", new Timestamp(new Date().getTime()));

              list.add(new Tuple2<Object, Object>(id + "_" + trialId, json));
            }
          }
        }

        List<Cell> clickCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_reaction_clic_url"));
        if (clickCells.size() > 0) {
          for (Cell clickCell : clickCells) {
            reaction = "CLIC";
            reactionDate = Utils.getSqlTimestamp(clickCell.getTimestamp());
            url = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(clickCell)));

            json = new HashMap<String, Object>();

            json.put("ID_TENTATIVE", id + "_" + trialId);
            json.put("LIB_TYPE_REACTION", reaction);
            json.put("DATE_REACTION", reactionDate);
            json.put("LIB_URL", url);
            json.put("LIB_DEVICE", device);
            json.put("LIB_OS", os);
            json.put("VERSION_OS", osVersion);
            json.put("LIB_BROWSER", browser);
            json.put("VERSION_BROWSER", browserVersion);
            json.put("DATE_INSERTION", new Timestamp(new Date().getTime()));

            list.add(new Tuple2<Object, Object>(id + "_" + trialId, json));
          }
        }

        url = "";

        List<Cell> optoutCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_optout"));
        if (optoutCells.size() > 0) {
          for (Cell optoutCell : optoutCells) {
            reaction = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(optoutCell)));
            reactionDate = Utils.getSqlTimestamp(optoutCell.getTimestamp());

            json = new HashMap<String, Object>();

            json.put("ID_TENTATIVE", id + "_" + trialId);
            json.put("LIB_TYPE_REACTION", reaction);
            json.put("DATE_REACTION", reactionDate);
            json.put("LIB_URL", url);
            json.put("LIB_DEVICE", device);
            json.put("LIB_OS", os);
            json.put("VERSION_OS", osVersion);
            json.put("LIB_BROWSER", browser);
            json.put("VERSION_BROWSER", browserVersion);
            json.put("DATE_INSERTION", new Timestamp(new Date().getTime()));

            list.add(new Tuple2<Object, Object>(id + "_" + trialId, json));
          }
        }

        List<Cell> mirrorCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_mirror"));
        if (mirrorCells.size() > 0) {
          for (Cell mirrorCell : mirrorCells) {
            reaction = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(mirrorCell)));
            reactionDate = Utils.getSqlTimestamp(mirrorCell.getTimestamp());

            json = new HashMap<String, Object>();

            json.put("ID_TENTATIVE", id + "_" + trialId);
            json.put("LIB_TYPE_REACTION", reaction);
            json.put("DATE_REACTION", reactionDate);
            json.put("LIB_URL", url);
            json.put("LIB_DEVICE", device);
            json.put("LIB_OS", os);
            json.put("VERSION_OS", osVersion);
            json.put("LIB_BROWSER", browser);
            json.put("VERSION_BROWSER", browserVersion);
            json.put("DATE_INSERTION", new Timestamp(new Date().getTime()));

            list.add(new Tuple2<Object, Object>(id + "_" + trialId, json));
          }
        }
      }
    }

    return list;
  }

  // ------------------------------------------------------------------------------
  // DATA MEMEBERS
  // ------------------------------------------------------------------------------
  private static final long serialVersionUID = -8612486796252609130L;

}
