package fr.edf.dco.contacts.bhc.batch.spark.functions;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.function.PairFlatMapFunction;

import fr.edf.dco.contacts.bhc.base.Utils;
import scala.Tuple2;

public class MapFeedBackResultToJsonFunction implements PairFlatMapFunction<Tuple2<ImmutableBytesWritable, Result>, Object, Object> {

  // ------------------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------------------

  @Override
  public Iterable<Tuple2<Object, Object>> call(Tuple2<ImmutableBytesWritable, Result> row) throws Exception {
    Result result = row._2;
    List<Tuple2<Object, Object>> list = new ArrayList<Tuple2<Object, Object>>();

    String id = Utils.getEmptyIfNull(Bytes.toString(result.getRow()));

    List<Cell> trials = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_tentative"));

    if (trials.size() > 0) {
      String trialId = null;
      String chanel = null;
      String sendResultDetails = null;

      Map<String, Object> json = null;
      for (Cell trialCell : trials) {
        trialId = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(trialCell)));
        chanel = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_canal"))));
        sendResultDetails = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_resultat_envoi_detail"))));

        String coordonnees = null;
        List<Cell> cs = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_coordonnee"));
        String v = null;
        for (Cell c : cs) {
          v = Bytes.toString(CellUtil.cloneValue(c));
          if (Utils.isNotEmptyOrSpace(v)) {
            coordonnees = v;
            break;
          }
        }

        String template = null;
        List<Cell> ts = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_template"));
        String w = null;
        for (Cell t : ts) {
          w = Bytes.toString(CellUtil.cloneValue(t));
          if (Utils.isNotEmptyOrSpace(w)) {
            template = w;
            break;
          }
        }

        String sendStatus = "";
        Timestamp interactionDate = new Timestamp(0);
        List<Cell> sendStatusCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_statut_envoi"));
        if (sendStatusCells.size() > 0) {
          Cell sendStatusCell = sendStatusCells.get(0);

          sendStatus = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(sendStatusCell)));
          interactionDate = Utils.getSqlTimestamp(sendStatusCell.getTimestamp());
        }

        String sendResult = "";
        Timestamp resultDate = new Timestamp(0);

        List<Cell> sendResultCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_resultat_envoi"));
        if (sendResultCells.size() > 0) {
          Cell sendResultCell = sendResultCells.get(0);

          sendResult = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(sendResultCell)));
          resultDate = Utils.getSqlTimestamp(sendResultCell.getTimestamp());
        }

        json = new HashMap<String, Object>();

        json.put("ID_TENTATIVE", id + "_" + trialId);
        json.put("ID_TECH", id);
        json.put("CODE_STATUT", sendStatus);
        json.put("DATE_INTERACTION", interactionDate);
        json.put("CODE_RES_ENV", sendResult);
        json.put("CODE_RES_ENV_DETAIL", sendResultDetails);
        json.put("DATE_RES_ENV", resultDate);
        json.put("LIB_CANAL_RET", chanel);
        json.put("CD_MESSAGE", template);
        json.put("DATE_INSERTION", new Timestamp(new Date().getTime()));
        json.put("COORDONNEE", coordonnees);

        list.add(new Tuple2<Object, Object>(id + "_" + trialId, json));
      }
    }

    return list;
  }

  // ------------------------------------------------------------------------------
  // DATA MEMEBERS
  // ------------------------------------------------------------------------------

  private static final long serialVersionUID = -8910485128148385287L;
}
