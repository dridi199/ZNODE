package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SaveMode;


import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.common.connector.jdbc.SqlServerConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;
import fr.edf.dco.contacts.bhc.batch.spark.functions.MapFeedBackResultToRowFunction;
import fr.edf.dco.contacts.bhc.batch.spark.functions.MapReactionResultToRowFunction;
import fr.edf.dco.contacts.bhc.batch.spark.functions.MapTargetingResultToRowFunction;
import scala.Tuple2;

/**
 * publie les donnees depuis hbase vers SQLServer
 * 
 * @author ahmed-externe.dridi@edf.fr
 *
 */
public class HbaseToSqlServerByRowKeyJob {

  public static void main(String[] args) {
   
        // spark application settings
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HBASE_SQL_SERVER);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);
    SQLContext sqlContext = new SQLContext(sparkContext);
    ApplicationContext context = ApplicationContext.getInstance();
    JavaRDD<Result> hbaseRDD = sparkContext.wholeTextFiles("/user/dco_app_bhc/tmp/RowKeysToUpdate").map(new Function<Tuple2<String,String>, List<Result>>() {
      private static final long serialVersionUID = 6111188139369500719L;

      @Override
      public List<Result> call(Tuple2<String,String> t) throws Exception {
        // getting environment context
        ApplicationContext context = ApplicationContext.getInstance();
        HbaseConnector hbase = context.getHbase();
        // configuring HBASE
        Configuration hbaseConfiguration = hbase.getConfiguration();
        hbaseConfiguration.set(TableInputFormat.SCAN_MAXVERSIONS, "30");
        hbaseConfiguration.set(TableInputFormat.SCAN_COLUMN_FAMILY, "S");
        hbaseConfiguration.setInt("hbase.rpc.timeout", 24000000);
        hbaseConfiguration.setInt("hbase.client.scanner.timeout.period", 24000000);
        // creating RDD from HBASE tables
        hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
        hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));   
        
        String[] rowkey=t._2.replaceAll(";", ",").replaceAll("\n", "").replaceAll("\r", "").replaceAll(",,", ",").split(",");
       
        List<Result> list = new ArrayList<Result>();
        int i = 0;
        while(i<rowkey.length-1){
          Result r =hbase.getRow(rowkey[i]);
          String id = Utils.getEmptyIfNull(Bytes.toString(r.getRow()));
          if(!id.equals("")&&!id.equals(" ")){
          list.add(r);
          }
          i++;
        }
        return list;
      }
    }).flatMap(new FlatMapFunction<List<Result>,Result>() {

      private static final long serialVersionUID = -6970025952348464419L;

      @Override
      public Iterable<Result> call(List<Result> listresult) throws Exception {
        return listresult;
      }
    });
    // MS SQL Server settings
    if (context.getProperty(Constants.PROPERTIES_SQL_SERVER_TARGET).equals("p")) {
      hbaseToSqlServer(ApplicationContext.getInstance().getSqlServerProd(Constants.SQL_SERVER_REPORTING_DB), hbaseRDD, sqlContext,"Prod");
    } else if (context.getProperty(Constants.PROPERTIES_SQL_SERVER_TARGET).equals("pp")) {
      hbaseToSqlServer(ApplicationContext.getInstance().getSqlServerPreprod(Constants.SQL_SERVER_REPORTING_DB), hbaseRDD, sqlContext,"PProd");
    } else if (context.getProperty(Constants.PROPERTIES_SQL_SERVER_TARGET).equals("y")){
      hbaseToSqlServer(ApplicationContext.getInstance().getSqlServerProd(Constants.SQL_SERVER_REPORTING_DB), hbaseRDD, sqlContext,"Prod");
      hbaseToSqlServer(ApplicationContext.getInstance().getSqlServerPreprod(Constants.SQL_SERVER_REPORTING_DB), hbaseRDD, sqlContext,"PProd");

    }
 
  }

  
  private static void hbaseToSqlServer(SqlServerConnector sqlServer, JavaRDD<Result> hbaseRDD, SQLContext sqlContext, String env) {
    ApplicationContext context = ApplicationContext.getInstance();
    Properties sqlServerOptions = new Properties();

    sqlServerOptions.put("driver", sqlServer.getDriverClassName());
    sqlServerOptions.put("url", sqlServer.getConnectionUrl());
    sqlServerOptions.put("user", sqlServer.getUser());
    sqlServerOptions.put("password", sqlServer.getUserPwd());   

    // initializing spark user defined functions
    MapTargetingResultToRowFunction targetingFunction = new MapTargetingResultToRowFunction();
    MapFeedBackResultToRowFunction interactionFunction = new MapFeedBackResultToRowFunction();
    MapReactionResultToRowFunction reactionFunction = new MapReactionResultToRowFunction();

    // ------------------------------------------------------------------------------
    // Processing Targeting Records
    // ------------------------------------------------------------------------------
    
    // creating RDD of SQLServer rows
    JavaRDD<Row> sqlTargetingRows = hbaseRDD.map(targetingFunction);

    // converting hive rows RDD to data frame
    DataFrame targetingDataFrame = sqlContext.createDataFrame(sqlTargetingRows, targetingFunction.TARGETING_SCHEMA_SQL);

    // acquittal and writing to SQLServer
    context.acquitHbaseToSql(Constants.ACQUITTAL_TARGETING_TABLE_SHORT_NAME, Constants.ACQUITTAL_START, new Timestamp(new Date().getTime()), env);
    targetingDataFrame.write().mode(SaveMode.Append).jdbc(sqlServer.getConnectionUrl(), context.getProperty(Constants.PROPERTIES_SQL_SERVER_TARGETING_TABLE), sqlServerOptions);
    context.acquitHbaseToSql(Constants.ACQUITTAL_TARGETING_TABLE_SHORT_NAME, Constants.ACQUITTAL_END, new Timestamp(new Date().getTime()), env);

    // ------------------------------------------------------------------------------
    // Processing Interaction Records
    // ------------------------------------------------------------------------------

    // creating RDD of SQLServer rows
    JavaRDD<Row> sqlInteractionRows = hbaseRDD.flatMap(interactionFunction);

    // converting hive rows RDD to data frame
    DataFrame interactionDataFrame = sqlContext.createDataFrame(sqlInteractionRows, interactionFunction.FEED_BACK_SCHEMA_SQL);

    // acquittal and writing to SQLServer
    context.acquitHbaseToSql(Constants.ACQUITTAL_FEED_BACK_TABLE_SHORT_NAME, Constants.ACQUITTAL_START, new Timestamp(new Date().getTime()), env);
    interactionDataFrame.write().mode(SaveMode.Append).jdbc(sqlServer.getConnectionUrl(), context.getProperty(Constants.PROPERTIES_SQL_SERVER_FEED_BACK_TABLE), sqlServerOptions);
    context.acquitHbaseToSql(Constants.ACQUITTAL_FEED_BACK_TABLE_SHORT_NAME, Constants.ACQUITTAL_END, new Timestamp(new Date().getTime()), env);

    // ------------------------------------------------------------------------------
    // Processing Reaction Records
    // ------------------------------------------------------------------------------

    // creating RDD of SQLServer rows
    JavaRDD<Row> sqlReactionRows = hbaseRDD.flatMap(reactionFunction);

    // converting hive rows RDD to data frame
    DataFrame reactionDataFrame = sqlContext.createDataFrame(sqlReactionRows, reactionFunction.REACTION_SCHEMA_SQL);

    // acquittal and writing to SQLServer
    context.acquitHbaseToSql(Constants.ACQUITTAL_REACTION_TABLE_SHORT_NAME, Constants.ACQUITTAL_START, new Timestamp(new Date().getTime()), env);
    reactionDataFrame.write().mode(SaveMode.Append).jdbc(sqlServer.getConnectionUrl(), context.getProperty(Constants.PROPERTIES_SQL_SERVER_REACTION_TABLE), sqlServerOptions);
    context.acquitHbaseToSql(Constants.ACQUITTAL_REACTION_TABLE_SHORT_NAME, Constants.ACQUITTAL_END, new Timestamp(new Date().getTime()), env);
  }
  
}
