package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.hadoop.hbase.client.Put;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;

import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.base.Utils;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;
/**
 * do a reputake using hive table with structured data (file_name,id_tech,device...)
 * @author ahmed-externe.dridi@edf.fr
 *
 */
public class HiveToHbaseJob {

  public static void main(String[] args) {

    final String table = args[0];
    final String separator = args[1];
    final String distributionColumn = args[2];
    final String filter = args[3];

    // spark application settings
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HIVE_HBASE);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);
    HiveContext hiveContext = new HiveContext(sparkContext);

    // Retrieving Hive table
    JavaRDD<Row> tableContentRDD = hiveContext.sql("select * from " + table + " DISTRIBUTE BY " + distributionColumn).toJavaRDD();
    tableContentRDD=tableContentRDD.filter(new Function<Row, Boolean>() {
      private static final long serialVersionUID = 4227508148921998101L;

      @Override
      public Boolean call(Row row) throws Exception {
        return row.getString(0).contains(filter);
      }
    });
//    tableContentRDD.persist(StorageLevel.MEMORY_AND_DISK());
    // hbase puts
    tableContentRDD.foreachPartition(new VoidFunction<Iterator<Row>>() {

      private static final long serialVersionUID = -5844753255324191699L;

      @Override
      public void call(Iterator<Row> rows) throws Exception {
        ApplicationContext context = ApplicationContext.getInstance();
        ContactFactory factory = new ContactFactory();

        String line = null;
        AbstractContactRecord record = null;
        while (rows.hasNext()) {
          try {
            line = rows.next().mkString(separator);

            record = factory.createRecord(line.substring(0, line.indexOf(separator)));
            record.parse(line.substring(line.indexOf(separator) + 1, line.length()));
            record.storeToHbase();
          } catch (Exception e) {
            // log later ..
          }
        }

        HbaseConnector hbase = context.getHbase();
        HashMap<String, Put> contacts = context.getContactPuts();

        if (contacts != null && contacts.size() > 0) {

          hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
          hbase.multiPut(new ArrayList<Put>(contacts.values()));

          for (String key : contacts.keySet()) {
            contacts.put(key, Utils.resultToNoVersionPut(hbase.getRow(key), contacts.get(key)));
          }

//          hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
//          hbase.multiPut(new ArrayList<Put>(contacts.values()));

          context.resetContactPuts();
        }    
      }
    });
  }
}
