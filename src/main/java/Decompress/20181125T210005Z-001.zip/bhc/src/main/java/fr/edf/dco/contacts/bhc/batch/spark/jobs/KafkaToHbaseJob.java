package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.streaming.kafka.KafkaUtils;
import org.apache.spark.streaming.kafka.OffsetRange;

import fr.edf.dco.common.connector.misc.KafkaConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;
import kafka.serializer.StringDecoder;
import scala.Tuple2;

/**
 * An ETL spark job where extraction is based on a KAFKA topic, transformation
 * on an Abstract factory and loading on HBASE tables
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class KafkaToHbaseJob {

  public static void main(String[] args) {
    // getting environment settings
    ApplicationContext app = ApplicationContext.getInstance();
    KafkaConnector kafka = app.getKafka(Constants.PROPERTIES_KAFKA_STREAM_TOPICS);

    // getting KAFKA partitions and offsets
    String streamTopic = app.getProperty(Constants.PROPERTIES_KAFKA_STREAM_TOPICS);
    HashMap<String, String> kafkaParams = kafka.getKafkaParams("smallest", false);
    List<OffsetRange> offsetRangeList = new ArrayList<OffsetRange>();
    List<Integer> StreamPartitions = kafka.getPartitionsForTopic();

    for (int partition : StreamPartitions) {
      List<Long> offsets = kafka.findAllOffsets(partition);

      if (offsets.size() > 1) {
        offsetRangeList.add(OffsetRange.create(streamTopic, partition, offsets.get(offsets.size() - 1), offsets.get(offsets.size() - 2)));
      }
    }

    OffsetRange[] offsetRange = new OffsetRange[offsetRangeList.size()];

    for (int i = 0; i < offsetRangeList.size(); i++) {
      offsetRange[i] = offsetRangeList.get(i);
    }

    // creating spark application
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_KAFKA_HBASE);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);

    // creating kafka RDD
    JavaPairRDD<String, String> kafkaRDD = KafkaUtils.createRDD(sparkContext, String.class, String.class, StringDecoder.class, StringDecoder.class, kafkaParams, offsetRange);

    // creating HBASE RDD after pushing lines to abstract factory and parsing
    // them
    kafkaRDD.foreachPartition(new VoidFunction<Iterator<Tuple2<String, String>>>() {

      @Override
      public void call(Iterator<Tuple2<String, String>> messages) throws Exception {
        ContactFactory factory = new ContactFactory();

        Tuple2<String, String> message = null;
        AbstractContactRecord record = null;
        while (messages.hasNext()) {
          message = messages.next();

          try {
            record = factory.createRecord(Constants.CONTACT_MESSAGE_EDIWAY_EDIFUZ);
            record.parse(message._2());
            record.storeToHbase();
          } catch (Exception e) {
            // ignore, nothing to do
          }
        }

        ApplicationContext.getInstance().flushContacts(false);
      }

      private static final long serialVersionUID = 3405568676967362666L;
    });
  }
}
