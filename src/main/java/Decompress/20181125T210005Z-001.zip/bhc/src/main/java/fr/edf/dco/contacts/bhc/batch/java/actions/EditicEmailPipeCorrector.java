package fr.edf.dco.contacts.bhc.batch.java.actions;


import java.io.IOException;
import java.sql.SQLException;

import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.util.Bytes;

import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * 
 * @author ahmed-externe.dridi@edf.fr
 *
 * some record have a pipe in the email that cause a translation of column when insertion to Sql
 */
public class EditicEmailPipeCorrector {
public static void main(String[] args) throws IOException, SQLException{
  ApplicationContext context = ApplicationContext.getInstance();
  HbaseConnector hbase = context.getHbase();
  hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
//  SqlServerConnector sql = context.getSqlServerPreprod(Constants.SQL_SERVER_REPORTING_DB);
  ResultScanner rs =hbase.scan(false);
//  Result result = hbase.getRow("TICFLX20171209006692100484_08001");
  for(Result result : rs){
//    System.out.println(Bytes.toString(r.getValue(Utils.getBytes("B"), Utils.getBytes("ligne_ciblage"))));
//    System.out.println(Bytes.toString(r.getRow()));
//    String rowkey=Bytes.toString(result.getRow());

    String id = Utils.getEmptyIfNull(Bytes.toString(result.getRow()));
//    String codeRegroupement = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_code_regroupement"))));
//    String traitement = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_code_traitement"))));
//    String canal = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_canal"))));
//    String statut = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("a_statut"))));
//
//    List<Cell> cells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_statut"));
//    long ts = 0;
//    for (Cell cell : cells) {
//      if (cell.getTimestamp() > ts) {
//        ts = cell.getTimestamp();
//      }
//    }
//
//    Timestamp dateStatut = new Timestamp(ts);
//
//    String typeNonEnv = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_type_nenv"))));
//    String tent = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("a_tentative"))));
//    String tentative = Utils.getEmptyIfNull(Utils.isNotEmptyOrSpace(tent) ? id + "_" + tent : "");
//    String bp = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_bp"))));
//
//    if (bp != null && bp.length() > 10) {
//      bp = bp.substring(0, 9);
//    }
//
//    String local = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_local"))));
//    String accordCo = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_accord_co"))));
//    String region = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_region"))));
//    boolean condition =(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_date"))==null) ;
//    Timestamp dateCiblage =(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_date"))==null) ? new Timestamp(0) : Utils.getSqlTimestamp(Utils.getLongTimestamp(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_date"))), "dd/MM/yyyy HH:mm:ss"));
//    String flux = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_flux"))));
//    String editicGroupCode = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_code_regroupement_editic"))));
//    String logicalInsert = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_mkt_log"))));
//    String physicalInsert = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_ref_insert_mkt_phy"))));
//    String pagesCount = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_nb_pages"))));
    String marche = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"))));
    
    if(marche.startsWith("https://"))
    System.out.println(id);
    //  TICFLX20171209006692100484_08001,TICFLX20171217006855801873_08001 TICFLX20171209006692100484_08001,TICFLX20180109007281700653_08001
    
//    if(id.startsWith("TIC") && id!="TICFLX20171217006855801873_08001"){
//    sql.executeUpdate("Insert into SAS_CIB_BHC (ID_TECH,CODE_REGROUPEMENT,CODE_TRAITEMENT,LIB_CANAL_CIB,LIB_STATUT,DATE_STATUT,TYPE_NENV,ID_TENTATIVE,ID_CLIENT_BP,ID_CLIENT_LOCAL,ID_CLIENT_ACCORD_CO,CODE_REGION,DATE_CIBLAGE,FLUX,MARCHE,CODE_REGROUPEMENT_EDITIC,REF_INSERT_MKT_LOG,REF_INSERT_MKT_PHY,NB_PAGES,DATE_INSERTION) values ('"+id+"','"+codeRegroupement+"','"+traitement+"','"+canal+"','"+statut+"','"+dateStatut+"','"+typeNonEnv+"','"+tentative+"','"+bp+"','"+local+"','"+accordCo+"','"+region+"','"+dateCiblage+"','"+flux+"','"+marche+"','"+editicGroupCode+"','"+logicalInsert+"','"+physicalInsert+"','"+pagesCount+"','2017-12-11 11:59:59')");
//    }
//  if(Bytes.toString(r.getValue(Utils.getBytes("B"), Utils.getBytes("ligne_ciblage"))) == null){
//    System.out.println(Bytes.toString(r.getValue(Utils.getBytes("B"), Utils.getBytes("ligne_retour"))));
//
  }
  }
  

//  
  
  
//  }

public static void isItBinary(String s){
  byte[] bytes = s.getBytes();
  StringBuilder binary = new StringBuilder();
  for (byte b : bytes)
  {
     int val = b;
     for (int i = 0; i < 8; i++)
     {
        binary.append((val & 128) == 0 ? 0 : 1);
        val <<= 1;
     }
     binary.append(' ');
  }
  System.out.println("'" + s + "' to binary: " + binary);
}
}

