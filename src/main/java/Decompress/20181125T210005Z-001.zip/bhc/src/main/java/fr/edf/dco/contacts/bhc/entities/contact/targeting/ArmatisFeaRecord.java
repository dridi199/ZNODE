package fr.edf.dco.contacts.bhc.entities.contact.targeting;

import java.text.ParseException;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Pattern;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;
import fr.edf.dco.contacts.bhc.entities.cartography.Cartography;

/**
 * Represents an ARMATIS FEA targeting contact record
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class ArmatisFeaRecord extends TargetingRecord {

  // ------------------------------------------------------------------
  // CONSTRUCTOR
  // ------------------------------------------------------------------

  /**
   * Constructs a new ArmatisFeaContactRecord
   * 
   * @param file
   */
  public ArmatisFeaRecord(String file) {
    super(file, ";", Constants.CONTACT_STREAM_ARMATIS_FEA, 99, null, false);
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------

  @Override
  protected void process(String[] fields) throws CustomException {
    this.targetingLine = new TargetingLine();

    targetingLine.market = Constants.CONTACT_MARKET_MM;

    line.businessPartner = fields[0].trim();
    line.noSendType = (!fields[96].trim().equals("CIBLE")) ? fields[96].trim() : "";
    codeType = fields[97].trim();
    line.groupCode = "FACTU_ELEVEE_" + codeType;
    targetingLine.comAgree = fields[2].trim();
    targetingLine.billNumber = fields[4].trim();
    targetingLine.email = fields[34].trim();
    targetingLine.mobilePhone = fields[32].trim();

    targetingLine.targetingDateBase = fileName.substring(fileName.indexOf(".csv") - 8, fileName.indexOf(".csv"));
    try {
      targetingLine.targetingDate = Utils.formatDate(targetingLine.targetingDateBase, "yyyyMMdd", "dd/MM/yyyy HH:mm:ss");
    } catch (ParseException e) {
      throw new CustomException("could not parse date : " + targetingLine.targetingDate + " from yyyyMMdd to dd/MM/yyyy HH:mm:ss format");
    }

    line.communicationID = "ARMMM" + line.businessPartner + "FEA" + targetingLine.targetingDateBase;

    loadCartography();
    targetingLine.hm = loadBhcParamAlim(fields);
  }

  @Override
  protected void setCartography() throws CustomException {
    Set<Cartography> cartographies = ApplicationContext.getInstance().getCartography().get(line.groupCode);
    Iterator<Cartography> iterator = cartographies.iterator();

    while (iterator.hasNext()) {
      Cartography entry = iterator.next();
      if (entry.getStrategy().contains(line.chanel)) {
        targetingLine.cartography = entry;
        break;
      }
    }
  }

  @Override
  protected void loadCartography() throws CustomException {
    boolean valid = true;

    // Armatis filters
    if (codeType.equals("NO_MATCH")) {
      valid = false;
      line.noSendType = "NO_MATCH";
    } else {
      if (line.noSendType.contains("NULL") || line.noSendType.contains("INVALIDE")) {
        valid = false;
        line.template = "FACTU_ELEVEE_NO_COORD";
        line.noSendType = "COORD_NULL_OU_INVALIDE";
      } else if (line.noSendType.equals("TEMOIN") || line.noSendType.equals("EXCLUSION")) {
        valid = false;
        line.template = "FACTU_ELEVEE_" + line.noSendType;
      } else {
        line.noSendType = "";
        valid = true;
      }
    }

    if (!valid) {
      line.groupCode = "FACTU_ELEVEE";
      line.status = Constants.CONTACT_STATUS_NON_ENVOYE;
    } else {
      line.chanel = buildChanel();

      if (line.chanel != null) {
        setCartography();

        line.status = Constants.CONTACT_STATUS_TRANSMIS;

        if (targetingLine.cartography != null) {
          line.template = targetingLine.cartography.getTemplate();
          line.strategy = targetingLine.cartography.getStrategy();
        }
      } else {
        throw new CustomException("Unconsistency exception: valid message but not valid contact information !! : " + line.raw);
      }
    }
  }

  @Override
  protected String buildChanel() {
    String patternEmail = ".*@.*\\..+";
    boolean isMatch = Pattern.matches(patternEmail, targetingLine.email);

    if (isMatch) {
      line.contactInformation = targetingLine.email;
      return Constants.CONTACT_CANAL_EMAIL;
    } else if (targetingLine.mobilePhone != null && Utils.isNotEmptyOrSpace(targetingLine.mobilePhone) && (targetingLine.mobilePhone.length() == 10) && (targetingLine.mobilePhone.startsWith("06") || targetingLine.mobilePhone.startsWith("07"))) {
      line.contactInformation = targetingLine.mobilePhone;
      return Constants.CONTACT_CANAL_SMS;
    }

    return null;
  }

  // ------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------
  private String codeType;

}
