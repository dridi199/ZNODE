package fr.edf.dco.contacts.bhc.entities.contact.feedback;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * AWL ETL SIMM feed back record representation
 * 
 * @author fahd-externe.essid@edf.fr
 */
public abstract class AwlFeedBackRecord extends FeedBackRecord {

  // -------------------------------------------------------------------
  // CONSTRUCTORS
  // -------------------------------------------------------------------

  public AwlFeedBackRecord(String file, int fieldsCount) {
    super(file, ";", Constants.CONTACT_STREAM_ETL_SIMM, fieldsCount, Constants.CONTACT_HEADER_AWL_FEED_BACK, false);
  }

  // -------------------------------------------------------------------
  // IMPLENTATION
  // -------------------------------------------------------------------

  public static AwlFeedBackRecord getRecord(String file) throws CustomException {
    if (file.contains(Constants.CONTACT_FILE_AWL_MESSAGES_SENT)) {
      return new MessageSent(file);
    } else if (file.contains(Constants.CONTACT_FILE_AWL_NOTIFICATIONS)) {
      return new Notification(file);
    } else if (file.contains(Constants.CONTACT_FILE_AWL_MESSAGES_RECEIVED)) {
      return new MessageReceived(file);
    } else if (file.contains(Constants.CONTACT_FILE_AWL_EMAIL_TRACKING)) {
      return new EmailTracking(file);
    } else {
      throw new CustomException("Unknown ETL SIMM Feed Back File " + file, file);
    }
  }

  // -------------------------------------------------------------------
  // INNER CLASS : MessageSent
  // -------------------------------------------------------------------

  public static class MessageSent extends AwlFeedBackRecord {

    public MessageSent(String file) {
      super(file, 17);
    }

    @Override
    protected void process(String[] fields) throws CustomException {
      line.communicationID = fields[0].trim();

      line.groupCode = fields[1].trim();
      line.referenceCategory = fields[2].trim();
      this.attempt = fields[4].trim();
      line.strategy = fields[5].trim();
      line.template = fields[6].trim();
      this.sendRuleOrder = fields[7].trim();
      line.chanel = fields[8].trim().replace("SVI", Constants.CONTACT_CANAL_PUSH_VOCAL);
      line.contactInformation = fields[9].trim();
      this.content = fields[10].trim();
      this.operator = fields[11].trim();
      this.step = fields[12].trim();
      this.stepDetail = fields[13].trim();
      this.callDuration = fields[16].trim();

      try {
        this.rawDate = Utils.dateFromString(fields[14].trim(), "yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
      } catch (ParseException e) {
        throw new CustomException("Could not parse date : " + rawDate + " error : " + e.getMessage());
      }

      if (!Utils.isNotEmptyOrSpace(line.communicationID)) {
        line.communicationID = fields[3].trim();
      }

      this.sentToOperator = fields[15].trim();

      validate();
      date = rawDate.getTime();
    }

    @Override
    public void storeToHbase() throws IOException {
      if (Utils.isNotEmptyOrSpace(line.communicationID)) {
        String initial = "t_" + trialId + "_";

        line.put = Utils.getContactPut(line.communicationID);
        
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), date, Utils.getBytes(line.raw));
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), date, Utils.getBytes(fileName));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), date, Utils.getBytes(Constants.CONTACT_MARKET_MM));

        if (date != 0) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "contenu"), date, Utils.getBytes(content));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "operateur"), date, Utils.getBytes(operator));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), date, Utils.getBytes(line.status));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_type_nenv"), date, Utils.getBytes(line.noSendType));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "callDuration"), date, Utils.getBytes(callDuration));

          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "template"), date, Utils.getBytes(line.template));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "canal"), date, Utils.getBytes(line.chanel));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "coordonnee"), date, Utils.getBytes(line.contactInformation));
        }
      }
    }

    @SuppressWarnings("deprecation")
    private void validate() {
      this.trialId = new Integer(sendRuleOrder + attempt).intValue();

      if (step.equals(Constants.CONTACT_STATUS_PENDING)) {
        line.status = Constants.CONTACT_STATUS_EN_COURS;
        line.noSendType = null;
      } else if ((step.equals(Constants.CONTACT_STATUS_SUCCESS)) && sentToOperator.equals("YES")) {
        rawDate.setSeconds(rawDate.getSeconds() + 1);
        line.status = Constants.CONTACT_STATUS_ENVOYE;
        line.noSendType = null;
      } else if (step.equals(Constants.CONTACT_STATUS_ERROR)) {
        rawDate.setSeconds(rawDate.getSeconds() + 2);
        if (sentToOperator.equals("YES")) {
          line.status = Utils.transcode(stepDetail);
          line.noSendType = null;
        } else {
          line.status = Constants.CONTACT_STATUS_NON_ENVOYE;
          line.noSendType = stepDetail;
        }
      }
    }

    private String operator;
    private String callDuration;
  }

  // -------------------------------------------------------------------
  // INNER CLASS : Notification
  // -------------------------------------------------------------------

  public static class Notification extends AwlFeedBackRecord {

    public Notification(String file) {
      super(file, 13);
    }

    @Override
    protected void process(String[] fields) throws CustomException {
      line.communicationID = fields[0].trim();
      attempt = fields[3].trim();
      sendRuleOrder = fields[6].trim();

      try {
        this.rawDate = Utils.dateFromString(fields[9].trim(), "yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
      } catch (ParseException e) {
        throw new CustomException("Could not parse date : " + rawDate + " error : " + e.getMessage());
      }

      if (!Utils.isNotEmptyOrSpace(line.communicationID)) {
        line.communicationID = fields[2].trim();
      }

      this.step = fields[10].trim();
      this.stepDetail = fields[11].trim();
      this.sentToOperator = fields[12].trim();

      validate();
      date = rawDate.getTime();
    }

    @Override
    public void storeToHbase() throws IOException {
      if (Utils.isNotEmptyOrSpace(line.communicationID) && isValid) {

        String initial = "t_" + trialId + "_";

        line.put = Utils.getContactPut(line.communicationID);

        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), date, Utils.getBytes(line.raw));
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), date, Utils.getBytes(fileName));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), date, Utils.getBytes(Constants.CONTACT_MARKET_MM));

        if (date != 0) {
          if (!Utils.valueAlreadyExists(line.communicationID, String.valueOf(trialId), "S", "a_tentative")) {
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_tentative"), date, Utils.getBytes(Integer.toString(trialId)));
          }

          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "statut_envoi"), date, Utils.getBytes(sendStatus));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "resultat_envoi"), date, Utils.getBytes(sendResult));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "resultat_envoi_detail"), date, Utils.getBytes(sendResultDetail));
        }
      }
    }

    @SuppressWarnings("deprecation")
    protected void validate() {
      this.trialId = new Integer(sendRuleOrder + attempt).intValue();
      isValid = true;

      if (step != null) {
        if (step.equals(Constants.CONTACT_STATUS_ERROR)) {
          if (stepDetail.equals(Constants.CONTACT_STATUS_UNKNOWN_ERROR)) {
            isValid = false;
          } else {
            sendResultDetail = stepDetail;
            rawDate.setSeconds(rawDate.getSeconds() + 2);

            if (sentToOperator.equals("NO")) {
              sendStatus = Constants.CONTACT_STATUS_NON_ENVOYE;
              sendResult = null;
            } else {
              sendStatus = Constants.CONTACT_STATUS_ENVOYE;
              sendResult = Utils.transcode(stepDetail);
            }
          }
        } else if (step.equals(Constants.CONTACT_STATUS_PENDING)) {
          if (sentToOperator.equals("NO")) {
            sendStatus = Constants.CONTACT_STATUS_EN_COURS;
            sendResult = null;
            sendResultDetail = null;
          } else {
            sendStatus = Constants.CONTACT_STATUS_ENVOYE;
            sendResult = Constants.CONTACT_STATUS_EN_COURS;
            sendResultDetail = stepDetail;
          }
        } else if (step.equals(Constants.CONTACT_STATUS_SUCCESS)) {
          sendStatus = Constants.CONTACT_STATUS_ENVOYE;
          sendResult = null;
          sendResultDetail = stepDetail;
          rawDate.setSeconds(rawDate.getSeconds() + 1);
        }
      } else {
        isValid = false;
      }
    }

  }

  // -------------------------------------------------------------------
  // INNER CLASS : MessageReceived
  // -------------------------------------------------------------------

  public static class MessageReceived extends AwlFeedBackRecord {

    public MessageReceived(String file) {
      super(file, 9);
    }

    @Override
    protected void process(String[] fields) throws CustomException {
      line.communicationID = fields[0].trim();

      try {
        this.rawDate = Utils.dateFromString(fields[5].trim(), "yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
      } catch (ParseException e) {
        throw new CustomException("Could not parse date : " + rawDate + " error : " + e.getMessage());
      }

      this.content = fields[6].trim();
      this.attempt = fields[7].trim();
      this.sendRuleOrder = fields[8].trim();

      this.trialId = new Integer(sendRuleOrder + attempt).intValue();
      date = rawDate.getTime();
    }

    @Override
    public void storeToHbase() throws IOException {
      if (Utils.isNotEmptyOrSpace(line.communicationID)) {

        String initial = "t_" + trialId + "_";

        line.put = Utils.getContactPut(line.communicationID);
        
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), date, Utils.getBytes(line.raw));
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), date, Utils.getBytes(fileName));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), date, Utils.getBytes(Constants.CONTACT_MARKET_MM));

        if (date != 0) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), date, Utils.getBytes(Constants.CONTACT_STATUS_RESPONSE));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction_contenu"), date, Utils.getBytes(content));
        }
      }
    }
  }

  // -------------------------------------------------------------------
  // INNER CLASS : EmailTracking
  // -------------------------------------------------------------------

  public static class EmailTracking extends AwlFeedBackRecord {

    public EmailTracking(String file) {
      super(file, 18);
    }

    @Override
    protected void process(String[] fields) throws CustomException {
      line.communicationID = fields[0].trim();

      try {
        this.rawDate = Utils.dateFromString(fields[11].trim(), "yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
      } catch (ParseException e) {
        throw new CustomException("Unable to parse date : " + rawDate + " error : " + e.getMessage());
      }

      if (!Utils.isNotEmptyOrSpace(line.communicationID)) {
        line.communicationID = fields[3].trim();
      }

      this.attempt = fields[4].trim();
      this.sendRuleOrder = fields[7].trim();
      this.action = fields[10].trim();
      this.url = fields[12].trim();
      this.device = Utils.transcode(fields[13].trim());
      this.browser = fields[14].trim();
      this.browserVersion = fields[15].trim();
      this.os = fields[16].trim();
      this.osVersion = fields[17].trim();

      this.trialId = new Integer(sendRuleOrder + attempt).intValue();
      date = rawDate.getTime();
    }

    @Override
    public void storeToHbase() throws IOException {
      if (Utils.isNotEmptyOrSpace(line.communicationID)) {

        String initial = "t_" + trialId + "_";

        line.put = Utils.getContactPut(line.communicationID);
        
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), date, Utils.getBytes(line.raw));
        line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), date, Utils.getBytes(fileName));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), date, Utils.getBytes(Constants.CONTACT_MARKET_MM));

        if (date != 0) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "device"), date, Utils.getBytes(device));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "device_browser"), date, Utils.getBytes(browser));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "device_browser_version"), date, Utils.getBytes(browserVersion));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "device_ois"), date, Utils.getBytes(os));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "device_ois_version"), date, Utils.getBytes(osVersion));

          if (action.equals(Constants.CONTACT_STATUS_OPEN)) {
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), date, Utils.getBytes(Constants.CONTACT_STATUS_OUVERT));
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), date, Utils.getBytes("OUVERT"));
          } else if (action.equals("CLICK")) {
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), date, Utils.getBytes(Constants.CONTACT_STATUS_CLIC));
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction_clic_url"), date, Utils.getBytes(url));
          } else if (action.equals("UNSUBSCRIBE")) {
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), date, Utils.getBytes(Constants.CONTACT_STATUS_OPTOUT));
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "optout"), date, Utils.getBytes(Constants.CONTACT_STATUS_OPTOUT));
          } else if (action.equals("MIRROR")) {
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), date, Utils.getBytes(Constants.CONTACT_STATUS_MIRROR_PAGE));
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "mirror"), date, Utils.getBytes(Constants.CONTACT_STATUS_MIRROR_PAGE));
          }
        }
      }
    }

    private String action;
    private String url;
    private String device;
    private String browser;
    private String browserVersion;
    private String os;
    private String osVersion;
  }

  // -------------------------------------------------------------------
  // DATA MEMBERS
  // -------------------------------------------------------------------

  protected String attempt;
  protected String sendRuleOrder;
  protected String stepDetail;
  protected Date rawDate;
  protected long date;
  protected String sentToOperator;
  protected String step;
  protected String sendStatus;
  protected String sendResult;
  protected String sendResultDetail;
  protected String content;
  protected boolean isValid;
}
