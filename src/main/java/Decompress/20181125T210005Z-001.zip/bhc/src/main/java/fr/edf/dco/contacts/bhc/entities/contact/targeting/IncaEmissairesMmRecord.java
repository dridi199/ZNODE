package fr.edf.dco.contacts.bhc.entities.contact.targeting;

import java.text.ParseException;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * Inca Emissaire MM Targeting contact Record
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class IncaEmissairesMmRecord extends TargetingRecord {

  public IncaEmissairesMmRecord(String file) {
    super(file, "\\|", Constants.CONTACT_STREAM_INCA_EMISSAIRES_MM, 42, "ID_TECH", false);
  }

  @Override
  protected void process(String[] fields) throws CustomException {
    this.targetingLine = new TargetingLine();

    targetingLine.market = Constants.CONTACT_MARKET_MM;

    line.communicationID = fields[0];

    if (!line.communicationID.startsWith("MM")) {
      throw new CustomException("Invalid Inca Cabestan Row Key : " + line.communicationID);
    }

    line.businessPartner = fields[13].trim();
    String temp = fileName.substring(0, fileName.lastIndexOf("_") - 10);
    line.groupCode = temp.substring(temp.lastIndexOf("_") + 1, temp.length());

    targetingLine.adress1 = fields[2].trim();
    targetingLine.adress2 = fields[3].trim();
    targetingLine.adress3 = fields[4].trim();
    targetingLine.adress4 = fields[5].trim();
    targetingLine.adress5 = fields[6].trim();
    targetingLine.adress6 = fields[7].trim();
    targetingLine.adress7 = fields[8].trim();
    targetingLine.adress8 = fields[9].trim();
    targetingLine.adress9 = fields[10].trim();
    targetingLine.adress10 = fields[11].trim();

    targetingLine.adress = buildAdress();
    targetingLine.adressOk = Utils.isNotEmptyOrSpace(targetingLine.adress2) && Utils.isNotEmptyOrSpace(targetingLine.adress4) && Utils.isNotEmptyOrSpace(targetingLine.adress5) && Utils.isNotEmptyOrSpace(targetingLine.adress7);

    line.processCode = fields[12].trim();
    targetingLine.local = fields[16].trim().equals("0") ? "" : fields[16].trim();

    targetingLine.targetingDateBase = fileName.substring(fileName.indexOf(".txt") - 8, fileName.indexOf(".txt"));

    try {
      targetingLine.targetingDate = Utils.formatDate(targetingLine.targetingDateBase, "yyyyMMdd", "dd/MM/yyyy HH:mm:ss");
    } catch (ParseException e) {
      throw new CustomException("could not parse date : " + targetingLine.targetingDate + " from yyyyMMdd to dd/MM/yyyy HH:mm:ss format");
    }

    loadCartography();
    targetingLine.hm = loadBhcParamAlim(fields);
    line.status = Constants.CONTACT_STATUS_TRANSMIS;

  }

}
