package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SaveMode;

import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.common.connector.jdbc.SqlServerConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;
import fr.edf.dco.contacts.bhc.batch.spark.functions.MapFeedBackResultToRowFunction;
import fr.edf.dco.contacts.bhc.batch.spark.functions.MapReactionResultToRowFunction;
import fr.edf.dco.contacts.bhc.batch.spark.functions.MapTargetingResultToRowFunction;

/**
 * publie les donnees depuis hbase vers SQLServer
 * 
 * @author ahmed-externe.dridi@edf.fr
 *
 */
public class HbaseToSqlServerRepriseJob {

  public static void main(String[] args) {

    // getting environment context
    ApplicationContext context = ApplicationContext.getInstance();
    HbaseConnector hbase = context.getHbase();
    // ------------------------------------------------------------------------------
    // Stolen writing to HBase tables permission from kafkajobStreaming  
    // ------------------------------------------------------------------------------
    try {
      hbase.put(context.getProperty(Constants.PROPERTIES_HBASE_KAFKA_PARAMS_CONTACTS_TABLE),"6","H","h_access","false");
    } catch (IOException e) {
      e.printStackTrace();
    }
    
    // configuring HBASE
    Configuration hbaseConfiguration = hbase.getConfiguration();
    hbaseConfiguration.set(TableInputFormat.SCAN_MAXVERSIONS, "30");
    hbaseConfiguration.set(TableInputFormat.SCAN_COLUMN_FAMILY, "S");
    hbaseConfiguration.setInt("hbase.rpc.timeout", 24000000);
    hbaseConfiguration.setInt("hbase.client.scanner.timeout.period", 24000000);

    // spark application settings
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HBASE_SQL_SERVER);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);
    SQLContext sqlContext = new SQLContext(sparkContext);
    String nom_flux="";
    String fromdate="";
    // creating RDD from HBASE tables
    if(args[0].equals("delta")) {
      hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
      hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
    }
    else if (args[0].equals("full")) {
      hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
      hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));   
    }
     else{
       hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
       hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
       nom_flux=Utils.getEmptyIfNull(args[0]);
       
    }
    
    // Due to instability in the newAPIHadoopRDD function we will parallelize data from a hbase Java API Scan
    JavaRDD<Result> hbaseRDD = sparkContext.newAPIHadoopRDD(hbaseConfiguration, TableInputFormat.class, ImmutableBytesWritable.class, Result.class).values();
    
    if (nom_flux.length() > 0 && nom_flux != "") {
      // Filter by nom de flux
         final String[] fluxName = nom_flux.split(",",-1);
         hbaseRDD = hbaseRDD.filter(new Function<Result, Boolean>() {
           private static final long serialVersionUID = -8734939700009133492L;

           @Override
           public Boolean call(Result result) throws Exception {
             String flux = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_flux"))));
             return Arrays.asList(fluxName).contains(flux);
           }
         });
       }
    
    
    if(args[2] != null && args[2].length()>0 && args[2].contains("-")){
      fromdate=args[2]; 
      // Filter By date 2017
      String[] s = fromdate.split("-",-1);
      final int year = Integer.parseInt(s[0]);
      final int month = Integer.parseInt(s[1]);
      final int day = Integer.parseInt(s[2]);
      hbaseRDD = hbaseRDD.filter(new Function<Result, Boolean>() {
        private static final long serialVersionUID = -8734939700009133492L;
        @Override
        public Boolean call(Result result) throws Exception {
          Calendar calendar = Calendar.getInstance();
          calendar.set(Calendar.YEAR, year);
          calendar.set(Calendar.MONTH, month-1);
          calendar.set(Calendar.DATE, day);
          Date filterdate = calendar.getTime();
          Date date = Utils.dateFromString(Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_date")))),"dd/MM/yyyy HH:mm:ss");
          return date == null || date.after(filterdate); // after 2017/6=07(ou juillet)/9 (date == null => retours sans ciblage)
        }
      });
    }
   
    
    String whichTable=Utils.getEmptyIfNull(args[1]);
    // MS SQL Server settings
    if (context.getProperty(Constants.PROPERTIES_SQL_SERVER_TARGET).equals("p")) {
      hbaseToSqlServer(ApplicationContext.getInstance().getSqlServerProd(Constants.SQL_SERVER_REPORTING_DB), hbaseRDD, sqlContext,"Prod",whichTable);
    } else if (context.getProperty(Constants.PROPERTIES_SQL_SERVER_TARGET).equals("pp")) {
      hbaseToSqlServer(ApplicationContext.getInstance().getSqlServerPreprod(Constants.SQL_SERVER_REPORTING_DB), hbaseRDD, sqlContext,"PProd",whichTable);
    } else if (context.getProperty(Constants.PROPERTIES_SQL_SERVER_TARGET).equals("y")){
      hbaseToSqlServer(ApplicationContext.getInstance().getSqlServerProd(Constants.SQL_SERVER_REPORTING_DB), hbaseRDD, sqlContext,"Prod",whichTable);
      hbaseToSqlServer(ApplicationContext.getInstance().getSqlServerPreprod(Constants.SQL_SERVER_REPORTING_DB), hbaseRDD, sqlContext,"PProd",whichTable);

    }

    // ------------------------------------------------------------------------------
    // Give jobStreaming access writing to HBase tables
    // ------------------------------------------------------------------------------
    try {
    hbase.put(context.getProperty(Constants.PROPERTIES_HBASE_KAFKA_PARAMS_CONTACTS_TABLE),"6","H","h_access","true");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  
  private static void hbaseToSqlServer(SqlServerConnector sqlServer, JavaRDD<Result> hbaseRDD, SQLContext sqlContext, String env,String whichTable) {
    ApplicationContext context = ApplicationContext.getInstance();
    Properties sqlServerOptions = new Properties();

    sqlServerOptions.put("driver", sqlServer.getDriverClassName());
    sqlServerOptions.put("url", sqlServer.getConnectionUrl());
    sqlServerOptions.put("user", sqlServer.getUser());
    sqlServerOptions.put("password", sqlServer.getUserPwd());   

    // initializing spark user defined functions
    MapTargetingResultToRowFunction targetingFunction = new MapTargetingResultToRowFunction();
    MapFeedBackResultToRowFunction interactionFunction = new MapFeedBackResultToRowFunction();
    MapReactionResultToRowFunction reactionFunction = new MapReactionResultToRowFunction();

    // ------------------------------------------------------------------------------
    // Processing Targeting Records
    // ------------------------------------------------------------------------------
    
    // creating RDD of SQLServer rows
    JavaRDD<Row> sqlTargetingRows = hbaseRDD.map(targetingFunction);
    // converting hive rows RDD to data frame
    DataFrame targetingDataFrame = sqlContext.createDataFrame(sqlTargetingRows, targetingFunction.TARGETING_SCHEMA_SQL);
   
    // ------------------------------------------------------------------------------
    // Processing Interaction Records
    // ------------------------------------------------------------------------------

    // creating RDD of SQLServer rows
    JavaRDD<Row> sqlInteractionRows = hbaseRDD.flatMap(interactionFunction);
    // converting hive rows RDD to data frame
    DataFrame interactionDataFrame = sqlContext.createDataFrame(sqlInteractionRows, interactionFunction.FEED_BACK_SCHEMA_SQL);

    // ------------------------------------------------------------------------------
    // Processing Reaction Records
    // ------------------------------------------------------------------------------

    // creating RDD of SQLServer rows
    JavaRDD<Row> sqlReactionRows = hbaseRDD.flatMap(reactionFunction);
    // converting hive rows RDD to data frame
    DataFrame reactionDataFrame = sqlContext.createDataFrame(sqlReactionRows, reactionFunction.REACTION_SCHEMA_SQL);

    if(whichTable.equals("all")||whichTable.equals("")){
    // acquittal and writing to SQLServer
    context.acquitHbaseToSql(Constants.ACQUITTAL_TARGETING_TABLE_SHORT_NAME, Constants.ACQUITTAL_START, new Timestamp(new Date().getTime()), env);
    targetingDataFrame.write().mode(SaveMode.Append).jdbc(sqlServer.getConnectionUrl(), context.getProperty(Constants.PROPERTIES_SQL_SERVER_TARGETING_TABLE), sqlServerOptions);
    context.acquitHbaseToSql(Constants.ACQUITTAL_TARGETING_TABLE_SHORT_NAME, Constants.ACQUITTAL_END, new Timestamp(new Date().getTime()), env);

    // acquittal and writing to SQLServer
    context.acquitHbaseToSql(Constants.ACQUITTAL_FEED_BACK_TABLE_SHORT_NAME, Constants.ACQUITTAL_START, new Timestamp(new Date().getTime()), env);
    interactionDataFrame.write().mode(SaveMode.Append).jdbc(sqlServer.getConnectionUrl(), context.getProperty(Constants.PROPERTIES_SQL_SERVER_FEED_BACK_TABLE), sqlServerOptions);
    context.acquitHbaseToSql(Constants.ACQUITTAL_FEED_BACK_TABLE_SHORT_NAME, Constants.ACQUITTAL_END, new Timestamp(new Date().getTime()), env);
    
    // acquittal and writing to SQLServer
    context.acquitHbaseToSql(Constants.ACQUITTAL_REACTION_TABLE_SHORT_NAME, Constants.ACQUITTAL_START, new Timestamp(new Date().getTime()), env);
    reactionDataFrame.write().mode(SaveMode.Append).jdbc(sqlServer.getConnectionUrl(), context.getProperty(Constants.PROPERTIES_SQL_SERVER_REACTION_TABLE), sqlServerOptions);
    context.acquitHbaseToSql(Constants.ACQUITTAL_REACTION_TABLE_SHORT_NAME, Constants.ACQUITTAL_END, new Timestamp(new Date().getTime()), env);
    
    }
    else if(whichTable.equals("cib")){
      context.acquitHbaseToSql(Constants.ACQUITTAL_TARGETING_TABLE_SHORT_NAME, Constants.ACQUITTAL_START, new Timestamp(new Date().getTime()), env);
      targetingDataFrame.write().mode(SaveMode.Append).jdbc(sqlServer.getConnectionUrl(), context.getProperty(Constants.PROPERTIES_SQL_SERVER_TARGETING_TABLE), sqlServerOptions);
      context.acquitHbaseToSql(Constants.ACQUITTAL_TARGETING_TABLE_SHORT_NAME, Constants.ACQUITTAL_END, new Timestamp(new Date().getTime()), env);
    }
    else if(whichTable.equals("int")){ 
      context.acquitHbaseToSql(Constants.ACQUITTAL_FEED_BACK_TABLE_SHORT_NAME, Constants.ACQUITTAL_START, new Timestamp(new Date().getTime()), env);
      interactionDataFrame.write().mode(SaveMode.Append).jdbc(sqlServer.getConnectionUrl(), context.getProperty(Constants.PROPERTIES_SQL_SERVER_FEED_BACK_TABLE), sqlServerOptions);
      context.acquitHbaseToSql(Constants.ACQUITTAL_FEED_BACK_TABLE_SHORT_NAME, Constants.ACQUITTAL_END, new Timestamp(new Date().getTime()), env);
    }
    else if(whichTable.equals("rea")){
      context.acquitHbaseToSql(Constants.ACQUITTAL_REACTION_TABLE_SHORT_NAME, Constants.ACQUITTAL_START, new Timestamp(new Date().getTime()), env);
      reactionDataFrame.write().mode(SaveMode.Append).jdbc(sqlServer.getConnectionUrl(), context.getProperty(Constants.PROPERTIES_SQL_SERVER_REACTION_TABLE), sqlServerOptions);
      context.acquitHbaseToSql(Constants.ACQUITTAL_REACTION_TABLE_SHORT_NAME, Constants.ACQUITTAL_END, new Timestamp(new Date().getTime()), env);
    }
    }
  
}
