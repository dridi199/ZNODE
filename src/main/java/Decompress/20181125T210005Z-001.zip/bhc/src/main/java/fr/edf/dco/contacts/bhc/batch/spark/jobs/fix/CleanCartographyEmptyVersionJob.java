package fr.edf.dco.contacts.bhc.batch.spark.jobs.fix;

import java.util.Iterator;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;

import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;
import scala.Tuple2;

public class CleanCartographyEmptyVersionJob {

  public static void main(String[] args) {
    // args
    final String table = args[0];

    // getting environment context
    ApplicationContext app = ApplicationContext.getInstance();
    HbaseConnector hbase = app.getHbase();

    // configuring HBASE
    Configuration hbaseConfiguration = hbase.getConfiguration();
    hbaseConfiguration.set(TableInputFormat.SCAN_MAXVERSIONS, "100");
    hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, table);

    // spark application settings
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HBASE_HIVE);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);

    // creating RDD from HBASE tables
    JavaPairRDD<ImmutableBytesWritable, Result> hbaseRDD = sparkContext.newAPIHadoopRDD(hbaseConfiguration, TableInputFormat.class, ImmutableBytesWritable.class, Result.class);

    // deleting empty versions
    hbaseRDD.foreachPartition(new VoidFunction<Iterator<Tuple2<ImmutableBytesWritable, Result>>>() {

      private static final long serialVersionUID = -9172223650101169251L;

      @Override
      public void call(Iterator<Tuple2<ImmutableBytesWritable, Result>> rows) throws Exception {
        ApplicationContext context = ApplicationContext.getInstance();
        HbaseConnector hbase = context.getHbase();
        hbase.setTable(table);

        while (rows.hasNext()) {
          Result row = rows.next()._2();

          List<Cell> templates = row.getColumnCells(Utils.getBytes("S"), Utils.getBytes("c_template"));
          List<Cell> channels = row.getColumnCells(Utils.getBytes("S"), Utils.getBytes("c_canal"));
          List<Cell> coordinates = row.getColumnCells(Utils.getBytes("S"), Utils.getBytes("c_coordonnees"));
          List<Cell> strategies = row.getColumnCells(Utils.getBytes("S"), Utils.getBytes("c_strategie"));

          Delete delete = new Delete(row.getRow());
          // deleting empty templates
          for (Cell templateCell : templates) {
            String t = Bytes.toString(CellUtil.cloneValue(templateCell));
            if (!Utils.isNotEmptyOrSpace(t)) {
              delete.addColumn(Utils.getBytes("S"), Utils.getBytes("c_template"), templateCell.getTimestamp());
            }
          }

          // deleting empty channels
          for (Cell canalCell : channels) {
            if (!Utils.isNotEmptyOrSpace(Bytes.toString(CellUtil.cloneValue(canalCell)))) {
              delete.addColumn(Utils.getBytes("S"), Utils.getBytes("c_canal"), canalCell.getTimestamp());
            }
          }

          // deleting empty coordinates
          for (Cell coordinateCell : coordinates) {
            if (!Utils.isNotEmptyOrSpace(Bytes.toString(CellUtil.cloneValue(coordinateCell)))) {
              delete.addColumn(Utils.getBytes("S"), Utils.getBytes("c_coordonnees"), coordinateCell.getTimestamp());
            }
          }

          // deleting empty strategies
          for (Cell strategyCell : strategies) {
            if (!Utils.isNotEmptyOrSpace(Bytes.toString(CellUtil.cloneValue(strategyCell)))) {
              delete.addColumn(Utils.getBytes("S"), Utils.getBytes("c_strategie"), strategyCell.getTimestamp());
            }
          }

          if (!delete.isEmpty()) {
            hbase.delete(delete);
          }
        }
      }
    });

    // deletesRDD.foreachPartition(new VoidFunction<Iterator<Delete>>() {
    //
    // private static final long serialVersionUID = -2242133943222001948L;
    //
    // @SuppressWarnings("unchecked")
    // @Override
    // public void call(Iterator<Delete> t) throws Exception {
    // ApplicationContext context = ApplicationContext.getInstance();
    // HbaseConnector hbase = context.getHbase();
    // hbase.setTable(table);
    // System.out.println("DELETES SIZE IS : " +
    // IteratorUtils.toList(t).size());
    // hbase.multiDelete(IteratorUtils.toList(t));
    // }
    // });

    sparkContext.close();
  }
}
