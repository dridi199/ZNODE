package fr.edf.dco.contacts.bhc.entities.contact.feedback;

import java.io.IOException;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * Inca Emissaires Feed Back Record
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class IncaEmissairesMMFeedBackRecord extends FeedBackRecord {

  // -------------------------------------------------------------------
  // CONSTRUCTORS
  // -------------------------------------------------------------------

  public IncaEmissairesMMFeedBackRecord(String file) {
    super(file, "\\|", Constants.CONTACT_STREAM_INCA_EMISSAIRES_MM, 11, null, false);
    trialId = 11;
  }

  // -------------------------------------------------------------------
  // IMPLEMENTATION
  // -------------------------------------------------------------------

  @Override
  protected void process(String[] fields) throws CustomException {
    line.communicationID = fields[0].trim();

    if (!line.communicationID.startsWith("MM")) {
      throw new CustomException("Invalid Inca Emissaires Row Key : " + line.communicationID);
    }

    sendStatus = Utils.transcode(fields[1].trim());
    sendDate = Utils.getLongTimestamp(fields[2].trim(), "MM/dd/yyyy HH:mm:ss");
    sendResult = Utils.transcode(fields[3].trim());
    sendResultDetail = Utils.transcode(fields[4].trim());
    resultDate = Utils.getLongTimestamp(fields[5].trim(), "MM/dd/yyyy HH:mm:ss");
    reaction = Utils.transcode(fields[6].trim());
    reactionDate = Utils.getLongTimestamp(fields[7].trim(), "MM/dd/yyyy HH:mm:ss");
    optout = Utils.transcode(fields[8].trim());
    optoutDetail = fields[9].trim();
    optoutDate = Utils.getLongTimestamp(fields[10].trim(), "MM/dd/yyyy HH:mm:ss");
  }

  @Override
  public void storeToHbase() throws IOException {
    if (Utils.isNotEmptyOrSpace(line.communicationID)) {
      String initial = "t_" + trialId + "_";

      line.put = Utils.getContactPut(line.communicationID);

      if (!Utils.isInit()) {
        line.template = Utils.getExistingValue(line.communicationID, "S", "c_template");
        line.contactInformation = Utils.getExistingValue(line.communicationID, "S", "c_coordonnees");

        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "canal"), sendDate, Utils.getBytes(Constants.CONTACT_CANAL_COURRIER));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "coordonnee"), sendDate, Utils.getBytes(line.contactInformation));
      }

      line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), sendDate, Utils.getBytes(line.raw));
      line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), sendDate, Utils.getBytes(fileName));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), sendDate, Utils.getBytes(Constants.CONTACT_MARKET_MM));

      if (sendDate != 0) {
        if (sendStatus.equals("ENVOYE")) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_tentative"), sendDate, Utils.getBytes(Integer.toString(trialId)));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "template"), sendDate, Utils.getBytes(line.template));

          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "statut_envoi"), sendDate, Utils.getBytes(sendStatus));

          if (sendResult.equals("NPAI")) {
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), sendDate, Utils.getBytes(sendResult));

            if (resultDate != 0) {
              line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "resultat_envoi"), resultDate, Utils.getBytes(sendResult));
              line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "resultat_envoi_detail"), resultDate, Utils.getBytes(sendResultDetail));
            }
          } else {
            line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), sendDate, Utils.getBytes(sendStatus));

            if (resultDate != 0) {
              line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "resultat_envoi_detail"), resultDate, Utils.getBytes(sendResultDetail));
            }
          }
        } else {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), resultDate, Utils.getBytes(sendStatus));
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_type_nenv"), resultDate, Utils.getBytes(sendResultDetail));
        }
      }

      if (reactionDate != 0) {
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), reactionDate, Utils.getBytes(reaction));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "reaction"), reactionDate, Utils.getBytes(reaction));
      }

      if (optoutDate != 0) {
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "optout"), optoutDate, Utils.getBytes(optout));
        line.put.addColumn(Utils.getBytes("S"), Utils.getBytes(initial + "optout_detail"), optoutDate, Utils.getBytes(optoutDetail));
      }
    }
  }

  // -------------------------------------------------------------------
  // DATA MEMBERS
  // -------------------------------------------------------------------

  private String sendStatus;
  private long sendDate;
  private String sendResult;
  private String sendResultDetail;
  private long resultDate;
  private String reaction;
  private long reactionDate;
  private String optout;
  private String optoutDetail;
  private long optoutDate;
}
