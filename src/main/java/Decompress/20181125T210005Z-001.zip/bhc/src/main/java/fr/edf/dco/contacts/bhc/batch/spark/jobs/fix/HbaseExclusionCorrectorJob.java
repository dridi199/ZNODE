package fr.edf.dco.contacts.bhc.batch.spark.jobs.fix;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.IteratorUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.VoidFunction;

import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;
import scala.Tuple2;

public class HbaseExclusionCorrectorJob {

  public static void main(String[] args) {

    // getting environment context
    ApplicationContext app = ApplicationContext.getInstance();
    HbaseConnector hbase = app.getHbase();

    // configuring HBASE
    Configuration hbaseConfiguration = hbase.getConfiguration();
    hbaseConfiguration.set(TableInputFormat.SCAN_MAXVERSIONS, "100");
    hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, app.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));

    // spark application settings
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HBASE_HIVE);
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);

    // creating RDD from HBASE tables
    JavaPairRDD<ImmutableBytesWritable, Result> hbaseRDD = sparkContext.newAPIHadoopRDD(hbaseConfiguration, TableInputFormat.class, ImmutableBytesWritable.class, Result.class);

    // insert missing values
    JavaRDD<Put> putsRDD = hbaseRDD.mapPartitions(new FlatMapFunction<Iterator<Tuple2<ImmutableBytesWritable, Result>>, Put>() {

      private static final long serialVersionUID = -9172223650101169251L;

      @Override
      public Iterable<Put> call(Iterator<Tuple2<ImmutableBytesWritable, Result>> rows) throws Exception {
        List<Put> puts = new ArrayList<Put>();

        Result row = null;
        String noenv = null;
        String status = null;
        Put p = null;

        while (rows.hasNext()) {
          row = rows.next()._2();

          if (Bytes.toString(row.getRow()).startsWith("ARMM") && Bytes.toString(row.getRow()).contains("FEA")) {
            noenv = Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes("c_type_nenv"))));
            status = Utils.getEmptyIfNull(Bytes.toString(row.getValue(Utils.getBytes("S"), Utils.getBytes("a_statut"))));

            if ((Utils.isNotEmptyOrSpace(noenv)) && (!status.equals("NON_ENVOYE"))) {
              p = new Put(row.getRow());
              p.addColumn(Utils.getBytes("S"), Utils.getBytes("c_type_nenv"), Utils.getBytes(""));
              puts.add(p);
            }

          }
        }

        return puts;
      }
    });

    putsRDD.foreachPartition(new VoidFunction<Iterator<Put>>() {

      private static final long serialVersionUID = -2242133943222001948L;

      @SuppressWarnings("unchecked")
      @Override
      public void call(Iterator<Put> t) throws Exception {
        ApplicationContext context = ApplicationContext.getInstance();
        HbaseConnector hbase = context.getHbase();
        hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
        hbase.multiPut(IteratorUtils.toList(t));
      }
    });

    sparkContext.close();
  }
}
