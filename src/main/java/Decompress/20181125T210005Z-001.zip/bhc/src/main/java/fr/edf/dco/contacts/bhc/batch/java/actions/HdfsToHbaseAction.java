package fr.edf.dco.contacts.bhc.batch.java.actions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import fr.edf.com.dacc.HDFSLogger;
import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.common.connector.base.ConnectorException;
import fr.edf.dco.common.connector.hadoop.HdfsConnector;
import fr.edf.dco.common.connector.hadoop.HdfsConnector.HadoopFile;
import fr.edf.dco.common.factory.AbstractFactory;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.base.Utils;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;

/**
 * Collecting Hdfs files and writing to hbase
 * 
 * @author fahd-externe.essid@edf.fr eu36
 */
public class HdfsToHbaseAction {

  public static void main(String[] args) {
    ApplicationContext context = ApplicationContext.getInstance();
//    System.out.println(context.getProperty("env"));
    HdfsConnector hdfs = context.getHdfs();
    HDFSLogger logger = context.getLogger(HdfsToHbaseAction.class, Constants.CONTACT_PROCESS_HDFS_TO_HBASE);
    String[] dirs = context.getProperty(Constants.PROPERTIES_HDFS_WORK_DIR).split(";", -1);

    List<HadoopFile> files = new ArrayList<HadoopFile>();
    AbstractFactory factory = new ContactFactory();

    hdfs.setFileExtensionsPatterns(context.getProperty(Constants.PROPERTIES_APPLICATION_CONTACTS_EXTENSIONS).split(";", -1));

    for (String workDir : dirs) {
      try {
        files = hdfs.getFiles(workDir);
      } catch (IOException | ConnectorException e) {
        logger.error(Constants.ERROR_HDFS, "unable to read HDFS folder : " + workDir + " " + e.getMessage());
      }

      for (HadoopFile file : files) {
        // Stupid AWL Message Sent line breaks removal process
        if (file.getName().contains(Constants.CONTACT_FILE_AWL_MESSAGES_SENT)) {
          try {
            hdfs.removeLineBreaks(file.getPath().toString(), 17);
          } catch (IOException e) {
            logger.error(Constants.ERROR_HDFS, "could not process AWL MessageSent file : " + file.getName() + " " + e.getMessage());
          }
        }
        
        if (file.getName().contains(Constants.CONTACT_FILE_AWL_MESSAGES_RECEIVED)) {
          try {
            hdfs.removeLineBreaks(file.getPath().toString(), 9);
          } catch (IOException e) {
            logger.error(Constants.ERROR_HDFS, "could not process AWL MessageSent file : " + file.getName() + " " + e.getMessage());
          }
        }

        AbstractContactRecord record = null;
        String line = null;

        try {
          record = (AbstractContactRecord) factory.createRecord(file.getName());
        } catch (CustomException e) {
          e.printStackTrace();
          logger.warn(Constants.WARNING_DATA, "unknow contact file : " + file.getName());
        }

        // processing xml files
        if (record!=null && file.getName().contains("xml")) {
          try {
            file.setXmlDocument();
            NodeList nodeList = file.getNodesList(record.getXmlNodesTag());

            for (int i = 0; i < nodeList.getLength(); i++) {
              Node node = nodeList.item(i);

              if (record != null) {
                try {
                  record.parse(Utils.xmlElementToString((Element) node));
                  record.storeToHbase();
                } catch (IOException e) {
//                  e.printStackTrace();
                  logger.error(Constants.ERROR_HBASE, "could not write to hbase : " + e.getMessage());
                } catch (CustomException e) {
//                  e.printStackTrace();
                  logger.warn(Constants.WARNING_DATA, "Contact line could not be parsed : " + line);
                }
              }

            }
          } catch (IOException | SAXException | ParserConfigurationException e) {
            e.printStackTrace();
          }
        } else {
          try {
            while (null != (line = file.readLine())) {
              if (record != null) {
                try {
                  record.parse(line);
                  record.storeToHbase();
                } catch (IOException e) {
//                  e.printStackTrace();
                  logger.error(Constants.ERROR_HBASE, "could not write to hbase : " + e.getMessage());
                } catch (CustomException e) {
                  e.printStackTrace();
                  logger.warn(Constants.WARNING_DATA, "Contact line could not be parsed : " + line);
                }
              }
            }
          } catch (IOException e) {
//            e.printStackTrace();
            logger.error(Constants.ERROR_HDFS, "could not read hdfs file : " + file.getName() + " " + e.getMessage());
          }
        }
      }
    }

    context.flushContacts(false);
    context.closeContext();
  }
}
