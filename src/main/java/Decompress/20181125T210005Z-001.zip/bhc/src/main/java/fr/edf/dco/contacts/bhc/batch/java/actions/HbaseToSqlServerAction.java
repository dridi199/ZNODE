package fr.edf.dco.contacts.bhc.batch.java.actions;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.util.Bytes;

import fr.edf.com.dacc.HDFSLogger;
import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.common.connector.jdbc.SqlServerConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

/**
 * Batch mode process for BHC contacts streams integration Designed to work
 * within an Oozie workflow
 * 
 * @author fahd-externe.essid@edf.fr
 */
public class HbaseToSqlServerAction {

  /**
   * Program args : Process Phase
   */
  public static void main(String[] args) {
    ApplicationContext context = ApplicationContext.getInstance();
    HDFSLogger logger = context.getLogger(HbaseToSqlServerAction.class, Constants.CONTACT_PROCESS_HBASE_TO_SQL_SERVER);
    HbaseConnector hbase = context.getHbase();
    ResultScanner scanner = null;

    try {
      hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
      scanner = hbase.scan(true);
    } catch (IOException e) {
      e.printStackTrace();
      logger.error(Constants.ERROR_HBASE, "unable to scan hbase table : " + Constants.PROPERTIES_HBASE_CONTACTS_TABLE + " " + e.getMessage());
    }

    String table = args.length > 0 ? args[0] : "";

    if (table.contains("CIB")) {
      loadTargetingTable(scanner, context.getProperty(Constants.PROPERTIES_SQL_SERVER_TARGETING_TABLE), context, logger);
    } else if (table.contains("INT")) {
      loadFeedBackTable(scanner, context.getProperty(Constants.PROPERTIES_SQL_SERVER_FEED_BACK_TABLE), context, logger);
    } else if (table.contains("REA")) {
      loadReactionTable(scanner, context.getProperty(Constants.PROPERTIES_SQL_SERVER_REACTION_TABLE), context, logger);
    } else {
      logger.warn(Constants.WARNING_DATA, "Unknown sql table argmument : " + table);
    }

    context.closeContext();
  }

  /**
   * Export Targeting
   * 
   * @param scanner
   */
  public static void loadTargetingTable(ResultScanner scanner, String table, ApplicationContext context, HDFSLogger logger) {

    SqlServerConnector sqlserver = context.getSqlServerPreprod(Constants.SQL_SERVER_REPORTING_DB);

    try {
      Statement s = sqlserver.getConnection().createStatement();

      int i = 0;
      for (Result result : scanner) {
        String id = Utils.getEmptyIfNull(Bytes.toString(result.getRow()));
        String codeRegroupement = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_code_regroupement"))));
        String traitement = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_code_traitement"))));
        String canal = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_canal"))));
        String statut = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("a_statut"))));

        List<Cell> cells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_statut"));
        long ts = 0;
        for (Cell cell : cells) {
          if (cell.getTimestamp() > ts) {
            ts = cell.getTimestamp();
          }
        }

        Timestamp dateStatut = new Timestamp(ts);

        String typeNonEnv = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_type_nenv"))));
        String tent = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("a_tentative"))));
        String tentative = Utils.getEmptyIfNull(Utils.isNotEmptyOrSpace(tent) ? id + "_" + tent : "");
        String bp = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_bp"))));

        if (bp != null && bp.length() > 10) {
          bp = bp.substring(0, 9);
        }

        String local = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_local"))));
        String accordCo = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_accord_co"))));
        String region = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_region"))));
        Timestamp dateCiblage = Utils.getSqlTimestamp(Utils.getLongTimestamp(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_date"))), "dd/MM/yyyy HH:mm:ss"));

        String sql = "INSERT INTO " + table + "(ID_TECH, CODE_REGROUPEMENT, CODE_TRAITEMENT, LIB_CANAL_CIB, LIB_STATUT, DATE_STATUT, TYPE_NENV, ID_TENTATIVE, ID_CLIENT_BP, ID_CLIENT_LOCAL, ID_CLIENT_ACCORD_CO, CODE_REGION, DATE_CIBLAGE) " + "VALUES('" + id + "', '" + codeRegroupement + "', '" + traitement + "', '" + canal + "', '" + statut + "', '" + dateStatut + "', '" + typeNonEnv + "', '" + tentative + "', '" + bp + "', '" + local + "', '" + accordCo + "', '" + region + "','" + dateCiblage
            + "')";

        s.addBatch(sql);
        if (i++ % new Integer(context.getProperty(Constants.PROPERTIES_SQL_SERVER_BATCH_SIZE)).intValue() == 0) {
          s.executeBatch();
        }
      }

      s.executeBatch();
    } catch (SQLException e) {
      e.printStackTrace();
      logger.error(Constants.ERROR_SQLSERVER, "SQL Server error occured : " + e.getMessage());
    }
  }

  /**
   * Export Reaction
   * 
   * @param scanner
   */
  @SuppressWarnings("unused")
  public static void loadReactionTable(ResultScanner scanner, String table, ApplicationContext context, HDFSLogger logger) {
    System.out.println("writing to table : " + table);
    
    SqlServerConnector sqlserver = context.getSqlServerPreprod(Constants.SQL_SERVER_REPORTING_DB);
    System.out.println("Connection : " + sqlserver.getConnectionUrl());
    try {
//      int i = 0;
      int max = 0;

      for (Result result : scanner) {
        String id = Bytes.toString(result.getRow());
        List<Cell> trials = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_tentative"));
        
        if (trials.size() > 0) {
          for (Cell trialCell : trials) {
            String trialId = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(trialCell)));
            String device = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_device"))));
            String os = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_device_ois"))));
            String osVersion = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_device_ois_version"))));
            String browser = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_device_browser"))));
            String browserVersion = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_device_browser_version"))));

            String reaction = "";
            Timestamp reactionDate = new Timestamp(0);
            String url = "";

            List<Cell> openCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_reaction"));
            if (openCells.size() > 0) {
              for (Cell openCell : openCells) {
                reaction = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(openCell)));

                if (reaction.equals("OUVERT")) {
                  reactionDate = Utils.getSqlTimestamp(openCell.getTimestamp());

                  String query = ("INSERT INTO " + table + " (ID_TENTATIVE, LIB_TYPE_REACTION, DATE_REACTION, LIB_URL, LIB_DEVICE, LIB_OS, VERSION_OS, LIB_BROWSER, VERSION_BROWSER, DATE_INSERTION) " + "VALUES('" + id + "_" + trialId + "', '" + reaction + "', '" + reactionDate + "', '" + url + "', '" + device + "', '" + os + "', '" + osVersion + "', '" + browser + "', '" + browserVersion + "', '" + new Timestamp(new Date().getTime())+ "')");
                  
                  if(max < url.length()) {
                    max = url.length();
                    System.out.println(max + "   : " + url );
                  }

                  //System.out.println(query);
                  //sqlserver.executeUpdate(query);
                }
              }
            }

            List<Cell> clickCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_reaction_clic_url"));

            if (clickCells.size() > 0) {
              for (Cell clickCell : clickCells) {
                reaction = "CLIC";
                reactionDate = Utils.getSqlTimestamp(clickCell.getTimestamp());
                url = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(clickCell)));

                if(max < url.length()) {
                  max= url.length();
                  System.out.println(max + "   : " + url );
                }

                String query = ("INSERT INTO " + table + " (ID_TENTATIVE, LIB_TYPE_REACTION, DATE_REACTION, LIB_URL, LIB_DEVICE, LIB_OS, VERSION_OS, LIB_BROWSER, VERSION_BROWSER, DATE_INSERTION) " + "VALUES('" + id + "_" + trialId + "', '" + reaction + "', '" + reactionDate + "', '" + url + "', '" + device + "', '" + os + "', '" + osVersion + "', '" + browser + "', '" + browserVersion + "', '" + new Timestamp(new Date().getTime())+ "')");
                //System.out.println(query);
                //sqlserver.executeUpdate(query);
              }
            }

            url = "";
            List<Cell> optoutCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_optout"));
            if (optoutCells.size() > 0) {
              for (Cell optoutCell : optoutCells) {
                reaction = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(optoutCell)));
                reactionDate = Utils.getSqlTimestamp(optoutCell.getTimestamp());

                if(max < url.length()) {
                  max= url.length();
                  System.out.println(max + "   : " + url );                }
                String query = ("INSERT INTO " + table + " (ID_TENTATIVE, LIB_TYPE_REACTION, DATE_REACTION, LIB_URL, LIB_DEVICE, LIB_OS, VERSION_OS, LIB_BROWSER, VERSION_BROWSER, DATE_INSERTION) " + "VALUES('" + id + "_" + trialId + "', '" + reaction + "', '" + reactionDate + "', '" + url + "', '" + device + "', '" + os + "', '" + osVersion + "', '" + browser + "', '" + browserVersion + "', '" + new Timestamp(new Date().getTime())+ "')");
                //System.out.println(query);
                //sqlserver.executeUpdate(query);        
              }
            }

            List<Cell> mirrorCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_mirror"));
            if (mirrorCells.size() > 0) {
              for (Cell mirrorCell : mirrorCells) {
                reaction = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(mirrorCell)));
                reactionDate = Utils.getSqlTimestamp(mirrorCell.getTimestamp());

                if(max < url.length()) {
                  max= url.length();
                  System.out.println(max + "   : " + url );
                }
                String query = ("INSERT INTO " + table + " (ID_TENTATIVE, LIB_TYPE_REACTION, DATE_REACTION, LIB_URL, LIB_DEVICE, LIB_OS, VERSION_OS, LIB_BROWSER, VERSION_BROWSER, DATE_INSERTION) " + "VALUES('" + id + "_" + trialId + "', '" + reaction + "', '" + reactionDate + "', '" + url + "', '" + device + "', '" + os + "', '" + osVersion + "', '" + browser + "', '" + browserVersion + "', '" + new Timestamp(new Date().getTime())+ "')");
                //System.out.println(query);
                //sqlserver.executeUpdate(query);
              }
            }
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
      logger.error(Constants.ERROR_SQLSERVER, "SQL Server error occured : " + e.getMessage());
    }
  }

  /**
   * Export FeedBack
   * 
   * @param scanner
   */
  public static void loadFeedBackTable(ResultScanner scanner, String table, ApplicationContext context, HDFSLogger logger) {

    SqlServerConnector sqlserver = context.getSqlServerPreprod(Constants.SQL_SERVER_REPORTING_DB);

    try {
      Statement s = sqlserver.getConnection().createStatement();
      int i = 0;
      for (Result result : scanner) {
        String id = Utils.getEmptyIfNull(Bytes.toString(result.getRow()));

        List<Cell> trials = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_tentative"));

        if (trials.size() > 0) {
          for (Cell trialCell : trials) {
            String trialId = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(trialCell)));
            String chanel = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_canal"))));
            String template = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_template"))));
            String sendResultDetails = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_resultat_envoi_detail"))));
            String coordonnees = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_coordonnee"))));

            String sendStatus = "";
            Timestamp interactionDate = new Timestamp(0);
            List<Cell> sendStatusCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_statut_envoi"));
            if (sendStatusCells.size() > 0) {
              Cell sendStatusCell = sendStatusCells.get(0);

              sendStatus = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(sendStatusCell)));
              interactionDate = Utils.getSqlTimestamp(sendStatusCell.getTimestamp());
            }

            String sendResult = "";
            Timestamp resultDate = new Timestamp(0);

            List<Cell> sendResultCells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("t_" + trialId + "_resultat_envoi"));
            if (sendResultCells.size() > 0) {
              Cell sendResultCell = sendResultCells.get(0);

              sendResult = Utils.getEmptyIfNull(Bytes.toString(CellUtil.cloneValue(sendResultCell)));
              resultDate = Utils.getSqlTimestamp(sendResultCell.getTimestamp());
            }

            String sql = "INSERT INTO " + table + "(ID_TENTATIVE, ID_TECH, CODE_STATUT, DATE_INTERACTION, CODE_RES_ENV, CODE_RES_ENV_DETAIL, DATE_RES_ENV, LIB_CANAL_RET, CD_MESSAGE, COORDONNEE) " + "VALUES ('" + id + "_" + trialId + "', '" + id + "', '" + sendStatus + "', '" + interactionDate + "', '" + sendResult + "', '" + sendResultDetails + "', '" + resultDate + "', '" + chanel + "', '" + template + "', '" + coordonnees + "')";

            s.addBatch(sql);
          }
        }

        if (i++ % new Integer(context.getProperty(Constants.PROPERTIES_SQL_SERVER_BATCH_SIZE)).intValue() == 0) {
          s.executeBatch();
        }
      }

      s.executeBatch();
    } catch (SQLException e) {
      logger.error(Constants.ERROR_SQLSERVER, "SQL Server error occured : " + e.getMessage());
    }
  }

}
