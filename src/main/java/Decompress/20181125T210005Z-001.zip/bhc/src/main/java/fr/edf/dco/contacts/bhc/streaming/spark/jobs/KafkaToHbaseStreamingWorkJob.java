package fr.edf.dco.contacts.bhc.streaming.spark.jobs;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;

import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.common.connector.misc.KafkaConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;

/**
 * Spark Streaming application that handles contacts streaming from kafka and
 * contacts integration in HBase after specific transformations
 * 
 * @author ahmed-externe.dridi@edf.fr
 */
public class KafkaToHbaseStreamingWorkJob {

  public static void main(String[] args) {
    ApplicationContext context = ApplicationContext.getInstance();

    // Spark Streaming context configuration
    SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_STREAMING_KAFKA_HBASE);
    JavaStreamingContext streamingContext = new JavaStreamingContext(sparkConfiguration, Durations.seconds(120));

    String topic = context.getProperty(Constants.PROPERTIES_KAFKA_STREAM_TOPICS);
    HashSet<String> topicsSet = new HashSet<String>(Arrays.asList(topic.split(",")));
    KafkaConnector kafka = context.getKafka(topicsSet.iterator().next());

    // parametres de connection. Ne plus utiliser les serveurs Zookeeper
    Map<String, Object> kafkaParams = new HashMap<String, Object>();
    kafkaParams.put("bootstrap.servers", kafka.getBrokers()); // les brokers doivent etre passés en paramètre de la classe via le spark-submit
    kafkaParams.put("security.protocol", "SASL_SSL");
    kafkaParams.put("ssl.truststore.location", "./truststore"); // le fichier se trouve sur le frontal /etc/kafka/conf/truststore et doit etre passé dans les --files
    kafkaParams.put("ssl.truststore.password", "ryba123");
    kafkaParams.put("key.deserializer", org.apache.kafka.common.serialization.StringDeserializer.class);
    kafkaParams.put("value.deserializer", org.apache.kafka.common.serialization.StringDeserializer.class);
    kafkaParams.put("enable.auto.commit", false);
    kafkaParams.put("auto.offset.reset", "earliest"); // attention, les valeurs sont latest/earliest au lieu de largest/smallest
    kafkaParams.put("group.id", UUID.randomUUID().toString());

    // JavaPairInputDStream<String, String> messages = KafkaUtils.createDirectStream(streamingContext, String.class, String.class, StringDecoder.class, StringDecoder.class, kafkaParams, topicsSet);

    
    // creation de la stream
    JavaInputDStream<ConsumerRecord<String, String>> messages = KafkaUtils.createDirectStream(streamingContext, LocationStrategies.PreferConsistent(), ConsumerStrategies.<String, String> Subscribe(topicsSet, kafkaParams));

    messages.foreachRDD(new VoidFunction<JavaRDD<ConsumerRecord<String, String>>>() {

      private static final long serialVersionUID = -5607964196335019596L;

      @Override
      public void call(JavaRDD<ConsumerRecord<String, String>> rdd) throws Exception {
        rdd.foreachPartition(new VoidFunction<Iterator<ConsumerRecord<String, String>>>() {

          private static final long serialVersionUID = 3307816011518597911L;

          @Override
          public void call(Iterator<ConsumerRecord<String, String>> messages) throws Exception {
            ApplicationContext context = ApplicationContext.getInstance();
            ContactFactory factory = new ContactFactory();
            HbaseConnector hbase = context.getHbase();

            hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));

            AbstractContactRecord record = null;
            ConsumerRecord<String, String> message = null;

            while (messages.hasNext()) {
              message = messages.next();
//             System.out.println("message key ="+ message.key() +"message value = " +message.value());
              try {
                record = factory.createRecord(Constants.CONTACT_MESSAGE_EDIWAY_EDIFUZ);
                record.parse(message.value());
                record.storeToHbase();

              } catch (Exception e) {
                e.printStackTrace();
              }
            }
            context.flushContacts(true);

          }
        });
      }

    });

    // start streaming job
    streamingContext.start();
    streamingContext.awaitTermination();
  }
}
