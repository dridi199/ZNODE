package fr.edf.dco.contacts.bhc.batch.spark.functions;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.function.PairFunction;

import fr.edf.dco.contacts.bhc.base.Utils;
import scala.Tuple2;

public class MapTargetingResultToJsonFunction implements PairFunction<Tuple2<ImmutableBytesWritable, Result>, Object, Object> {

  // ------------------------------------------------------------------------------
  // IMPLEMENTATION
  // ------------------------------------------------------------------------------

  @Override
  public Tuple2<Object, Object> call(Tuple2<ImmutableBytesWritable, Result> row) throws Exception {
    Result result = row._2;
    Map<String, Object> json = new HashMap<String, Object>();
    String id = Utils.getEmptyIfNull(Bytes.toString(result.getRow()));

    json.put("ID_TECH", id);
    json.put("CODE_REGROUPEMENT", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_code_regroupement")))));
    json.put("CODE_TRAITEMENT", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_code_traitement")))));
    json.put("LIB_CANAL_CIB", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_canal")))));
    json.put("LIB_STATUT", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("a_statut")))));

    List<Cell> cells = result.getColumnCells(Utils.getBytes("S"), Utils.getBytes("a_statut"));
    long ts = 0;
    for (Cell cell : cells) {
      if (cell.getTimestamp() > ts) {
        ts = cell.getTimestamp();
      }
    }

    json.put("DATE_STATUT", new Timestamp(ts));
    json.put("TYPE_NENV", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_type_nenv")))));
    json.put("ID_TENTATIVE", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("a_tentative")))));
    json.put("ID_CLIENT_BP", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_bp")))));
    json.put("ID_CLIENT_LOCAL", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_local")))));
    json.put("ID_CLIENT_ACCORD_CO", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_accord_co")))));
    json.put("CODE_REGION", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_region")))));
    json.put("DATE_CIBLAGE", Utils.getSqlTimestamp(Utils.getLongTimestamp(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_date"))), "dd/MM/yyyy HH:mm:ss")));
    json.put("FLUX", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_flux")))));
    json.put("MARCHE", Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_marche_trace")))));

    json.put("DATE_INSERTION", new Timestamp(new Date().getTime()));
    return new Tuple2<Object, Object>(id, json);
  }

  private static final long serialVersionUID = 1715639021946760399L;
}
