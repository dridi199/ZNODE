package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.io.IOException;
import java.util.NavigableMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.mapreduce.TableOutputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.mapreduce.Job;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFunction;


import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;
import scala.Tuple2;

public class HbaseCopyTable {
  
  public static void main(String[] args) throws IOException{
  // getting environment context
  ApplicationContext context = ApplicationContext.getInstance();
  HbaseConnector hbase = context.getHbase();
  
  // configuring HBASE
  Configuration hbaseConfiguration = hbase.getConfiguration();
  hbaseConfiguration.set(TableInputFormat.SCAN_MAXVERSIONS, "30");
  hbaseConfiguration.setInt("hbase.rpc.timeout", 24000000);
  hbaseConfiguration.setInt("hbase.client.scanner.timeout.period", 24000000);

  // spark application settings
  SparkConf sparkConfiguration = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HBASE_SQL_SERVER);
  JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);

  // creating RDD from HBASE tables
  if (args[0].equals("full")) {
    hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
    hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));   
  } else {
    hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
    hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TEMP_TABLE));
  }

  
  // Due to instability in the newAPIHadoopRDD function we will parallelize data from a hbase Java API Scan
   JavaPairRDD<ImmutableBytesWritable, Result> hbaseRDD = sparkContext.newAPIHadoopRDD(hbaseConfiguration, TableInputFormat.class, ImmutableBytesWritable.class, Result.class);
  // Filter flux (INCA_INSERT_MKT)
  hbaseRDD=hbaseRDD.filter(new Function<Tuple2<ImmutableBytesWritable, Result>, Boolean>() {
    private static final long serialVersionUID = -8734939700009133492L;

    @Override
    public Boolean call(Tuple2<ImmutableBytesWritable, Result> t) throws Exception {
      String flux=Utils.getEmptyIfNull(Bytes.toString(t._2.getValue(Utils.getBytes("S"), Utils.getBytes("c_flux"))));
      String statut=Utils.getEmptyIfNull(Bytes.toString(t._2.getValue(Utils.getBytes("S"), Utils.getBytes("a_statut"))));
      return flux.equals("INCA_INSERT_MKT") && ((statut.equals("ENVOYE") || statut.equals("DEPRIORISE") || statut.equals("NON_ENVOYE")));
    }
  });
  
 JavaPairRDD<ImmutableBytesWritable,Put> hbaseputRDD = hbaseRDD.mapToPair(new PairFunction<Tuple2<ImmutableBytesWritable,Result>, ImmutableBytesWritable, Put>() {
  private static final long serialVersionUID = -161208050886731180L;

  @Override
  public Tuple2<ImmutableBytesWritable, Put> call(Tuple2<ImmutableBytesWritable, Result> t) throws Exception {
    Result r = t._2;
    Put put = new Put(r.getRow());
    NavigableMap<byte[], NavigableMap<byte[], byte[]>> resultMap = r.getNoVersionMap();
    for (byte[] familyName : resultMap.keySet()) {
        NavigableMap<byte[], byte[]> subResultMap = resultMap.get(familyName);
        for(byte[] columnName : subResultMap.keySet()) {
          @SuppressWarnings("deprecation")
          long date = r.raw()[0].getTimestamp();
          put.addColumn(Utils.getBytes(new String(familyName)), Utils.getBytes(new String(columnName)),date, r.getValue(Utils.getBytes(new String(familyName)), Utils.getBytes(new String(columnName))));
            
        }
    }
    return new Tuple2<ImmutableBytesWritable, Put>(t._1, put);
  }
});
 
  hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_ZETEMP_TABLE));
  hbase.setTable(context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_ZETEMP_TABLE));
  Job newAPIJobConfig = Job.getInstance(hbaseConfiguration);
  newAPIJobConfig.getConfiguration().set(TableOutputFormat.OUTPUT_TABLE, context.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_ZETEMP_TABLE));
  newAPIJobConfig.setOutputFormatClass(org.apache.hadoop.hbase.mapreduce.TableOutputFormat.class);
  hbaseputRDD.saveAsNewAPIHadoopDataset(newAPIJobConfig.getConfiguration());

  sparkContext.close();

}
}
