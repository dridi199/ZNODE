package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;

import fr.edf.dco.common.connector.hadoop.HbaseConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

public class HBaseFlatFileExporter{
  @SuppressWarnings("resource")
  public static void main(String[] args)  {
  ApplicationContext ctxt = ApplicationContext.getInstance();
  HbaseConnector hbase = ctxt.getHbase();
//spark application settings
  SparkConf sparkConfiguration = new SparkConf().setAppName("HbaseToFlatFileExporter");
  JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);
//  SQLContext sqlContext = new SQLContext(sparkContext);
  
  Configuration hbaseConfiguration = hbase.getConfiguration();
  hbaseConfiguration.set(TableInputFormat.SCAN_MAXVERSIONS, "30");
  hbaseConfiguration.set(TableInputFormat.SCAN_COLUMN_FAMILY, "S");
  hbaseConfiguration.setInt("hbase.rpc.timeout", 24000000);
  hbaseConfiguration.setInt("hbase.client.scanner.timeout.period", 24000000);
  hbaseConfiguration.set(TableInputFormat.INPUT_TABLE, ctxt.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE));
  hbase.setTable(ctxt.getProperty(Constants.PROPERTIES_HBASE_CONTACTS_TABLE)); 
  JavaRDD<Result> hbaseRDD = sparkContext.newAPIHadoopRDD(hbaseConfiguration, TableInputFormat.class, ImmutableBytesWritable.class, Result.class).values();
  hbaseRDD=hbaseRDD.filter(new Function<Result, Boolean>() {
    private static final long serialVersionUID = 754892399757323052L;

    @Override
    public Boolean call(Result result) throws Exception {
      String codeRegroupement = Utils.getEmptyIfNull(Bytes.toString(result.getValue(Utils.getBytes("S"), Utils.getBytes("c_code_regroupement"))));
      return codeRegroupement.equals(args[0]);
    }
  });
  
//  JavaRDD<Row> rowRDD = hbaseRDD.map(new Function<Result, Row>() {
//    private static final long serialVersionUID = 5624694702043318079L;
//
//    @Override
//    public Row call(Result v1) throws Exception {
//      return null;
//    }
//  });
//  MapToJsonFunction maptojson = new MapToJsonFunction();
//  rdd = hbaseRDD.mapToPair(maptojson);
  }
 
}