package fr.edf.dco.contacts.bhc.batch.java.actions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import fr.edf.com.dacc.HDFSLogger;
import fr.edf.dco.common.connector.base.ConnectorException;
import fr.edf.dco.common.connector.hadoop.HdfsConnector;
import fr.edf.dco.common.connector.hadoop.HdfsConnector.HadoopFile;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;

public class AwlMessagesSentFilesCorrectAction {

  public static void main(String[] args) {
    ApplicationContext context = ApplicationContext.getInstance();
    HdfsConnector hdfs = context.getHdfs();
    HDFSLogger logger = context.getLogger(HdfsToHbaseAction.class, Constants.CONTACT_PROCESS_HDFS_TO_HBASE);
    String[] dirs = context.getProperty(Constants.PROPERTIES_HDFS_WORK_DIR).split(";", -1);

    List<HadoopFile> files = new ArrayList<HadoopFile>();

    hdfs.setFileExtensionsPatterns(context.getProperty(Constants.PROPERTIES_APPLICATION_CONTACTS_EXTENSIONS).split(";", -1));

    for (String workDir : dirs) {
      try {
        files = hdfs.getFiles(workDir);
      } catch (IOException | ConnectorException e) {
        e.printStackTrace();
        logger.error(Constants.ERROR_HDFS, "unable to read HDFS folder : " + workDir + " " + e.getMessage());
      }

      for (HadoopFile file : files) {

        if (file.getName().contains(Constants.CONTACT_FILE_AWL_MESSAGES_SENT)) {
          try {
            hdfs.removeLineBreaks(file.getPath().toString(), 17);
            System.out.println("Processing file  : " + file.getName() );
          } catch (IOException e) {
            logger.error(Constants.ERROR_HDFS, "could not process AWL MessageSent file : " + file.getName() + " " + e.getMessage());
          }
        }
      }
    }

    context.closeContext();
  }
}
