package fr.edf.dco.contacts.bhc.entities.contact.feedback;

import java.io.IOException;

import fr.edf.dco.common.base.CustomException;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.Utils;

public class IncaMMAbandonedRecord extends FeedBackRecord {

  // -------------------------------------------------------------------
  // CONSTRUCTORS
  // -------------------------------------------------------------------

  public IncaMMAbandonedRecord(String file) {
    super(file, "\\|", Constants.CONTACT_STREAM_INCA_EMISSAIRES_MM, 6, "ID_TECH", false);

  }

  // -------------------------------------------------------------------
  // IMPLENTATION
  // -------------------------------------------------------------------

  @Override
  protected void process(String[] fields) throws CustomException {
    line.communicationID = fields[0].trim();
    line.processCode = fields[1].trim();
    line.groupCode = fields[2].trim();
    line.chanel = fields[3].trim();
    line.status = fields[4].trim();
    sendDate = Utils.getLongTimestamp(fields[5].trim(), "MM/dd/yyyy HH:mm:ss");
  }

  @Override
  public void storeToHbase() throws IOException {
    if (Utils.isNotEmptyOrSpace(line.communicationID)) {
      line.put = Utils.getContactPut(line.communicationID);
      
      line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("ligne_retour"), sendDate, Utils.getBytes(line.raw));
      line.put.addColumn(Utils.getBytes("B"), Utils.getBytes("source_retour"), sendDate, Utils.getBytes(fileName));
      
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_marche_trace"), sendDate, Utils.getBytes(Constants.CONTACT_MARKET_MM));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_canal"), Utils.getBytes(line.chanel));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_code_regroupement"), Utils.getBytes(line.groupCode));
      line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("c_code_traitement"), Utils.getBytes(line.processCode));

      if (sendDate > 0) {
        if (line.status.equals(Constants.CONTACT_STATUS_RAW_ABANDONED)) {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), sendDate, Utils.getBytes(Constants.CONTACT_STATUS_ABANDONED));
        } else {
          line.put.addColumn(Utils.getBytes("S"), Utils.getBytes("a_statut"), sendDate, Utils.getBytes(line.status));
        }
      }
    }
  }

  // -------------------------------------------------------------------
  // DATA MEMBERS
  // -------------------------------------------------------------------

  private long sendDate;
}
