package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;

import fr.edf.dco.common.connector.jdbc.SqlServerConnector;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;

public class HiveToHbaseRepriseJob {

  public static void main(String[] args) throws SQLException, IOException {
    SparkConf sparkConfiguration = new SparkConf().setAppName("HiveToHbaseReprise");
    JavaSparkContext sparkContext = new JavaSparkContext(sparkConfiguration);
    HiveContext hContext = new HiveContext(sparkContext);

    SQLContext sqlContext = new HiveContext(sparkContext);
    ApplicationContext context = ApplicationContext.getInstance();
    SqlServerConnector sqlServer = context.getSqlServerPreprod(Constants.SQL_SERVER_REPORTING_DB);
    Properties sqlServerOptions = new Properties();

    sqlServerOptions.put("driver", sqlServer.getDriverClassName());
    sqlServerOptions.put("url", sqlServer.getConnectionUrl());
    sqlServerOptions.put("user", sqlServer.getUser());
    sqlServerOptions.put("password", sqlServer.getUserPwd());
    // sqlContext.setConf(sqlServerOptions);

    DataFrame dataframe = sqlContext.read().jdbc(sqlServer.getConnectionUrl(), "REPRISE_HIVE_HBASE", sqlServerOptions);
    List<Row> rows = dataframe.select("TABLE_HIVE_CIBLE_ORC").distinct().collectAsList();
    Map<String, Row> mapTableHiveNames = new HashMap<String, Row>();
    for (Row row : rows)
      mapTableHiveNames.put(row.getString(0), row);// name table hive

    // exécution des ciblages
    if(mapTableHiveNames.containsKey("armatis_dpnr_init_orc"))
      process("armatis_dpnr_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'armatis_dpnr_init_orc'"),Constants.CONTACT_POINT_VIRGULE_SEPARATOR);
    if(mapTableHiveNames.containsKey("armatis_fea_init_orc"))
      process("armatis_fea_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'armatis_fea_init_orc'"),Constants.CONTACT_POINT_VIRGULE_SEPARATOR);
    if(mapTableHiveNames.containsKey("echea_apure_init_orc"))
      process("echea_apure_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'echea_apure_init_orc'"),Constants.CONTACT_POINT_VIRGULE_SEPARATOR);
    if(mapTableHiveNames.containsKey("editic_data_init_orc"))
      process("editic_data_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'editic_data_init_orc'"),Constants.CONTACT_PIPE_SEPARATOR);
    if(mapTableHiveNames.containsKey("etl_simm_init_orc"))
      process("etl_simm_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'etl_simm_init_orc'"),Constants.CONTACT_POINT_VIRGULE_SEPARATOR);
    if(mapTableHiveNames.containsKey("inca_cabestan_init_orc"))
      process("inca_cabestan_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'inca_cabestan_init_orc'"),Constants.CONTACT_PIPE_SEPARATOR);
    if(mapTableHiveNames.containsKey("inca_emissaires_init_orc"))
      process("inca_emissaires_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'inca_emissaires_init_orc'"),Constants.CONTACT_PIPE_SEPARATOR);
    
    // exécution des retours
    if(mapTableHiveNames.containsKey("armatis_dpnr_retours_init_orc"))
      process("armatis_dpnr_retours_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'armatis_dpnr_retours_init_orc'"),Constants.CONTACT_PIPE_SEPARATOR);
    if(mapTableHiveNames.containsKey("armatis_fea_retours_init_orc"))
      process("armatis_fea_retours_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'armatis_fea_retours_init_orc'"),Constants.CONTACT_PIPE_SEPARATOR);
    if(mapTableHiveNames.containsKey("awl_email_tracking_init_orc"))
      process("awl_email_tracking_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'awl_email_tracking_init_orc'"),Constants.CONTACT_POINT_VIRGULE_SEPARATOR);
    if(mapTableHiveNames.containsKey("awl_messages_received_init_orc"))
      process("awl_messages_received_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'awl_messages_received_init_orc'"),Constants.CONTACT_POINT_VIRGULE_SEPARATOR);
    if(mapTableHiveNames.containsKey("awl_messages_sent_init_orc"))
      process("awl_messages_sent_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'awl_messages_sent_init_orc'"),Constants.CONTACT_POINT_VIRGULE_SEPARATOR);
    if(mapTableHiveNames.containsKey("awl_notifications_init_orc"))
      process("awl_notifications_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'awl_notifications_init_orc'"),Constants.CONTACT_POINT_VIRGULE_SEPARATOR);
    if(mapTableHiveNames.containsKey("editic_acq_init_orc"))
      process("editic_acq_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'editic_acq_init_orc'"),Constants.CONTACT_PIPE_SEPARATOR);
    if(mapTableHiveNames.containsKey("inca_abandons_init_orc"))
      process("inca_abandons_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'inca_abandons_init_orc'"),Constants.CONTACT_POINT_VIRGULE_SEPARATOR);
    if(mapTableHiveNames.containsKey("inca_cabestan_mail_init_orc"))
      process("inca_cabestan_mail_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'inca_cabestan_mail_init_orc'"),Constants.CONTACT_PIPE_SEPARATOR);
    if(mapTableHiveNames.containsKey("inca_cabestan_clics_init_orc"))
      process("inca_cabestan_clics_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'inca_cabestan_clics_init_orc'"),Constants.CONTACT_PIPE_SEPARATOR);
    if(mapTableHiveNames.containsKey("inca_cabestan_devices_init_orc"))
      process("inca_cabestan_devices_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC ='inca_cabestan_devices_init_orc'"),Constants.CONTACT_PIPE_SEPARATOR);
    if(mapTableHiveNames.containsKey("inca_emissaires_retours_init_orc"))
      process("inca_emissaires_retours_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'inca_emissaires_retours_init_orc'"),Constants.CONTACT_PIPE_SEPARATOR);
    if(mapTableHiveNames.containsKey("satho_actco_init_orc"))
     process("satho_actco_init_orc",hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC = 'satho_actco_init_orc'"),Constants.CONTACT_POINT_VIRGULE_SEPARATOR);
    
    // for (String tablename : mapTableHiveNames.keySet())
    // process(tablename,hContext,dataframe.filter("TABLE_HIVE_CIBLE_ORC =   // '"+tablename+"'"));
  }

  public static void process(String tablename, HiveContext hContext, DataFrame dataframe,String separator) throws IOException {

    DataFrame finalDataframe = null;
    DataFrame rowkeyDataFrame = dataframe.filter("TYPE_FILTRE = 'rowkey'");
    DataFrame coderegDataFrame = dataframe.filter("TYPE_FILTRE = 'code_reg'");

    List<Row> listcodereg = coderegDataFrame.collectAsList();
    if(listcodereg.size()>0){
//    update by code reg
    for (Row row : listcodereg) {
      finalDataframe = hContext.sql("select * from bhc_db." + tablename + " where "+row.getString(4)+" like '%" + row.getString(1) + "%'");
      if(finalDataframe != null)
      doReprise(finalDataframe,separator);
    }
    }
//    update by rowkey jointure
    if(!rowkeyDataFrame.rdd().isEmpty()){
    DataFrame hiveTbale = hContext.sql("select * from bhc_db." + tablename +" DISTRIBUTE BY file_name");
//    String columnFilter = rowkeyDataFrame.first().getString(4);
    finalDataframe = hiveTbale.join(rowkeyDataFrame, rowkeyDataFrame.col("ID_REPRISE").equalTo(hiveTbale.col("id_tech")));
    doReprise(finalDataframe,separator);
    }
  }
  
  public static void doReprise(DataFrame dataframe,String separator){
    dataframe.toJavaRDD().foreachPartition(new VoidFunction<Iterator<Row>>() {
      private static final long serialVersionUID = -5844753255324191699L;

      @Override
      public void call(Iterator<Row> rows) throws Exception {
        ApplicationContext context = ApplicationContext.getInstance();
        ContactFactory factory = new ContactFactory();

        String line = null;
        AbstractContactRecord record = null;
        while (rows.hasNext()) {
          try {
            line = rows.next().mkString(separator);
            record = factory.createRecord(line.substring(0, line.indexOf(separator)));
            record.parse(line.substring(line.indexOf(separator) + 1, line.length()));
            record.storeToHbase();
          } catch (Exception e) {
//            throw new CustomException("could not parse record " +record.getFileName());
          }
        }
        context.flushContacts(true);
      }
    });
    
  }
}