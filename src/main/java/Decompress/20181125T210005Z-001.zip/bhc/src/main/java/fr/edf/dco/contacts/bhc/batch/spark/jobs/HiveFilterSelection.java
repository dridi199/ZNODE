package fr.edf.dco.contacts.bhc.batch.spark.jobs;

import java.util.Iterator;
import java.util.Map;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import fr.edf.dco.contacts.bhc.base.ApplicationContext;
import fr.edf.dco.contacts.bhc.base.Constants;
import fr.edf.dco.contacts.bhc.base.ContactFactory;
import fr.edf.dco.contacts.bhc.entities.contact.AbstractContactRecord;
import scala.Tuple2;

/**
 * Update Hbase from hive with a given criter as textfile with ',' or  * ';' separator and the filename must has the same name as the hive table (table_name.column_name_filter)
 * 
 * @author ahmed-externe.dridi@edf.fr
 *
 */
public class HiveFilterSelection {

  public static void main(String[] args) {
    final String separator = "|";
    SparkConf sparkconf = new SparkConf().setAppName(Constants.CONTACT_SPARK_APP_HIVE_HBASE_UPDATE);
    JavaSparkContext jsc = new JavaSparkContext(sparkconf);
    HiveContext hiveContext = new HiveContext(jsc);
    JavaPairRDD<String, String> RowKeyFiles = jsc.wholeTextFiles("/user/dco_app_bhc/tmp/CodeRegroupementToUpdate/");

    RowKeyFiles = RowKeyFiles.mapToPair(new PairFunction<Tuple2<String, String>, String, String>() {
      private static final long serialVersionUID = 5584200452699132177L;

      @Override
      public Tuple2<String, String> call(Tuple2<String, String> t) throws Exception {
        String filetablename = t._1.substring((t._1.lastIndexOf("/") + 1),t._1.length()); //table_name.column_filter
        String filterColumn = t._1.substring((t._1.lastIndexOf(".") + 1), t._1.length()); //table_name.column_filter
        if(filterColumn.equals("id_tech"))
          return new Tuple2<String, String>(filetablename, "'" + t._2.replaceAll(";", ",").replaceAll("[^0-9A-Z,]", "").replaceAll("\n", "").replaceAll(",,", ",").replaceAll(",", "','") + "'");
        else if(filterColumn.equals("file_name"))
            return new Tuple2<String, String>(filetablename, "'" + t._2.replaceAll(";", ",").replaceAll("\n", "").replaceAll(",,", ",").replaceAll(",", "','") + "'");
        else
          return null;
      }
    });
    
    Map<String, String> map = RowKeyFiles.collectAsMap();
    // //iterate over key
    for (String key : map.keySet()) {
      String value = map.get(key);
      updateHbase(key.substring(0,key.indexOf(".")),key.substring(key.indexOf(".")+1,key.length()), value, hiveContext, separator);
    }
  }

  public static void updateHbase(String tableName,String filterColumn, String filterCollection, HiveContext hiveContext, String separator) {
    if(filterColumn.equals("code_regroupement"))
      if(tableName.contains("cabestan")){
        @SuppressWarnings("unused")
        JavaRDD<Row> rowKeysRDD = hiveContext.sql("select * from bhc_db." + tableName + " where " + tableName + ".file_name like '%" + filterCollection + "%'").toJavaRDD();
      }
    JavaRDD<Row> rowKeysRDD = hiveContext.sql("select * from bhc_db." + tableName + " where " + tableName + "."+filterColumn+" in (" + filterCollection + ")").toJavaRDD();
      rowKeysRDD.foreachPartition(new VoidFunction<Iterator<Row>>() {
      private static final long serialVersionUID = -5844753255324191699L;

      @Override
      public void call(Iterator<Row> rows) throws Exception {
        ApplicationContext context = ApplicationContext.getInstance();
        ContactFactory factory = new ContactFactory();

        String line = null;
        AbstractContactRecord record = null;
        while (rows.hasNext()) {
          try {
            line = rows.next().mkString(separator);
            record = factory.createRecord(line.substring(0, line.indexOf(separator)));
            record.parse(line.substring(line.indexOf(separator) + 1, line.length()));
            record.storeToHbase();
          } catch (Exception e) {
            // log later ..
          }
        }
        context.flushBigContacts();
      }
    });

  }

}
