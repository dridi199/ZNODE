package fr.edf.dco.contacts.bhc.base;

/**
 * Application Constants Interface
 * 
 * @author fahd-externe.essid@edf.fr
 */
public final class Constants {

  // BHC properties file parameters

  // Application Properties
  public static final String PROPERTIES_APPLICATION_FILE_NAME = "bhc_Datalab.properties";
  public static final String PROPERTIES_DATALAB_APPLICATION_FILE_NAME = "bhc_Datalab.properties";
  public static final String PROPERTIES_PROD_APPLICATION_FILE_NAME = "bhc_Prod.properties";

  public static final String PROPERTIES_APPLICATION_ENV_NAME = "env";
  public static final String PROPERTIES_APPLICATION_CONTACTS_FILES = "files";
  public static final String PROPERTIES_APPLICATION_ARCHIVAGE = "archivage";
  public static final String PROPERTIES_APPLICATION_INTEGRATION_MODE = "mode";
  public static final String PROPERTIES_APPLICATION_CONTACTS_EXTENSIONS = "extensions";
  public static final String PROPERTIES_APPLICATION_LOGS = "log";
  public static final String PROPERTIES_APPLICATION_INIT = "init";

  // HDFS Properties
  public static final String PROPERTIES_HDFS_RAW_DIR = "contactsHdfsRawDir";
  public static final String PROPERTIES_HDFS_WORK_DIR = "contactsHdfsWorkDir";
  public static final String PROPERTIES_HDFS_ARCHIVE_DIR = "streamArchiveDir";

  // HBASE Properties
  public static final String PROPERTIES_HBASE_CONTACTS_TABLE = "contactsTable";
  public static final String PROPERTIES_HBASE_CONTACTS_TEMP_TABLE = "contactTemporaryTable";
  public static final String PROPERTIES_HBASE_CONTACTS_ZETEMP_TABLE = "contactZETemporaryTable";
  public static final String PROPERTIES_HBASE_KAFKA_PARAMS_CONTACTS_TABLE = "contactsKafkaParamsTable";
  public static final String PROPERTIES_HBASE_PUTS_THRESHOLD = "putsThreshold";
  public static final String PROPERTIES_HFILE_PATH = "hfiles";

  // KERBEROS Properties
  public static final String PROPERTIES_KERBEROS_USER = "applicationUser";
  public static final String PROPERTIES_KERBEROS_KEYTAB = "keytab";

  // SPARK Properties
  public static final String PROPERTIES_SPARK_CONTACTS_PARTITIONS = "sparkContactsPartitions";

  // KAFKA Properties
  public static final String PROPERTIES_KAFKA_STREAM_TOPICS = "kafkaStreamTopic";
  public static final String PROPERTIES_KAFKA_ZOOKEEPER_QUORUM = "zookeeperQuorum";
  public static final String PROPERTIES_KAFKA_BROKERS_LIST = "brokersList";

  // SQLServer Properties
  public static final String PROPERTIES_SQL_SERVER_HOST_PROD = "sqlServerHostProd";
  public static final String PROPERTIES_SQL_SERVER_HOST_PREPROD = "sqlServerHostPreprod";
  public static final String PROPERTIES_SQL_SERVER_INSTANCE = "sqlServerInstance";
  public static final String PROPERTIES_SQL_SERVER_USER = "sqlServerUser";
  public static final String PROPERTIES_SQL_SERVER_PWD_PROD = "sqlServerPwdProd";
  public static final String PROPERTIES_SQL_SERVER_JCEKS_PROD_FILE_PATH = "sqlServerJceksFileProd";
  public static final String PROPERTIES_SQL_SERVER_PWD_PREPROD = "sqlServerPwdPreprod";
  public static final String PROPERTIES_SQL_SERVER_JCEKS_PREPROD_FILE_PATH = "sqlServerJceksFilePreProd";
  public static final String PROPERTIES_SQL_SERVER_CARTOGRAPHY_PROCEDURE = "cartographyStoredProcedure";
  public static final String PROPERTIES_SQL_SERVER_PARAM_ALIM_PROCEDURE = "bhcparamalimStoredProcedure";
  public static final String PROPERTIES_SQL_SERVER_ACQUITTAL_TABLE = "sqlServerAcquittalTable";
  public static final String PROPERTIES_SQL_SERVER_TARGETING_TABLE = "targetingTable";
  public static final String PROPERTIES_SQL_SERVER_FEED_BACK_TABLE = "feedBackTable";
  public static final String PROPERTIES_SQL_SERVER_REACTION_TABLE = "reactionTable";
  public static final String PROPERTIES_SQL_SERVER_BATCH_SIZE = "sqlBatchSize";
  public static final String PROPERTIES_SQL_SERVER_TARGET = "targetReporting";
  
  // Oracle Properties
  public static final String PROPERTIES_ORACLE_SERVER_HOST_PROD = "oracleServerHostProd";
  public static final String PROPERTIES_ORACLE_SERVER_HOST_PREPROD = "oracleServerHostPreprod";
  public static final String PROPERTIES_ORACLE_SERVER_HOST_RE7 = "oracleServerHostRe7";
  public static final String PROPERTIES_ORACLE_SERVER_INSTANCE_PROD = "oracleServerInstanceProd";
  public static final String PROPERTIES_ORACLE_SERVER_INSTANCE_PREPROD = "oracleServerInstancePreProd";
  public static final String PROPERTIES_ORACLE_SERVER_INSTANCE_RE7 = "oracleServerInstanceRe7";
  public static final String PROPERTIES_ORACLE_SERVER_USER = "oracleServerUser";
  public static final String PROPERTIES_ORACLE_SERVER_JCEKS_FILE_PROD_PATH = "oracleServerJceksFileProd";
  public static final String PROPERTIES_ORACLE_SERVER_JCEKS_FILE_PREPROD_PATH = "oracleServerJceksFilePreProd";
  public static final String PROPERTIES_ORACLE_SERVER_JCEKS_FILE_RE7_PATH = "oracleServerJceksFileRe7";
  public static final String PROPERTIES_ORACLE_SERVER_SERVICE_NAME_PROD = "oracleServerServiceNameProd";
  public static final String PROPERTIES_ORACLE_SERVER_SERVICE_NAME_PREPROD = "oracleServerServiceNamePreProd";
  public static final String PROPERTIES_ORACLE_SERVER_SERVICE_NAME_RE7 = "oracleServerServiceNameRe7";
  public static final String PROPERTIES_ORACLE_SERVER_DATABASE = "oracleServerDataBase";
  public static final String PROPERTIES_ORACLE_SERVER_EDITIC_TABLE = "editicTable";
  public static final String PROPERTIES_ORACLE_SERVER_TARGET = "zetargeting";
  
  public static final String SQL_SERVER_CARTOGRAPHY_DB = "Contacts_Sortants";
  public static final String SQL_SERVER_REPORTING_DB = "Contacts_Sortants_Reporting";

    // Elasticsearch Properties
  public static final String PROPERTIES_ELASTIC_TARGETING_INDEX = "elasticTargetingIndex";
  public static final String PROPERTIES_ELASTIC_FEED_BACK_INDEX = "elasticFeedBackIndex";
  public static final String PROPERTIES_ELASTIC_REACTION_INDEX = "elasticReactionIndex";

  // BHC Contacts types
  public static final String CONTACT_TYPE_SORTANT = "SORTANT";
  public static final String CONTACT_TYPE_ENTRANT = "ENTRANT";

  // BHC Contacts streams
  public static final String CONTACT_STREAM_ETL_SIMM = "ETL_SIMM";
  public static final String CONTACT_STREAM_SATHO_ACTCO = "SATHO_ACTCO";
  public static final String CONTACT_STREAM_ECHEA_APURE = "ECHEA_APURE";
  public static final String CONTACT_STREAM_INCA_CABESTAN_MM = "INCA_CABESTAN_MM";
  public static final String CONTACT_STREAM_INCA_EMISSAIRES_MM = "INCA_EMISSAIRES_MM";
  public static final String CONTACT_STREAM_ARMATIS_DPNR = "ARMATIS_DPNR";
  public static final String CONTACT_STREAM_ARMATIS_FEA = "ARMATIS_FEA";
  public static final String CONTACT_STREAM_EDIWAY_EDIFUZ = "EDIWAY_EDIFUZ";
  public static final String CONTACT_STREAM_EDITIC = "EDITIC";
  public static final String CONTACT_STREAM_INCA_INSERT = "INCA_INSERT_MKT";
  public static final String CONTACT_STREAM_INCA_AWL_MM = "INCA_AWL_MM";

  // BHC Contact File Names Patterns
  public static final String CONTACT_FILE_ETL_SIMM = "EDF_SIMM_CST_CONTACTS_SORTANTS_DONNEES_DE_CIBLAGE";
  public static final String CONTACT_FILE_SATHO_ACTCO = "EDF_SIMM_ATOSWORLDLINE_CST_SATHO_ACTCO";
  public static final String CONTACT_FILE_ECHEA_APURE = "EDF_SIMM_ATOSWORLDLINE_CST_ECHEA_APURE";
  public static final String CONTACT_FILE_INCA_CABESTAN_MM = "EDF_MM_CIBLE_EMAIL_CABE";
  public static final String CONTACT_FILE_INCA_CABESTAN_RETOURS_MM = "EDF_MM_CABE";
  public static final String CONTACT_FILE_INCA_EMISSAIRES_MM = "EDF_MM_CIBLE_COURRIER_EMIS";
  public static final String CONTACT_FILE_INCA_EMISSAIRES_RETOURS_MM = "EDF_MM_EMIS_ROUTAGECOURRIER";
  public static final String CONTACT_FILE_ARMATIS_DPNR = "RETOURS_EXPE_LASERCONTACT_DPNR";
  public static final String CONTACT_FILE_ARMATIS_FEA = "out_";
  public static final String CONTACT_FILE_ARMATIS_FEA_RETOURS = "RETOURS_EXPE_LASERCONTACT_FACTU_ELEVEE";
  public static final String CONTACT_FILE_AWL_RETOURS = "WL_";
  public static final String CONTACT_FILE_AWL_MESSAGES_SENT = "MessagesSent";
  public static final String CONTACT_FILE_AWL_NOTIFICATIONS = "Notifications";
  public static final String CONTACT_FILE_AWL_MESSAGES_RECEIVED = "MessagesReceived";
  public static final String CONTACT_FILE_AWL_EMAIL_TRACKING = "EMAILTracking";
  public static final String CONTACT_FILE_INCA_ABANDONS_MM = "EDF_MM_INCA_REPRISE";
  public static final String CONTACT_FILE_EDITIC = "BHC_EDITIC";
  public static final String CONTACT_FILE_EDITIC_TARGETING = "_data";
  public static final String CONTACT_FILE_EDITIC_FEED_BACK = "_acq";
  public static final String CONTACT_FILE_INCA_INSERT = "EDF_MM_INSERT_";
  public static final String CONTACT_FILE_INCA_AWL_MM = "CONTACTS_EDF_MM_";
  public static final String CONTACT_FILE_DACC_APURE_SATHO = "DACC_APURE_SATHO_";

  // BHC Contact Message Key Patterns
  public static final String CONTACT_MESSAGE_EDIWAY_EDIFUZ = "EDIWAY_EDIFUZ";
//  public static final String CONTACT_MESSAGE_EDIFUZ = "EDIWAY_EDIFUZ";
//  public static final String KEY_STREAM_EDIWAY_EDIFUZ = "EDIWAY_EDIFUZ";


  // BHC Aiming Contacts status
  public static final String CONTACT_STATUS_TRANSMIS = "TRANSMIS";
  public static final String CONTACT_STATUS_NON_ENVOYE = "NON_ENVOYE";
  public static final String CONTACT_STATUS_ENVOYE = "ENVOYE";
  public static final String CONTACT_STATUS_SOFTBOUNCE = "SOFTBOUNCE";
  public static final String CONTACT_STATUS_HARDBOUNCE = "HARDBOUNCE";
  public static final String CONTACT_STATUS_SPAM = "SPAM";
  public static final String CONTACT_STATUS_OUVERT = "OUVERT";
  public static final String CONTACT_STATUS_OPEN = "OPEN";
  public static final String CONTACT_STATUS_RESPONSE = "REPONSE";
  public static final String CONTACT_STATUS_OPTOUT = "DESABONNE";
  public static final String CONTACT_STATUS_CLIC = "CLIC";
  public static final String CONTACT_STATUS_CLICK = "CLICK";
  public static final String CONTACT_STATUS_MIRROR_PAGE = "PAGE_MIROIR";
  public static final String CONTACT_STATUS_PENDING = "PENDING";
  public static final String CONTACT_STATUS_SUCCESS = "SUCCESS";
  public static final String CONTACT_STATUS_EN_COURS = "EN_COURS";
  public static final String CONTACT_STATUS_ERROR = "ERROR";
  public static final String CONTACT_STATUS_UNKNOWN_ERROR = "ERR_UNKNOWN";
  public static final String CONTACT_STATUS_UNKNOWN = "UNKNOWN";
  public static final String CONTACT_STATUS_ABANDONED = "ABANDON_METIER";
  public static final String CONTACT_STATUS_RAW_ABANDONED = "ABANDON";
  public static final String CONTACT_STATUS_UNPRIORITIZED = "DEPRIORISE";

  // BHC Chanel types
  public static final String CONTACT_CANAL_MULTI = "MULTICANAL";
  public static final String CONTACT_CANAL_NO_COORD = "NO_COORD";
  public static final String CONTACT_CANAL_SMS = "SMS";
  public static final String CONTACT_CANAL_PUSH_VOCAL = "PUSH_VOCAL";
  public static final String CONTACT_CANAL_EMAIL = "EMAIL";
  public static final String CONTACT_CANAL_COURRIER = "COURRIER";
  public static final String CONTACT_CANAL_DOUBLE_CLIC = "DOUBLECLIC";
  public static final String CONTACT_CANAL_IMPLOC = "IMPLOC";
  public static final String CONTACT_CANAL_EDI = "EDI";

  // BHC Market types
  public static final String CONTACT_MARKET_MM = "MCP";
  public static final String CONTACT_MARKET_MA = "MA";
  
  // BHC flux separator
  public static final String CONTACT_PIPE_SEPARATOR = "|";
  public static final String CONTACT_POINT_VIRGULE_SEPARATOR = ";";


  // BHC Contacts file Headers values
  public static final String CONTACT_HEADER_ARMATIS_FEED_BACK = "id_demande_comm";
  public static final String CONTACT_HEADER_AWL_FEED_BACK = "contactRef";
  // BHC Contacts default values
  public static final String CONTACT_DEFAULT_NULL_ADDRESS = "null,null,null,null,null,null,null";

  // BHC ARMATIS DPNR Record Types
  public static final String CONTACT_ARMATIS_DPNR_CIBLE_COURRIER = "CIBLE_COURRIER";
  public static final String CONTACT_ARMATIS_DPNR_CIBLE_EMAIL = "CIBLE_EMAIL";

  // HDFSLogger Error Messages IDs :
  public static final String ERROR_HDFS = "HDFS";
  public static final String ERROR_HIVE = "HIVE";
  public static final String ERROR_HBASE = "HBASE";
  public static final String ERROR_KAFKA = "KAFKA";
  public static final String ERROR_ELASTICSEARCH = "ELASTIC";
  public static final String ERROR_SQLSERVER = "SQLSERVER";
  public static final String ERROR_DATA = "DATA";
  public static final String ERROR_OTHER = "TECH";

  // HDFSLogger Warning Messages IDs :
  public static final String WARNING_DATA = "DATA";
  public static final String WARNING_OTHER = "WARN";

  // HDFSLogger Info Messages IDs :
  public static final String INFO_START = "DEBUT";
  public static final String INFO_END = "FIN";
  public static final String INFO_OTHER = "INFO";

  // BHC loggin types :
  public static final String LOG_CONSOLE = "console";
  public static final String LOG_HDFS = "hdfs";

  // HDFSLogger Debug Messages IDs :
  public static final String DEBUG_MESSAGE = "";

  // BHC Contacts Process Codes:
  public static final String CONTACT_PROCESS_GOLABAL = "T0000";
  public static final String CONTACT_PROCESS_HDFS_TO_HBASE = "T0001";
  public static final String CONTACT_PROCESS_HBASE_TO_SQL_SERVER = "T0002";
  public static final String CONTACT_PROCESS_KAFKA_TO_HBASE = "T0003";
  public static final String CONTACT_PROCESS_PARSING = "T0004";

  // BHC Spark Batch Action Applications Names
  public static final String CONTACT_SPARK_APP_HDFS_HBASE = "fr.edf.dco.cs.hdfs2hbase";
  public static final String CONTACT_SPARK_APP_HDFS_CLEANER = "fr.edf.dco.cs.hdfscleaner"; 
  public static final String CONTACT_SPARK_APP_HBASE_SQL_SERVER = "fr.edf.dco.cs.hbase2SqlSerer";
  public static final String CONTACT_SPARK_APP_HBASE_ORACLE_SERVER = "fr.edf.dco.cs.hbase2OracleSerer";
  
  public static final String CONTACT_SPARK_APP_KAFKA_HBASE = "fr.edf.dco.cs.kafka2hbase";
  public static final String CONTACT_SPARK_APP_HDFS_KAFKA = "fr.edf.dco.cs.kafka2hbase";
  public static final String CONTACT_SPARK_APP_STREAMING_KAFKA_HBASE = "fr.edf.dco.cs.kafka2hbaseStream";
  public static final String CONTACT_SPARK_APP_HBASE_HIVE = "fr.edf.dco.cs.hbase2hive";
  public static final String CONTACT_SPARK_APP_HIVE_HBASE = "fr.edf.dco.cs.hive2hbase";
  public static final String CONTACT_SPARK_APP_HIVE_HBASE_UPDATE = "HiveHbaseUpdateByRowKey";
  public static final String CONTACT_SPARK_APP_SPARK_HBASE_ELASTIC = "fr.edf.dco.cs.hbase2es";
  public static final String CONTACT_SPARK_APP_HBASE_UPDATE = "fr.edf.dco.cs.hbaseupdate";
  public static final String CONTACT_SPARK_APP_KAFKA_HBASE_STREAMING = "StreamingKafkaRecoverableDirectEvent";
  // HBase to SQLServer acquittal parameters
  public static final String ACQUITTAL_TARGETING_TABLE_SHORT_NAME = "CIB";
  public static final String ACQUITTAL_FEED_BACK_TABLE_SHORT_NAME = "INT";
  public static final String ACQUITTAL_REACTION_TABLE_SHORT_NAME = "REA";
  public static final String ACQUITTAL_START = "DEBUT";
  public static final String ACQUITTAL_END = "FIN";
}
