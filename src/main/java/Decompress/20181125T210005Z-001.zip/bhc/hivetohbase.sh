#!/bin/bash

spark-submit --jars lib/datanucleus-core-3.2.10.jar,lib/datanucleus-api-jdo-3.2.6.jar,lib/datanucleus-rdbms-3.2.9.jar,/home/dco_app/usr/lib/hdfs/HDFSLogger-2.6.0.jar --files hbase-site.xml,bhc.properties,krb5.conf,dco_app_bhc.keytab,hive-site.xml,config/HDFSLogger.properties --class fr.edf.dco.contacts.bhc.batch.spark.jobs.$1 --master yarn-cluster --queue dco_batch --num-executors 20 --executor-memory 5G --executor-cores 1 --driver-memory 5G --driver-cores 1 --conf spark.sql.shuffle.partitions=200 --conf spark.yarn.executor.memoryOverhead=1048  usr/lib/bhc.jar  HiveToHbaseWorkJob $3 $4 $5


